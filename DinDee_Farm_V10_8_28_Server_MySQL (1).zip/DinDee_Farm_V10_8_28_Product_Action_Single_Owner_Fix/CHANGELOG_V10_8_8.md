# V10.8.8 — Today Work History Material Summary
- The compact Work History card on the Today page now shows actual Material / Lot / Quantity / Unit.
- It reads from the same task-linked D.usages source as full Work History.
- Returned quantity is subtracted; cancelled usage is excluded.
- Also shows separate Task Status and Work Result for consistency with V10.8.7.
- Full Work History remains unchanged.
