# V10.8.28 — Product Action Single Owner Fix

- Based on V10.8.26 (V10.8.27 cleanup patch intentionally not used).
- Product Catalog row delete action now has one owner: `v1052.js`.
- Removed Product Catalog delete injection from `v1051.js`.
- Removed Product Catalog action normalization/injection rule from `v1056.js`.
- Kept delete behavior, Product edit, Checkout, Reports, Stock and Accounting unchanged.
- Purpose: prevent asynchronous render passes from recreating duplicate delete buttons after the catalog first opens.
