# V10.7.6 — Farm Shop Category Split
- Farm Shop now separates `คอร์ส / Workshop` and `กิจกรรม`.
- `คอร์ส / Workshop` maps conceptually to Learning Center Income > Workshop Income.
- `กิจกรรม` maps conceptually to Learning Center Income > Activity Income.
- Existing `คอร์ส` products migrate to `คอร์ส / Workshop`.
- Existing `กิจกรรม / Workshop` products migrate to `กิจกรรม` and are marked for category review because old data cannot tell Activity from Workshop reliably; Admin can move Workshop items using Edit Product.
- Both categories remain learning-center services and retain Activity QR behavior.
