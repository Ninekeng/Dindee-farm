# V10.5.7 — Settings, Users & UI Clarity

- Settings master rows now have Edit, Safe Delete, and Enable/Disable actions.
- Master records referenced by transactions are deactivated instead of hard-deleted where references can be detected.
- User Management now has Edit, Password, Role, and Delete actions.
- Prevents deleting the currently logged-in account and preserves at least one Admin.
- Improved Settings/User table hierarchy, status chips, action spacing, and responsive layout.
- Stock category/Thai description metadata is displayed smaller (11px) to reduce row width.
