'use strict';
/*
 ตรวจความสอดคล้องของ Order กับบัญชีรายรับ (อ่านอย่างเดียว ไม่แก้ข้อมูล)
 กฎตามระบบเดิม: Order "รับเงินแล้ว" เมื่อ cashReceived = true หรือสถานะเป็น Confirmed/Preparing/Packed/Shipping/Completed
 และเมื่อรับเงินแล้วต้องมีรายรับ source='Farm Shop' อ้าง refId = id ของ Order โดยยอดรวมเท่ากับยอด Order
*/
const PAID_STATUS = ['Confirmed', 'Preparing', 'Packed', 'Shipping', 'Completed'];
const arr = x => (Array.isArray(x) ? x : []);
const num = x => Number(x) || 0;
const isPaid = o => !!o.cashReceived || PAID_STATUS.includes(o.status);

function checkLedger({ orders, income }) {
  const O = arr(orders), I = arr(income).filter(x => x && x.source === 'Farm Shop');
  const byRef = new Map();
  I.forEach(x => { if (!byRef.has(x.refId)) byRef.set(x.refId, []); byRef.get(x.refId).push(x); });
  const ids = new Set(O.map(o => o.id));
  const issues = [];
  const add = (type, o, detail) => issues.push({ type, order: o ? o.no || o.id : undefined, ...detail });

  for (const o of O) {
    const rows = byRef.get(o.id) || [];
    const sum = rows.reduce((s, x) => s + num(x.amount), 0);
    if (isPaid(o)) {
      if (!rows.length) add('paid_without_income', o, { total: num(o.total), message: 'รับเงินแล้วแต่ไม่มีรายรับ' });
      else if (Math.abs(sum - num(o.total)) > 0.01) add('income_total_mismatch', o, { total: num(o.total), incomeSum: sum, message: 'ยอดรายรับไม่เท่ายอด Order' });
    } else if (rows.length) add('income_without_payment', o, { incomeSum: sum, status: o.status, message: 'มีรายรับแต่ Order ยังไม่ถือว่ารับเงิน' });
  }
  for (const [ref, rows] of byRef) if (!ids.has(ref)) issues.push({ type: 'orphan_income', refId: ref, incomeSum: rows.reduce((s, x) => s + num(x.amount), 0), message: 'รายรับอ้าง Order ที่ไม่มีอยู่' });
  const seenNo = new Map();
  for (const o of O) if (o.no) { if (seenNo.has(o.no)) add('duplicate_order_no', o, { message: 'เลข Order ซ้ำ' }); seenNo.set(o.no, 1); }
  return { ok: issues.length === 0, orders: O.length, incomeRows: I.length, issues };
}

module.exports = { checkLedger, isPaid };
