'use strict';
/*
 DinDee Farm server — Node.js (ไม่ต้องใช้ express) + MySQL
 - เสิร์ฟไฟล์หน้าเว็บ (index.html, css/, js/, modules/)
 - /api/*  : login, bootstrap ข้อมูล, บันทึกข้อมูลลง MySQL, backup
*/
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { createDb } = require('./db');
const { legacyHash, hashPassword, verifyPassword, isScrypt } = require('./auth');
const { loadBrand } = require('./brand');
const { checkLedger } = require('./ledger');

const ROOT = path.resolve(__dirname, '..');
const PORT = process.env.PORT !== undefined && process.env.PORT !== '' ? +process.env.PORT : 3000;
const HOST = process.env.HOST || '0.0.0.0';
const MAX_BODY = (+process.env.MAX_BODY_MB || 25) * 1024 * 1024;
const SECURE = process.env.COOKIE_SECURE === '1';
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const COOKIE = 'dd_sid';
const SESSION_MS = (+process.env.SESSION_DAYS || 7) * 86400000;

const FULL_ROLES = ['Admin', 'Staff', 'Sponsor Viewer'];
const PUBLIC_KEYS = ['products', 'appSettings', 'units', 'shopCategories', 'farmProfile'];
const KEY_RE = /^[A-Za-z0-9_]{1,100}$/;

let db, SECRET, brand;

/* ---------- helpers ---------- */
const parse = (s, d) => { try { const x = JSON.parse(s); return x == null ? d : x; } catch (_) { return d; } };
const arr = x => (Array.isArray(x) ? x : []);
const num = x => Number(x) || 0;
const genId = () => Date.now().toString(36) + crypto.randomBytes(3).toString('hex');

function send(res, code, body, headers = {}) {
  const isObj = body !== null && typeof body === 'object' && !Buffer.isBuffer(body);
  const data = isObj ? JSON.stringify(body) : body;
  res.writeHead(code, Object.assign({
    'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin',
  }, headers));
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('too large'), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (_) { reject(Object.assign(new Error('bad json'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

function clientIp(req) {
  if (TRUST_PROXY && req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',')[0].trim();
  return req.socket.remoteAddress || '';
}

/* ---------- session (cookie ลงลายมือ HMAC ไม่ต้องเก็บ session ในฐานข้อมูล) ---------- */
const b64 = b => Buffer.from(b).toString('base64url');
const sign = p => crypto.createHmac('sha256', SECRET).update(p).digest('base64url');
function makeCookie(sess) {
  const p = b64(JSON.stringify({ ...sess, exp: Date.now() + SESSION_MS }));
  return `${COOKIE}=${p}.${sign(p)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${Math.floor(SESSION_MS / 1000)}${SECURE ? '; Secure' : ''}`;
}
const clearCookie = () => `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${SECURE ? '; Secure' : ''}`;
function getSession(req) {
  const m = /(?:^|;\s*)dd_sid=([^;]+)/.exec(req.headers.cookie || '');
  if (!m) return null;
  const [p, sig] = m[1].split('.');
  if (!p || !sig) return null;
  const good = sign(p);
  if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return null;
  const s = parse(Buffer.from(p, 'base64url').toString('utf8'), null);
  return s && s.exp > Date.now() ? s : null;
}

/* ---------- login rate limit ---------- */
const fails = new Map();
function limited(key) { const f = fails.get(key); return f && f.n >= 8 && Date.now() - f.t < 10 * 60000; }
function noteFail(key) { const f = fails.get(key); fails.set(key, { n: f && Date.now() - f.t < 10 * 60000 ? f.n + 1 : 1, t: Date.now() }); }
setInterval(() => { const now = Date.now(); for (const [k, f] of fails) if (now - f.t > 10 * 60000) fails.delete(k); }, 60000).unref();

/* ---------- first-run seed ---------- */
async function ensureSeed() {
  if (await db.get('users')) return;
  let pw = process.env.ADMIN_PASSWORD, generated = false;
  if (!pw) { pw = crypto.randomBytes(6).toString('base64url'); generated = true; }
  await db.put('users', JSON.stringify([{ id: genId(), user: 'admin', pass: await hashPassword(pw), role: 'Admin' }]), null, 'seed', true);
  if (!(await db.get('houses'))) {
    await db.put('houses', JSON.stringify([1, 2, 3, 4, 5].map(i => ({ id: 'H' + i, name: 'โรงเรือน ' + i, camera: '' }))), null, 'seed', true);
  }
  if (!(await db.get('stock'))) {
    await db.put('stock', JSON.stringify([{ id: genId(), name: 'ปุ๋ยอินทรีย์ A', qty: 20, unit: 'kg' }, { id: genId(), name: 'ชีวภัณฑ์ป้องกันแมลง', qty: 10, unit: 'L' }]), null, 'seed', true);
  }
  console.log('============================================================');
  console.log(' สร้างบัญชีผู้ดูแลเริ่มต้นแล้ว  Username: admin');
  console.log(generated ? ` Password: ${pw}   (สุ่มให้ — เข้าระบบแล้วโปรดเปลี่ยนทันที)` : ' Password: ตามค่า ADMIN_PASSWORD');
  console.log('============================================================');
}

/* ---------- bootstrap ---------- */
/* ไม่ส่ง hash/รหัสผ่านไปให้ browser ทุก role (รวม Admin) — server เก็บไว้เอง และคืนค่าเดิมให้ตอนบันทึก */
function stripUsers(v) {
  return JSON.stringify(arr(parse(v, [])).map(u => { const c = { ...u }; delete c.pass; delete c.plainPass; return c; }));
}
async function bootstrapJs(sess) {
  await ensureSeed();
  const full = !!sess && FULL_ROLES.includes(sess.role);
  const rows = await db.getAll();
  const state = {}, vers = {};
  for (const r of rows) {
    if (full) {
      state[r.k] = r.k === 'users' ? stripUsers(r.v) : r.v;
      vers[r.k] = r.ver;
    } else if (PUBLIC_KEYS.includes(r.k)) {
      state[r.k] = r.v; vers[r.k] = r.ver;
    } else if (r.k === 'orders') { /* ลูกค้าทั่วไปได้เฉพาะเลข Order เพื่อให้เลขรันไม่ซ้ำ ไม่เห็นข้อมูลลูกค้า */
      state.orders = JSON.stringify(arr(parse(r.v, [])).map(o => ({ id: o.id, no: o.no })));
    }
  }
  const out = {
    tier: full ? 'full' : 'public',
    readOnly: !!sess && sess.role === 'Sponsor Viewer',
    session: sess ? { id: sess.id, user: sess.user, role: sess.role } : null,
    state, vers,
  };
  return 'window.__DINDEE__=' + JSON.stringify(out).replace(/</g, '\\u003c') + ';';
}

/* ---------- ลูกค้าทั่วไปสั่งซื้อ: server ตรวจราคา/ตัดสต็อกเอง ไม่เชื่อค่าจาก browser ---------- */
async function publicAddOrders(incoming, by) {
  let added = 0;
  /* orders + products อยู่ใน transaction เดียว: ไม่มีกรณีได้ Order แต่สต็อกไม่ถูกตัด (หรือกลับกัน) */
  await db.multi(['orders', 'products'], cur => {
    const prods = arr(parse(cur.products && cur.products.v, []));
    const list = arr(parse(cur.orders && cur.orders.v, []));
    const have = new Set(list.map(o => o.id));
    let max = Math.max(0, ...list.map(o => parseInt(String(o.no || '').replace(/\D/g, ''), 10) || 0));
    const fresh = arr(incoming).filter(o => o && typeof o.id === 'string' && !have.has(o.id)).slice(0, 10);
    const soldQty = {};
    for (const o of fresh) {
      const items = [];
      for (const it of arr(o.items)) {
        const p = prods.find(x => x.id === it.productId);
        const q = Math.floor(num(it.qty));
        if (!p || q < 1 || p.status === 'ปิดขาย') continue;
        items.push({ ...it, productId: p.id, name: p.name, unit: p.unit, price: num(p.price), qty: q });
      }
      if (!items.length) continue;
      const qr = o.paymentMethod === 'qr';
      const nos = new Set(list.map(x => x.no));
      let no = String(o.no || '');
      if (!no || nos.has(no)) no = 'D' + String(++max).padStart(4, '0'); else max = Math.max(max, parseInt(no.replace(/\D/g, ''), 10) || 0);
      list.push({
        ...o, no, items,
        qty: items.reduce((s, x) => s + x.qty, 0),
        total: items.reduce((s, x) => s + x.qty * x.price, 0),
        status: qr ? 'Payment Submitted' : 'New',
        cashStatus: qr ? '' : 'Pending Cash',
        history: arr(o.history).slice(0, 5),
      });
      items.forEach(x => { soldQty[x.productId] = (soldQty[x.productId] || 0) + x.qty; });
      added++;
    }
    if (!added) return {};
    prods.forEach(p => { if (soldQty[p.id]) p.qty = Math.max(0, num(p.qty) - soldQty[p.id]); });
    return { orders: JSON.stringify(list), products: JSON.stringify(prods) };
  }, by);
  return added;
}
async function publicAddCustomers(incoming, by) {
  await db.update('customers', cur => {
    const list = arr(parse(cur, []));
    const have = new Set(list.map(c => c.id));
    const fresh = arr(incoming).filter(c => c && typeof c.id === 'string' && !have.has(c.id)).slice(0, 10);
    fresh.forEach(c => list.push({ id: c.id, phone: String(c.phone || '').replace(/\D/g, '').slice(0, 15), name: String(c.name || '').slice(0, 200), address: String(c.address || '').slice(0, 500), note: String(c.note || '').slice(0, 500), created: c.created, active: true, pinHash: c.pinHash, pinCreatedAt: c.pinCreatedAt }));
    return fresh.length ? JSON.stringify(list) : null;
  }, by);
}

/* รวมรายการ users ที่ client ส่งมากับของเดิมบน server (รหัสผ่านเดิมคงไว้ / plainPass -> scrypt) */
function mergeUsers(val, curStr, fresh) {
  const old = new Map(arr(parse(curStr, [])).map(x => [x.id, x]));
  const merged = val.filter(u => u && typeof u === 'object').map(u => {
    const o = old.get(u.id), c = { ...u };
    delete c.plainPass;
    if (fresh.has(u)) c.pass = fresh.get(u);
    else if (o) c.pass = o.pass; /* ไม่มีรหัสใหม่ -> คงรหัสเดิมบน server เสมอ (client ตั้ง hash เองไม่ได้) */
    else if (!isScrypt(c.pass)) delete c.pass; /* ผู้ใช้ใหม่ที่ไม่มี plainPass จะไม่มีรหัส -> ถูกปฏิเสธด้านล่าง */
    return c;
  });
  if (merged.some(x => !x.pass)) throw Object.assign(new Error('no pass'), { status: 400 });
  if (!merged.some(x => x.role === 'Admin')) throw Object.assign(new Error('no admin'), { status: 400 });
  return JSON.stringify(merged);
}
const userErr = e => (e.message === 'no admin' ? 'ต้องมีบัญชี Admin อย่างน้อย 1 บัญชี' : 'ผู้ใช้ทุกคนต้องมีรหัสผ่าน');
async function hashFresh(val) {
  const fresh = new Map();
  for (const u of val) if (u && typeof u.plainPass === 'string' && u.plainPass) fresh.set(u, await hashPassword(u.plainPass));
  return fresh;
}

/* ---------- API ---------- */
async function api(req, res, u) {
  const route = u.pathname, method = req.method;
  const sess = getSession(req);

  if (route === '/api/health') { await db.versions(); return send(res, 200, { ok: true, db: db.kind }); }

  if (route === '/api/bootstrap.js' && method === 'GET') {
    return send(res, 200, await bootstrapJs(sess), { 'Content-Type': 'application/javascript; charset=utf-8' });
  }

  if (route === '/api/login' && method === 'POST') {
    const b = await readBody(req);
    const user = String(b.user || '').trim(), pass = String(b.pass || '');
    const rk = clientIp(req) + '|' + user.toLowerCase();
    if (limited(rk) || limited(clientIp(req))) return send(res, 429, { error: 'พยายามเข้าสู่ระบบผิดหลายครั้ง กรุณารอ 10 นาที' });
    await ensureSeed();
    const users = arr(parse((await db.get('users')).v, []));
    let me = null, legacy = false;
    if (user && pass) {
      for (const x of users.filter(x => x.user === user)) {
        const v = await verifyPassword(pass, x.pass);
        if (v.ok) { me = x; legacy = !!v.legacy; break; }
      }
    }
    if (!me) { noteFail(rk); noteFail(clientIp(req)); return send(res, 401, { error: 'Username หรือ Password ไม่ถูกต้อง' }); }
    if (legacy) { /* อัปเกรด hash เก่า -> scrypt เงียบ ๆ */
      const nh = await hashPassword(pass);
      await db.update('users', cur => {
        const list = arr(parse(cur, [])), t = list.find(x => x.id === me.id);
        if (!t || t.pass !== me.pass) return null;
        t.pass = nh; delete t.plainPass; return JSON.stringify(list);
      }, 'system');
    }
    fails.delete(rk);
    return send(res, 200, { ok: true, role: me.role }, { 'Set-Cookie': makeCookie({ id: me.id, user: me.user, role: me.role }) });
  }

  if (route === '/api/logout' && method === 'POST') return send(res, 200, { ok: true }, { 'Set-Cookie': clearCookie() });

  if (route === '/api/versions' && method === 'GET') {
    if (!sess || !FULL_ROLES.includes(sess.role)) return send(res, 401, { error: 'unauthorized' });
    const vers = {}; (await db.versions()).forEach(r => { vers[r.k] = r.ver; });
    return send(res, 200, { vers });
  }

  if (route === '/api/ledger-check' && method === 'GET') {
    if (!sess || sess.role !== 'Admin') return send(res, 403, { error: 'forbidden' });
    const rd = async k => { const r = await db.get(k); return r ? parse(r.v, []) : []; };
    return send(res, 200, checkLedger({ orders: await rd('orders'), income: await rd('income') }));
  }

  if (route === '/api/backup' && method === 'GET') {
    if (!sess || sess.role !== 'Admin') return send(res, 403, { error: 'forbidden' });
    const data = {}; (await db.getAll()).forEach(r => { data[r.k] = parse(r.v, null); });
    const name = 'dindee-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    return send(res, 200, JSON.stringify({ exportedAt: new Date().toISOString(), data }), {
      'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': `attachment; filename="${name}"`,
    });
  }

  if (route === '/api/reset' && method === 'POST') {
    if (!sess || sess.role !== 'Admin') return send(res, 403, { error: 'forbidden' });
    const b = await readBody(req);
    if (b.confirm !== 'RESET') return send(res, 400, { error: 'ต้องยืนยันด้วยคำว่า RESET' });
    await db.delAll();
    return send(res, 200, { ok: true });
  }

  /* บันทึกหลายชุดข้อมูลพร้อมกันใน transaction เดียว: สำเร็จทั้งหมด หรือไม่เปลี่ยนอะไรเลย */
  if (route === '/api/commit' && method === 'POST') {
    if (!sess) return send(res, 401, { error: 'unauthorized' });
    if (sess.role !== 'Admin' && sess.role !== 'Staff') return send(res, 403, { error: 'forbidden' });
    const b = await readBody(req);
    if (!Array.isArray(b.writes) || !b.writes.length || b.writes.length > 40) return send(res, 400, { error: 'writes ต้องเป็น array 1-40 รายการ' });
    const seen = new Set(), ws = [];
    for (const w of b.writes) {
      if (!w || !KEY_RE.test(w.key || '') || seen.has(w.key)) return send(res, 400, { error: 'bad key' });
      seen.add(w.key);
      if (w.del === true) {
        if (sess.role !== 'Admin') return send(res, 403, { error: 'forbidden' });
        if (w.key === 'users') return send(res, 400, { error: 'ไม่อนุญาตให้ลบ users' });
        ws.push({ key: w.key, del: true });
        continue;
      }
      if (typeof w.value !== 'string') return send(res, 400, { error: 'value must be string' });
      let val; try { val = JSON.parse(w.value); } catch (_) { return send(res, 400, { error: 'value must be JSON' }); }
      if (w.key === 'users') {
        if (sess.role !== 'Admin') return send(res, 403, { error: 'เฉพาะ Admin' });
        if (!Array.isArray(val)) return send(res, 400, { error: 'users ต้องเป็น array' });
      }
      ws.push({ key: w.key, value: w.value, val, base: w.base == null ? null : Number(w.base), force: w.force === true });
    }
    const uw = ws.find(w => w.key === 'users' && !w.del);
    const fresh = uw ? await hashFresh(uw.val) : new Map();
    try {
      const r = await db.multi(ws.map(w => w.key), cur => {
        const conflicts = [];
        for (const w of ws) {
          const c = cur[w.key];
          if (w.del || w.force || !c) continue;
          if (w.base == null || w.base !== c.ver) conflicts.push({ key: w.key, ver: c.ver });
        }
        if (conflicts.length) throw Object.assign(new Error('conflict'), { conflicts });
        const out = {};
        for (const w of ws) out[w.key] = w.del ? null : w.key === 'users' ? mergeUsers(w.val, cur.users ? cur.users.v : null, fresh) : w.value;
        return out;
      }, sess.user);
      return send(res, 200, { ok: true, vers: r.vers });
    } catch (e) {
      if (e.conflicts) return send(res, 409, { error: 'conflict', conflicts: e.conflicts });
      if (e.status === 400) return send(res, 400, { error: userErr(e) });
      throw e;
    }
  }

  const m = /^\/api\/kv\/([^/]+)$/.exec(route);
  if (m) {
    const key = m[1];
    if (!KEY_RE.test(key)) return send(res, 400, { error: 'bad key' });
    const role = sess && sess.role;
    const by = sess ? sess.user : 'guest';

    if (method === 'PUT') {
      const b = await readBody(req);
      if (typeof b.value !== 'string') return send(res, 400, { error: 'value must be string' });
      let val; try { val = JSON.parse(b.value); } catch (_) { return send(res, 400, { error: 'value must be JSON' }); }

      /* ลูกค้าทั่วไป/Customer: เพิ่มได้เฉพาะ orders และ customers แบบ merge */
      if (!role || role === 'Customer') {
        if (key === 'orders') return send(res, 200, { ok: true, merged: await publicAddOrders(val, by) });
        if (key === 'customers') { await publicAddCustomers(val, by); return send(res, 200, { ok: true, merged: true }); }
        return send(res, role ? 403 : 401, { error: 'forbidden' });
      }
      if (role === 'Sponsor Viewer') return send(res, 403, { error: 'read-only account' });
      if (key === 'users') {
        if (role !== 'Admin') return send(res, 403, { error: 'เฉพาะ Admin' });
        if (!Array.isArray(val)) return send(res, 400, { error: 'users ต้องเป็น array' });
        const fresh = await hashFresh(val);
        try {
          const r = await db.update('users', (cur, ver) => {
            if (!b.force && b.base != null && Number(b.base) !== ver) throw Object.assign(new Error('conflict'), { conflict: ver });
            return mergeUsers(val, cur, fresh);
          }, by);
          return send(res, 200, { ok: true, ver: r.ver });
        } catch (e) {
          if (e.conflict != null) return send(res, 409, { error: 'conflict', ver: e.conflict });
          if (e.status === 400) return send(res, 400, { error: userErr(e) });
          throw e;
        }
      }
      const r = await db.put(key, b.value, b.base == null ? null : Number(b.base), by, b.force === true);
      if (r.conflict) return send(res, 409, { error: 'conflict', ver: r.ver });
      return send(res, 200, { ok: true, ver: r.ver });
    }

    if (method === 'DELETE') {
      if (role !== 'Admin') return send(res, 403, { error: 'forbidden' });
      if (key === 'users') return send(res, 400, { error: 'ไม่อนุญาตให้ลบ users' });
      await db.del(key);
      return send(res, 200, { ok: true });
    }
  }
  return send(res, 404, { error: 'not found' });
}

/* ---------- static (allowlist เท่านั้น: server/, tests/, *.md ไม่ถูกเสิร์ฟ) ---------- */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webp': 'image/webp', '.json': 'application/json',
};
const ALLOW_DIRS = ['css', 'js', 'modules'];
const gzCache = new Map();
function serveStatic(req, res, u) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method Not Allowed');
  let p;
  try { p = decodeURIComponent(u.pathname); } catch (_) { return send(res, 400, 'bad request'); }
  if (p === '/') p = '/index.html';
  if (p === '/brand/logo') {
    if (!brand.logoPath) return send(res, 404, 'Not found');
    return fs.readFile(brand.logoPath, (e, buf) => e ? send(res, 404, 'Not found') : send(res, 200, buf, { 'Content-Type': brand.logoType, 'Cache-Control': 'public, max-age=300', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'" }));
  }
  const rel = path.posix.normalize(p).replace(/^\/+/, '');
  const top = rel.split('/')[0];
  if (rel.includes('..') || rel.includes('\0') || !(rel === 'index.html' || (ALLOW_DIRS.includes(top) && rel.includes('/')))) return send(res, 404, 'Not found');
  const file = path.join(ROOT, rel);
  if (!file.startsWith(ROOT + path.sep)) return send(res, 404, 'Not found');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'Not found');
    const type = MIME[path.extname(file).toLowerCase()];
    if (!type) return send(res, 404, 'Not found');
    const etag = `"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}-${brand.sig}"`;
    const h = { 'Content-Type': type, 'Cache-Control': 'no-cache', ETag: etag, 'X-Content-Type-Options': 'nosniff' };
    if (req.headers['if-none-match'] === etag) { res.writeHead(304, h); return res.end(); }
    const text = /^(text\/|application\/(javascript|json))/.test(type) || type.includes('svg');
    const gz = text && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
    if (gz) h['Content-Encoding'] = 'gzip';
    h.Vary = 'Accept-Encoding';
    if (req.method === 'HEAD') { res.writeHead(200, h); return res.end(); }
    fs.readFile(file, (e2, buf0) => {
      if (e2) return send(res, 500, 'error');
      const buf = !brand.identity && (rel === 'index.html' || /\.js$/.test(rel)) ? Buffer.from(brand.transform(buf0.toString('utf8'), rel), 'utf8') : buf0;
      if (!gz) { res.writeHead(200, h); return res.end(buf); }
      const ck = file + etag; let z = gzCache.get(ck);
      if (!z) { z = zlib.gzipSync(buf); if (gzCache.size > 300) gzCache.clear(); gzCache.set(ck, z); }
      res.writeHead(200, h); res.end(z);
    });
  });
}

/* ---------- main ---------- */
async function start() {
  brand = loadBrand(ROOT);
  db = createDb();
  await db.init();
  SECRET = process.env.SESSION_SECRET || await db.getMeta('session_secret');
  if (!SECRET) { SECRET = crypto.randomBytes(32).toString('hex'); await db.setMeta('session_secret', SECRET); }
  await ensureSeed();

  const server = http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url, 'http://x');
      if (u.pathname.startsWith('/api/')) await api(req, res, u);
      else serveStatic(req, res, u);
    } catch (e) {
      const status = e.status || 500;
      if (status === 500) console.error('[error]', req.method, req.url, e);
      if (!res.headersSent) send(res, status, { error: status === 413 ? 'ข้อมูลใหญ่เกินกำหนด (เพิ่ม MAX_BODY_MB)' : status === 400 ? 'bad request' : 'server error' });
    }
  });
  await new Promise(r => server.listen(PORT, HOST, r));
  console.log(`${brand.config.nameEn} พร้อมใช้งานที่ http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${server.address().port}  (db: ${db.kind})`);
  const stop = async () => { server.close(); try { await db.close(); } catch (_) {} process.exit(0); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
  return server;
}

if (require.main === module) start().catch(e => { console.error('เริ่มระบบไม่สำเร็จ:', e); process.exit(1); });
module.exports = { start, hash: legacyHash };
