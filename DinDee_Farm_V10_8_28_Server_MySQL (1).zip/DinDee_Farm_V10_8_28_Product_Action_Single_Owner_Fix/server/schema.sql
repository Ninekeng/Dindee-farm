-- DinDee Farm — MySQL / MariaDB schema (server.js สร้างให้อัตโนมัติตอนเริ่มระบบ ไฟล์นี้ไว้อ้างอิง/สร้างเอง)
CREATE TABLE IF NOT EXISTS kv_store (
  k          VARCHAR(120) NOT NULL PRIMARY KEY,   -- ชื่อชุดข้อมูล เช่น users, orders, products
  v          LONGTEXT     NOT NULL,               -- JSON ของชุดข้อมูลนั้น
  ver        INT UNSIGNED NOT NULL DEFAULT 1,     -- เลขเวอร์ชัน ใช้ตรวจการแก้ไขชนกัน
  updated_by VARCHAR(100) NULL,
  updated_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_meta (
  k VARCHAR(120) NOT NULL PRIMARY KEY,
  v TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
