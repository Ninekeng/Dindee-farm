'use strict';
/* รหัสผ่าน: scrypt (มีใน Node ไม่ต้องติดตั้งเพิ่ม) รูปแบบ  scrypt$N$r$p$salt$hash  — ยังรับ hash แบบเก่า (FNV) เพื่อให้ผู้ใช้เดิมเข้าได้ แล้วอัปเกรดตอน login สำเร็จ */
const crypto = require('crypto');
const { promisify } = require('util');
const scryptAsync = promisify(crypto.scrypt);

const N = 16384, R = 8, P = 1, KEYLEN = 32;

/* hash แบบเก่าของแอป (ต้องเหมือน hash() ใน js/app.js) */
function legacyHash(s) { let h = 2166136261; for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return (h >>> 0).toString(16); }

const isScrypt = s => typeof s === 'string' && s.startsWith('scrypt$');

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = await scryptAsync(String(pw), salt, KEYLEN, { N, r: R, p: P });
  return ['scrypt', N, R, P, salt.toString('base64url'), key.toString('base64url')].join('$');
}
function hashPasswordSync(pw) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(String(pw), salt, KEYLEN, { N, r: R, p: P });
  return ['scrypt', N, R, P, salt.toString('base64url'), key.toString('base64url')].join('$');
}

/* คืน { ok, legacy } — legacy=true แปลว่าตรงกับ hash เก่า ควรอัปเกรด */
async function verifyPassword(pw, stored) {
  if (typeof stored !== 'string' || !stored) return { ok: false };
  if (isScrypt(stored)) {
    const [, n, r, p, salt, hash] = stored.split('$');
    const want = Buffer.from(hash || '', 'base64url');
    if (!want.length) return { ok: false };
    const got = await scryptAsync(String(pw), Buffer.from(salt, 'base64url'), want.length, { N: +n, r: +r, p: +p });
    return { ok: got.length === want.length && crypto.timingSafeEqual(got, want) };
  }
  const a = Buffer.from(legacyHash(String(pw))), b = Buffer.from(stored);
  return { ok: a.length === b.length && crypto.timingSafeEqual(a, b), legacy: true };
}

module.exports = { legacyHash, hashPassword, hashPasswordSync, verifyPassword, isScrypt };
