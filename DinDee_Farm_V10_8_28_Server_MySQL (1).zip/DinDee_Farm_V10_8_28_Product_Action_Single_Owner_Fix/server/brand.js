'use strict';
/*
 Brand/white-label: ชื่อฟาร์ม โลโก้ มาจาก config/farm.json (หรือ env) — ไม่ต้องแก้โค้ดโมดูล
 server จะแทนข้อความชื่อ "ดินดีฟาร์ม" / "DinDee Farm" ในไฟล์ .html/.js ตอนส่งให้ browser
 (ถ้า config ตรงกับค่าเริ่มต้น จะไม่แทนอะไรเลย = ไฟล์ออกไปเหมือนต้นฉบับทุกไบต์)
*/
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULTS = {
  nameTh: 'ดินดีฟาร์ม', nameEn: 'DinDee Farm',
  fullNameTh: 'ดินดีฟาร์ม ออร์แกนิก ชลบุรี', fullNameEn: 'DinDee Farm Organic Chonburi',
  shortName: 'DinDee', logoEmoji: '🌿', logoFile: '',
};
/* ห้ามอักขระที่ทำให้ string literal ใน JS/HTML พัง */
const SAFE = /^[^\\'"`$<>&{}\r\n]{1,80}$/;
const LOGO_EXT = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml' };
const ENV = { nameTh: 'FARM_NAME_TH', nameEn: 'FARM_NAME_EN', fullNameTh: 'FARM_FULL_NAME_TH', fullNameEn: 'FARM_FULL_NAME_EN', shortName: 'FARM_SHORT_NAME', logoEmoji: 'FARM_LOGO_EMOJI', logoFile: 'FARM_LOGO_FILE' };

function loadBrand(root) {
  const dir = path.resolve(process.env.FARM_CONFIG_DIR || path.join(root, 'config'));
  let file = {};
  const fp = path.join(dir, 'farm.json');
  if (fs.existsSync(fp)) {
    try { file = JSON.parse(fs.readFileSync(fp, 'utf8')); }
    catch (e) { throw new Error(`อ่าน ${fp} ไม่ได้ (JSON ผิดรูปแบบ): ${e.message}`); }
  }
  const c = { ...DEFAULTS };
  /* ถ้าตั้งแค่ nameTh/nameEn ให้ชื่อเต็ม/ชื่อสั้นตามไปด้วย แทนที่จะค้างเป็นของ DinDee */
  const given = k => (process.env[ENV[k]] || file[k] || '').toString().trim();
  for (const k of Object.keys(DEFAULTS)) { const v = given(k); if (v) c[k] = v; }
  if (!given('fullNameTh') && given('nameTh')) c.fullNameTh = c.nameTh;
  if (!given('fullNameEn') && given('nameEn')) c.fullNameEn = c.nameEn;
  if (!given('shortName') && given('nameEn')) c.shortName = c.nameEn.split(/\s+/)[0];

  for (const k of ['nameTh', 'nameEn', 'fullNameTh', 'fullNameEn', 'shortName', 'logoEmoji']) {
    if (!SAFE.test(c[k])) throw new Error(`ค่า "${k}" ใน farm.json ไม่ถูกต้อง: ต้องยาว 1-80 ตัวอักษร และห้ามมี \\ ' " \` $ < > & { }`);
  }
  let logoPath = null;
  if (c.logoFile) {
    logoPath = path.resolve(dir, c.logoFile);
    if (!logoPath.startsWith(dir + path.sep) || !LOGO_EXT[path.extname(logoPath).toLowerCase()]) throw new Error('logoFile ต้องอยู่ในโฟลเดอร์ config และเป็น .png .jpg .webp หรือ .svg');
    if (!fs.existsSync(logoPath)) throw new Error('ไม่พบไฟล์โลโก้: ' + logoPath);
  }

  const identity = Object.keys(DEFAULTS).every(k => c[k] === DEFAULTS[k]);
  const sig = crypto.createHash('sha1').update(JSON.stringify(c) + (logoPath ? fs.statSync(logoPath).mtimeMs : '')).digest('hex').slice(0, 8);

  const map = new Map([
    ['ดินดีฟาร์ม ออร์แกนิก ชลบุรี', c.fullNameTh], ['DinDee Farm Organic Chonburi', c.fullNameEn],
    ['ดินดีฟาร์ม', c.nameTh], ['DinDee Farm', c.nameEn],
  ]);
  const re = /ดินดีฟาร์ม ออร์แกนิก ชลบุรี|DinDee Farm Organic Chonburi|ดินดีฟาร์ม|DinDee Farm/g; /* ผ่านเดียว: ไม่แทนซ้ำซ้อน */
  const mark = logoPath ? '<img src="brand/logo" alt="" style="height:1.2em;vertical-align:-.2em;object-fit:contain">' : c.logoEmoji;
  const markBig = logoPath ? '<img src="brand/logo" alt="" style="height:3rem;object-fit:contain">' : c.logoEmoji;

  function transform(text, rel) {
    if (identity) return text;
    let out = text.replace(re, m => map.get(m));
    if (rel === 'index.html') {
      out = out
        .replace('<div class="farm-mark">🌿</div>', `<div class="farm-mark">${markBig}</div>`)
        .replace('<div class="brand">🌿 <span>DinDee</span></div>', `<div class="brand">${mark} <span>${c.shortName}</span></div>`);
      if (logoPath) out = out.replace('<div class="login-logo">🌱</div>', `<div class="login-logo">${markBig}</div>`);
    }
    return out;
  }
  return { config: c, identity, sig, transform, logoPath, logoType: logoPath ? LOGO_EXT[path.extname(logoPath).toLowerCase()] : null, dir };
}

module.exports = { loadBrand, DEFAULTS };
