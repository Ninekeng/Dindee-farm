'use strict';
/* Database adapter: MySQL/MariaDB (production) หรือ memory (ใช้ทดสอบ DB_DRIVER=memory) */
const fs = require('fs');
const path = require('path');

function createMysql() {
  const mysql = require('mysql2/promise');
  const pool = mysql.createPool({
    host: process.env.MYSQL_HOST || '127.0.0.1',
    port: +process.env.MYSQL_PORT || 3306,
    user: process.env.MYSQL_USER || 'dindee',
    password: process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DATABASE || 'dindee',
    waitForConnections: true,
    connectionLimit: +process.env.MYSQL_POOL || 10,
    charset: 'utf8mb4',
    timezone: 'Z',
  });
  const SCHEMA = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8')
    .split(';').map(s => s.replace(/--.*$/gm, '').trim()).filter(Boolean);

  const get = async k => {
    const [r] = await pool.execute('SELECT k,v,ver FROM kv_store WHERE k=?', [k]);
    return r[0] || null;
  };
  return {
    kind: 'mysql',
    async init() {
      for (let i = 1; ; i++) {
        try { await pool.query('SELECT 1'); break; }
        catch (e) {
          if (i >= 30) throw e;
          console.log(`[db] รอ MySQL พร้อม (${i}/30): ${e.code || e.message}`);
          await new Promise(r => setTimeout(r, 2000));
        }
      }
      for (const s of SCHEMA) await pool.query(s);
    },
    get,
    async getAll() { const [r] = await pool.query('SELECT k,v,ver FROM kv_store'); return r; },
    async versions() { const [r] = await pool.query('SELECT k,ver FROM kv_store'); return r; },
    /* base = เวอร์ชันที่ client เห็นล่าสุด; force = เขียนทับโดยไม่ตรวจเวอร์ชัน */
    async put(k, v, base, by, force) {
      if (force) {
        await pool.execute(
          'INSERT INTO kv_store(k,v,ver,updated_by) VALUES(?,?,1,?) ON DUPLICATE KEY UPDATE v=VALUES(v), ver=ver+1, updated_by=VALUES(updated_by)',
          [k, v, by]);
        return { ok: true, ver: (await get(k)).ver };
      }
      if (base != null) {
        const [r] = await pool.execute('UPDATE kv_store SET v=?, ver=ver+1, updated_by=? WHERE k=? AND ver=?', [v, by, k, base]);
        if (r.affectedRows) return { ok: true, ver: base + 1 };
      }
      const cur = await get(k);
      if (cur) return { conflict: true, ver: cur.ver, v: cur.v };
      try {
        await pool.execute('INSERT INTO kv_store(k,v,ver,updated_by) VALUES(?,?,1,?)', [k, v, by]);
        return { ok: true, ver: 1 };
      } catch (e) {
        if (e.code === 'ER_DUP_ENTRY') { const c = await get(k); return { conflict: true, ver: c.ver, v: c.v }; }
        throw e;
      }
    },
    /* read-modify-write แบบ transaction: fn(currentString|null, currentVer) -> newString | null(ไม่เปลี่ยน); throw เพื่อยกเลิก */
    async update(k, fn, by) {
      const c = await pool.getConnection();
      try {
        await c.beginTransaction();
        const [rows] = await c.execute('SELECT v,ver FROM kv_store WHERE k=? FOR UPDATE', [k]);
        const cur = rows[0];
        const nv = fn(cur ? cur.v : null, cur ? cur.ver : 0);
        if (nv == null) { await c.rollback(); return { ver: cur ? cur.ver : 0, changed: false }; }
        let ver;
        if (cur) { await c.execute('UPDATE kv_store SET v=?, ver=ver+1, updated_by=? WHERE k=?', [nv, by, k]); ver = cur.ver + 1; }
        else { await c.execute('INSERT INTO kv_store(k,v,ver,updated_by) VALUES(?,?,1,?)', [k, nv, by]); ver = 1; }
        await c.commit();
        return { ver, changed: true };
      } catch (e) { try { await c.rollback(); } catch (_) {} throw e; }
      finally { c.release(); }
    },
    /* หลาย key ใน transaction เดียว: fn({key:{v,ver}|undefined}) -> {key: newString | null(ลบ)}; throw = ยกเลิกทั้งหมด */
    async multi(keys, fn, by) {
      const ks = [...new Set(keys)].sort();
      const c = await pool.getConnection();
      try {
        await c.beginTransaction();
        const [rows] = await c.query('SELECT k,v,ver FROM kv_store WHERE k IN (?) FOR UPDATE', [ks]);
        const cur = {}; rows.forEach(r => { cur[r.k] = { v: r.v, ver: r.ver }; });
        const out = fn(cur) || {};
        const vers = {};
        for (const k of ks) {
          if (!(k in out)) continue;
          if (out[k] === null) { await c.execute('DELETE FROM kv_store WHERE k=?', [k]); continue; }
          if (cur[k]) { await c.execute('UPDATE kv_store SET v=?, ver=ver+1, updated_by=? WHERE k=?', [out[k], by, k]); vers[k] = cur[k].ver + 1; }
          else { await c.execute('INSERT INTO kv_store(k,v,ver,updated_by) VALUES(?,?,1,?)', [k, out[k], by]); vers[k] = 1; }
        }
        await c.commit();
        return { vers };
      } catch (e) { try { await c.rollback(); } catch (_) {} throw e; }
      finally { c.release(); }
    },
    async del(k) { await pool.execute('DELETE FROM kv_store WHERE k=?', [k]); },
    async delAll() { await pool.query('DELETE FROM kv_store'); },
    async getMeta(k) { const [r] = await pool.execute('SELECT v FROM app_meta WHERE k=?', [k]); return r[0] ? r[0].v : null; },
    async setMeta(k, v) { await pool.execute('INSERT INTO app_meta(k,v) VALUES(?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)', [k, v]); },
    async close() { await pool.end(); },
  };
}

function createMemory() {
  const file = process.env.DATA_FILE || '';
  const kv = new Map(), meta = new Map();
  if (file && fs.existsSync(file)) {
    try {
      const o = JSON.parse(fs.readFileSync(file, 'utf8'));
      Object.entries(o.kv || {}).forEach(([k, x]) => kv.set(k, x));
      Object.entries(o.meta || {}).forEach(([k, x]) => meta.set(k, x));
    } catch (_) {}
  }
  const persist = () => { if (file) fs.writeFileSync(file, JSON.stringify({ kv: Object.fromEntries(kv), meta: Object.fromEntries(meta) })); };
  const row = k => { const x = kv.get(k); return x ? { k, v: x.v, ver: x.ver } : null; };
  return {
    kind: 'memory',
    async init() {},
    async get(k) { return row(k); },
    async getAll() { return [...kv.keys()].map(row); },
    async versions() { return [...kv.keys()].map(k => ({ k, ver: kv.get(k).ver })); },
    async put(k, v, base, by, force) {
      const cur = kv.get(k);
      if (!force && cur && cur.ver !== base) return { conflict: true, ver: cur.ver, v: cur.v };
      const ver = cur ? cur.ver + 1 : 1;
      kv.set(k, { v, ver }); persist();
      return { ok: true, ver };
    },
    async update(k, fn) {
      const cur = kv.get(k), nv = fn(cur ? cur.v : null, cur ? cur.ver : 0);
      if (nv == null) return { ver: cur ? cur.ver : 0, changed: false };
      const ver = cur ? cur.ver + 1 : 1;
      kv.set(k, { v: nv, ver }); persist();
      return { ver, changed: true };
    },
    async multi(keys, fn) {
      const ks = [...new Set(keys)].sort();
      const cur = {}; ks.forEach(k => { const x = kv.get(k); if (x) cur[k] = { v: x.v, ver: x.ver }; });
      const out = fn(cur) || {};
      const vers = {};
      for (const k of ks) {
        if (!(k in out)) continue;
        if (out[k] === null) { kv.delete(k); continue; }
        const ver = cur[k] ? cur[k].ver + 1 : 1; kv.set(k, { v: out[k], ver }); vers[k] = ver;
      }
      persist();
      return { vers };
    },
    async del(k) { kv.delete(k); persist(); },
    async delAll() { kv.clear(); persist(); },
    async getMeta(k) { return meta.has(k) ? meta.get(k) : null; },
    async setMeta(k, v) { meta.set(k, v); persist(); },
    async close() {},
  };
}

module.exports = {
  createDb: () => (process.env.DB_DRIVER === 'memory' ? createMemory() : createMysql()),
};
