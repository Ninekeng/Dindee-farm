# DinDee Farm Management V10.1 Professional

V10.1 continues the stable architecture. Existing V9/V10 LocalStorage data remains compatible (`dindee_v7_`).

## V10.1 architecture
- Core legacy-compatible runtime: `js/app.js`
- Master data: `modules/master-data.js`
- Unified tasks/crop plan: `modules/tasks.js`
- Stock + greenhouse/area: `modules/stock-houses.js`
- Sales documents + reports: `modules/sales.js`
- System/help pages: `modules/system-pages.js`

## Engineering rule
New features are implemented as isolated modules that override only their owned page/service. Core code is not rewritten by fragile text patches.

## Validation
Run:
- `node --check js/app.js`
- `node --check modules/*.js`
- `node tests/smoke-test.js`

Open `index.html` in Chrome or Edge.
