# V10.8.17 — Flow 4 Dashboard & Transaction Center
- Fixed 6-month Sponsor series to use Sponsor received amount by month; legacy funds without a received date fall back to their earliest linked transaction date.
- New Sponsor funds store received date automatically.
- Removed Direct Cost from cash-expense KPI/trend to prevent Purchase + Usage cost double counting; Direct Cost remains available for profitability analysis.
- Dashboard Latest Transactions now shows Type, Source and Reference.
- Finance page upgraded to Transaction Center with date/type/category/source/fund/search filters and filtered summaries.
- Direct Cost is visible separately and is not included twice in cash Expense/Net.
