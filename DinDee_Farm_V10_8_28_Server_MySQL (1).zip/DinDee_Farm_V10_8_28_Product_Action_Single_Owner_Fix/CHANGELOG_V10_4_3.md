# DinDee Farm V10.4.3 Stable Fix

- Preserves V10.4.2 routes, storage namespace, menus and existing modules.
- Fixes Sponsor purchase linkage and removes double counting of Purchase + generated Expense in Sponsor totals.
- Adds Sponsor summary to Farm Dashboard and repairs six-month trend rendering/data handling.
- Stock shows Thai category meaning, per-item minimum stock, lot/expiry and warning states.
- Usage selects an exact non-expired lot and sorts lots FEFO.
- Separates `คอร์ส` from `กิจกรรม / Workshop`; both use Activity payment behavior.
- Farm Shop adds +/- quantity controls and clearer stock limits.
- Delivery option is `จัดส่ง - โทรสอบถามก่อน` with warning.
- Checkout QR slip remains attached to the first submitted order; Orders highlights `ส่งหลักฐานแล้ว — รอตรวจสอบ` and clearer customer/item blocks.
- Greenhouse list links to a per-greenhouse work/history center.
- Sales documents retain line totals and gain clearer download/print actions; print header uses full Thai/English farm name.
- V10.4.2 Today-task completion and Shop category fixes remain loaded and regression checked.
