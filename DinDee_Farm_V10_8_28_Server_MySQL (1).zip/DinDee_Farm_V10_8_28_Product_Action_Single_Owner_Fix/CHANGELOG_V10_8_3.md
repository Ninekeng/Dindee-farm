# V10.8.3 — Unified Work History Edit Popup
- Work History material column is display-only; the extra material-edit button was removed from the table.
- The Work History Edit popup now contains work details and actual material/Lot management together.
- Popup includes actual date, house/area, production cycle, task type, action, worker, status, remark, evidence and linked actual materials.
- Existing material edit/add/return logic from V10.8.0–10.8.1 is retained and opened from inside the unified popup.
- Work History management buttons are compact icon-only Edit/Delete controls.
