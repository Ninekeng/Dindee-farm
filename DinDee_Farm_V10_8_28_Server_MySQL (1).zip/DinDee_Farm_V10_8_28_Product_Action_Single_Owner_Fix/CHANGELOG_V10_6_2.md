# V10.6.2 — Monthly Date Headers & Customer History
- Monthly matrix repeats day 1–31 header under every greenhouse.
- Top monthly date header is sticky while scrolling.
- Added Customer History from Order Management.
- Existing orders are linked/migrated to customer master non-destructively.
- Customer profile stores name, phone, delivery address, note and active status.
- Customer history shows order count, total purchase amount, last purchase and detailed order history.
- Checkout enriches the customer master using phone number as duplicate key.
- Customer records with order history are deactivated rather than hard-deleted.
