# V10.8.16 — Finance Import Date & Accounting Actions
- Finance template example date is `2026-09-30` (YYYY-MM-DD).
- Finance import normalizes YYYY-MM-DD, DD/MM/YYYY, and Excel serial dates to internal YYYY-MM-DD.
- Imported finance rows therefore participate correctly in month/year Dashboard filters.
- Accounting list adds compact ✏️ Edit and 🗑️ Delete icons for Manual/Import rows.
- Auto-generated Purchase and Farm Shop accounting rows stay protected and must be changed at their source.
