# V10.8.24 — Checkout Submit & Product Action Fix
- Replaced the final checkout Save action with one direct submit path to avoid the older wrapper chain.
- Validates customer/PIN/payment slip/cart stock, saves customer PIN, creates the order, snapshots product source/cost, deducts Farm Shop quantity, and clears the cart.
- Product Catalog Edit/Delete controls are now compact icon-only actions with accessible labels/tooltips.
- Existing Farm Shop source linkage, reports, Dashboard and transaction functions remain in place.
