# V10.8.1 — Stock Movement & Test-mode Delete
- Material usage no longer requires a greenhouse: supports House, General, Learning Center/Activity, Food/Beverage, Maintenance, Project/Asset, Other.
- Usage history supports Edit, Return Stock, Cancel and Admin Hard Delete.
- Return can be partial and keeps return history.
- Cancel restores only the quantity not already returned and retains the usage record.
- Hard Delete is Admin-only, restores remaining stock before deletion, removes linked usage costs, and writes Audit.
- Settings adds a Test Mode switch for permanent usage deletion; default ON during testing.
