# V10.7.5 — Purchase Edit Tag Master Fix
- Fixed the actual cause of the empty Tag dropdown in Edit Purchase.
- TAGS is declared as a top-level `const TAGS` in app.js, not `window.TAGS`.
- Edit Purchase now uses the shared `tagOptions(category, selectedTag)` helper directly.
- Changing Category continues to rebuild the Tag dropdown from the same master.
- Excel Tag canonicalization/validation now reads the same lexical TAGS master as the web form.
