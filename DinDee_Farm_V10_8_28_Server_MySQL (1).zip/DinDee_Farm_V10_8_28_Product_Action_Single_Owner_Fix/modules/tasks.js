
'use strict';
(function(){
  function taskTypeOptions(sel=''){
    return D.taskTypes.filter(x=>x.active!==false).map(x=>`<option value="${x.id}" ${x.id===sel?'selected':''}>${esc(x.name)}</option>`).join('');
  }
  window.todayPage=function(){
    let rows=D.tasks.filter(x=>x.date<=today()&&x.status!=='Done').sort((a,b)=>a.date.localeCompare(b.date));
    content.innerHTML=`${me.role==='Admin'?`<div class="card"><h3>➕ เพิ่มงาน</h3><p class="small">งานที่เพิ่มจากหน้านี้และ “แผนปลูก + งาน” ใช้ฐานข้อมูลรายการงานเดียวกัน</p><div class="form"><div><label>รอบการผลิต</label><select id="tcycle"><option value="">-- งานทั่วไป / ไม่ผูกรอบ --</option>${D.yearPlans.map(p=>`<option value="${p.id}">${esc((D.houses.find(h=>h.id===p.houseId)||{}).name)} • ${esc(p.crop)} • ${p.start}</option>`).join('')}</select></div><div><label>วันที่</label><input id="td" type="date" value="${today()}"></div><div><label>โรงเรือน</label><select id="th">${opt(D.houses)}</select></div><div><label>ประเภทงาน</label><select id="tt">${taskTypeOptions()}</select></div><div class="span2"><label>งานที่ต้องทำ</label><input id="ta"></div><div><label>ผู้รับผิดชอบ</label><select id="towner">${responsibleOptions()}</select></div><div><label>คู่มือ</label><select id="tk">${opt(D.knowledge,'title')}</select></div><div class="span2"><label>หมายเหตุแผน</label><input id="tn"></div></div><br><button class="btn" onclick="addTask()">เพิ่มงาน</button></div>`:''}
    <div class="card"><h3>✅ งานวันนี้ / งานค้าง</h3><table><tr><th>วันที่</th><th>รอบการผลิต</th><th>โรงเรือน</th><th>ประเภท</th><th>งาน</th><th>ผู้รับผิดชอบ</th><th>สถานะ</th><th>จัดการ</th></tr>${rows.map(t=>{let p=D.yearPlans.find(x=>x.id===t.cycleId),hh=D.houses.find(x=>x.id===t.houseId)||{};return `<tr id="row_${t.id}"><td>${t.date}</td><td>${p?esc(p.crop):'งานทั่วไป'}</td><td>${esc(hh.name||'-')}</td><td>${esc(t.type||'-')}</td><td>${esc(t.action)}</td><td>${esc(ownerName(t)||'ยังไม่ระบุ')}</td><td>${t.status==='Done'?'✓ ทำแล้ว':t.date<today()?'! เลยกำหนด':'● มีแผน'}</td><td><button class="btn2" onclick="editTask('${t.id}')">✏️</button> <button class="btn2" onclick="deleteTask('${t.id}')">🗑️</button> ${t.status!=='Done'?`<button class="btn" onclick="doneTask('${t.id}')">✓ เสร็จ</button>`:''}</td></tr>`}).join('')}</table></div>`;
    if(document.getElementById('th')&&D.houses[0]) th.value=D.houses[0].id;
  };
  window.addTask=function(){
    let cycle=D.yearPlans.find(p=>p.id===tcycle.value);
    let houseId=cycle?cycle.houseId:th.value;
    if(!houseId||!ta.value.trim()||!td.value)return alert('กรอกวันที่ โรงเรือน และงานให้ครบ');
    if(cycle&&(td.value<cycle.start||td.value>cycle.end))return alert('วันที่งานต้องอยู่ในช่วงรอบการผลิต');
    let type=D.taskTypes.find(x=>x.id===tt.value);
    let x={id:id(),cycleId:cycle?.id||'',date:td.value,houseId,typeId:tt.value,type:type?.name||'',action:ta.value.trim(),ownerId:towner.value,owner:'',knowledgeId:tk.value,note:tn.value,status:'Pending',actualDate:'',actualRemark:'',actualPhoto:''};
    D.tasks.push(x);sv('tasks');logAudit('CREATE','Task',x.id,x.action);render();
  };
  window.editTask=function(i){
    let t=D.tasks.find(x=>x.id===i); if(!t)return;
    showEditModal('✏️ แก้ไขงาน',`<div class="form">
      <div><label>รอบการผลิต</label><select id="etc"><option value="">-- งานทั่วไป --</option>${D.yearPlans.map(p=>`<option value="${p.id}" ${p.id===t.cycleId?'selected':''}>${esc((D.houses.find(h=>h.id===p.houseId)||{}).name)} • ${esc(p.crop)}</option>`).join('')}</select></div>
      <div><label>วันที่</label><input id="etd" type="date" value="${t.date||''}"></div>
      <div><label>โรงเรือน</label><select id="eth">${D.houses.filter(x=>x.active!==false).map(h=>`<option value="${h.id}" ${h.id===t.houseId?'selected':''}>${esc(h.name)}</option>`).join('')}</select></div>
      <div><label>ประเภทงาน</label><select id="ett">${taskTypeOptions(t.typeId)}</select></div>
      <div class="span2"><label>รายละเอียด <button type="button" class="btn2" onclick="voiceTo('eta')">🎙️ พูด</button></label><input id="eta" value="${esc(t.action||'')}"></div>
      <div><label>ผู้รับผิดชอบ</label><select id="eto">${responsibleOptions(t.ownerId||'')}</select></div>
      <div><label>สถานะ</label><select id="ets"><option value="Pending" ${t.status!=='Done'?'selected':''}>มีแผน / รอดำเนินการ</option><option value="Done" ${t.status==='Done'?'selected':''}>ทำแล้ว</option></select></div>
      <div class="span2"><label>หมายเหตุ</label><input id="etn" value="${esc(t.note||'')}"></div></div>`,()=>{
        let p=D.yearPlans.find(x=>x.id===etc.value); if(p&&(etd.value<p.start||etd.value>p.end))return alert('วันที่งานต้องอยู่ในช่วงรอบการผลิต');
        let ty=D.taskTypes.find(x=>x.id===ett.value);
        t.cycleId=etc.value;t.date=etd.value;t.houseId=p?p.houseId:eth.value;t.typeId=ett.value;t.type=ty?.name||'';t.action=eta.value;t.ownerId=eto.value;t.owner='';t.note=etn.value;t.status=ets.value;
        sv('tasks');logAudit('EDIT','Task',i,t.action);closeEditModal();render();
      });
  };
  window.deleteTask=function(i){let t=D.tasks.find(x=>x.id===i);if(!t||!confirm('ลบงานนี้?'))return;D.tasks=D.tasks.filter(x=>x.id!==i);sv('tasks');logAudit('DELETE','Task',i,t.action);render()};
  window.openTaskModal=function(pid,tid=''){
    let p=D.yearPlans.find(x=>x.id===pid),t=tid?D.tasks.find(x=>x.id===tid):null;if(!p)return;
    let h=D.houses.find(x=>x.id===p.houseId)||{};
    showEditModal(t?'✏️ แก้ไขงานในรอบการผลิต':'➕ เพิ่มงานในรอบการผลิต',`<div class="form">
      <div><label>โรงเรือน</label><input value="${esc(h.name||'')}" disabled></div><div><label>พืช/สัตว์</label><input value="${esc(p.crop||'')}" disabled></div>
      <div><label>วันที่</label><input id="ptd" type="date" value="${t?.date||p.start}"></div><div><label>ประเภทงาน</label><select id="ptt">${taskTypeOptions(t?.typeId||'')}</select></div>
      <div class="span2"><label>รายละเอียด</label><input id="pta" value="${esc(t?.action||'')}"></div><div><label>ผู้รับผิดชอบ</label><select id="pto">${responsibleOptions(t?.ownerId||'')}</select></div>
      <div><label>วัตถุดิบ</label><select id="pts"><option value="">-- ไม่ใช้ --</option>${D.stock.map(x=>`<option value="${x.id}" ${x.id===t?.stockId?'selected':''}>${esc(x.name)}</option>`).join('')}</select></div>
      <div><label>ปริมาณแผน</label><input id="ptq" type="number" step=".01" value="${t?.planQty||''}"></div><div class="span2"><label>หมายเหตุ</label><input id="ptn" value="${esc(t?.note||'')}"></div></div>`,()=>{
        if(ptd.value<p.start||ptd.value>p.end)return alert('วันที่งานต้องอยู่ในช่วงรอบการผลิต');
        let ty=D.taskTypes.find(x=>x.id===ptt.value),data={cycleId:p.id,date:ptd.value,houseId:p.houseId,typeId:ptt.value,type:ty?.name||'',action:pta.value,ownerId:pto.value,owner:'',stockId:pts.value,planQty:+ptq.value||0,note:ptn.value};
        if(t)Object.assign(t,data);else D.tasks.push({id:id(),...data,status:'Pending',actualDate:'',actualRemark:'',actualPhoto:''});
        sv('tasks');logAudit(t?'EDIT':'CREATE','Task',t?.id||p.id,data.action);closeEditModal();render();
      });
  };
  window.year=function(){
    content.innerHTML=`${me.role==='Admin'?`<div class="card"><h3>🌱 เพิ่มรอบปลูก</h3><div class="form"><div><label>โรงเรือน</label><select id="yh">${opt(D.houses)}</select></div><div><label>ชื่อพืช/สัตว์</label><input id="yc" list="speciesListCycle" autocomplete="off" placeholder="เลือกจากรายการ หรือพิมพ์ชื่อเอง"><datalist id="speciesListCycle">${(D.species||[]).filter(x=>x.active!==false).map(x=>`<option value="${esc(x.name)}"></option>`).join('')}</datalist><div class="small">เลือกจาก Master หรือพิมพ์ชื่อใหม่ได้</div></div><div><label>วันเริ่ม</label><input id="ys" type="date"></div><div><label>วันสิ้นสุด/คาดเก็บ</label><input id="ye" type="date"></div><div><label>จำนวน</label><input id="yqty" type="number"></div><div><label>หน่วย</label><select id="yunit">${unitOptions("ต้น")}</select></div></div><br><button class="btn" onclick="addYear()">เพิ่มรอบ</button></div>`:''}
    <div class="card"><h3>🗓️ แผนปลูก + งาน</h3>${D.yearPlans.map(p=>{let h=D.houses.find(x=>x.id===p.houseId)||{},ts=D.tasks.filter(t=>t.cycleId===p.id).sort((a,b)=>a.date.localeCompare(b.date));return `<div class="groupTitle"><b>${esc(h.name)} • ${esc(p.crop)}</b> | ${p.start} → ${p.end} <button class="btn2" onclick="editPlan('${p.id}')">✏️ รอบ</button> <button class="btn" onclick="openTaskModal('${p.id}')">+ งาน</button></div><table><tr><th>วันที่</th><th>ประเภท</th><th>งาน</th><th>ผู้รับผิดชอบ</th><th>สถานะ</th><th>จัดการ</th></tr>${ts.map(t=>`<tr><td>${t.date}</td><td>${esc(t.type)}</td><td>${esc(t.action)}</td><td>${esc(ownerName(t)||'ยังไม่ระบุ')}</td><td>${t.status==='Done'?'✓ ทำแล้ว':t.date<today()?'! เลยกำหนด':'● มีแผน'}</td><td><button class="btn2" onclick="editTask('${t.id}')">✏️</button> <button class="btn2" onclick="deleteTask('${t.id}')">🗑️</button></td></tr>`).join('')||'<tr><td colspan="6">ยังไม่มีงานในรอบนี้</td></tr>'}</table>`}).join('')}</div>`;
  };
})();
