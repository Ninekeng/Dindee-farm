'use strict';
(function(){
 const cats=()=>window.DinDee.master.expenseCats;
 const units=(sel='')=>'<option value="">-- เลือกหน่วยนับ --</option>'+D.units.filter(x=>x.active!==false).map(x=>`<option value="${esc(x.name)}" ${x.name===sel?'selected':''}>${esc(x.name)}</option>`).join('');
 window.purchase=function(){
  content.innerHTML=`<div class="card"><h3>🛒 ซื้อวัตถุดิบ / เข้า Stock</h3><p class="small">Supplier เลือกจากข้อมูลเดิมหรือพิมพ์ชื่อใหม่ได้ ระบบจะเพิ่มเข้า Supplier Master ให้อัตโนมัติ</p><div class="form">
  <div><label>วันที่</label><input id="pd" type="date" value="${today()}"></div><div><label>รายการ</label><input id="pi"></div>
  <div><label>Category</label><select id="pc" onchange="ptag.innerHTML=tagOptions(pc.value)">${cats().map(x=>`<option>${x}</option>`).join('')}</select></div><div><label>Tag</label><select id="ptag"></select></div>
  <div><label>Supplier / แหล่งที่มา</label><input id="psupplier" list="supplierMasterList" placeholder="เลือกหรือพิมพ์ Supplier ใหม่" autocomplete="off"><datalist id="supplierMasterList">${supplierDatalist()}</datalist><div class="small">หากไม่มีในรายการ สามารถพิมพ์ชื่อใหม่ได้</div></div>
  <div><label>Supplier Lot</label><input id="plot"></div><div><label>จำนวน</label><input id="pq" type="number" min="0" step=".01"></div><div><label>หน่วยนับ</label><select id="pu">${units()}</select></div>
  <div><label>ยอดรวม</label><input id="pt" type="number" min="0" step=".01"></div><div><label>แหล่งเงิน</label><select id="pfund"><option value="">💚 เงินฟาร์ม</option>${D.funds.map(f=>`<option value="${f.id}">🤝 Sponsor: ${esc(f.project)}</option>`).join('')}</select></div>
  <div class="span2"><label>หลักฐาน</label><input id="pe" type="file" accept="image/*,.pdf"></div></div><br><button class="btn" onclick="addPurchase()">💾 บันทึกการซื้อ</button></div>
  <div class="card"><h3>ประวัติการซื้อ</h3><table><tr><th>วันที่</th><th>รายการ</th><th>Category / Tag</th><th>Supplier</th><th>จำนวน</th><th>ยอดรวม</th></tr>${D.purchases.slice().reverse().map(x=>`<tr><td>${x.date}</td><td>${esc(x.item)}</td><td>${esc(x.category)}<br><span class="small">${esc(x.tag||'')}</span></td><td>${esc(supplierName(x.supplierId,x.supplier)||'-')}</td><td>${x.qty} ${esc(x.unit)}</td><td>฿${money(x.total)}</td></tr>`).join('')||'<tr><td colspan="6">ยังไม่มีรายการซื้อ</td></tr>'}</table></div>`; ptag.innerHTML=tagOptions(pc.value);
 };
 window.addPurchase=function(){
  const item=pi.value.trim(),qty=Number(pq.value),total=Number(pt.value),supplier=ensureSupplier(psupplier.value);
  if(!pd.value)return alert('กรุณาเลือกวันที่'); if(!item)return alert('กรุณากรอกรายการวัตถุดิบ'); if(!(qty>0))return alert('จำนวนต้องมากกว่า 0'); if(!pu.value)return alert('กรุณาเลือกหน่วยนับจากตั้งค่าระบบ'); if(!(total>=0))return alert('กรุณากรอกยอดรวมให้ถูกต้อง');
  const x={id:id(),date:pd.value,item,category:pc.value,tag:ptag.value,supplierId:supplier?.id||'',supplier:supplier?.name||'',lot:plot.value,qty,unit:pu.value,total,fundId:pfund.value,evidence:''};
  const commit=()=>{D.purchases.push(x);sv('purchases');let s=D.stock.find(z=>z.name===x.item&&z.category===x.category&&z.unit===x.unit&&(z.lot||'')===(x.lot||'')&&(z.expiryDate||'')===(x.expiryDate||''));if(s){s.qty=(+s.qty||0)+x.qty;if(x.supplierId){s.supplierId=x.supplierId;s.supplier=x.supplier}}else D.stock.push({id:id(),category:x.category,name:x.item,qty:x.qty,unit:x.unit,supplierId:x.supplierId,supplier:x.supplier,lot:x.lot,img:'',tag:x.tag});sv('stock');D.expenses.push({id:id(),date:x.date,category:x.category,tag:x.tag,name:x.item,amount:x.total,source:'Purchase',refId:x.id,fundId:x.fundId,evidence:x.evidence});sv('expenses');logAudit('CREATE','Purchase',x.id,`${x.item} ${x.qty} ${x.unit} ฿${money(x.total)}`);alert('บันทึกการซื้อเรียบร้อย: Purchase + Stock + เงินออก');render()};
  const f=pe.files&&pe.files[0];if(f)fileData(f,d=>{x.evidence=d;commit()});else commit();
 };
})();
