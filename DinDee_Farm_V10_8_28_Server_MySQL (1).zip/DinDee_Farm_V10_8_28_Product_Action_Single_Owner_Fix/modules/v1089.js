/* DinDee Farm V10.8.9 — Flow 3 Customer UX, permissions, tracking and Analytics */
(function(){
'use strict';
const phone=x=>String(x||'').replace(/\D/g,'');
const customerByPhone=p=>D.customers.find(c=>phone(c.phone)===phone(p));

/* Customer checkout PIN: existing customer verifies old PIN; new/legacy customer sets one. */
const checkout89=window.openCheckoutV104;
window.openCheckoutV104=function(){
  const r=checkout89.apply(this,arguments), phoneEl=document.getElementById('coPhone');
  if(!phoneEl)return r;
  const host=phoneEl.closest('div');
  host.insertAdjacentHTML('afterend',`<div id="coPinBox89" class="span2 pin-box-v1089"></div>`);
  const draw=()=>{
    const box=document.getElementById('coPinBox89');if(!box)return;
    const p=phone(phoneEl.value),c=customerByPhone(p);
    if(p.length<9){box.innerHTML='<div class="small">🔐 กรอกเบอร์โทรก่อน ระบบจะแสดงการยืนยัน PIN</div>';return}
    if(c&&c.pinHash){box.innerHTML=`<div class="pin-title-v1089">🔐 พบข้อมูลลูกค้าเดิม</div><label>กรอก PIN เดิม 4 หลัก</label><input id="coPin89" type="password" inputmode="numeric" maxlength="4" autocomplete="current-password"><div class="small">ใช้ PIN เดิมเพื่อยืนยันตัวตนและเชื่อม Order กับประวัติการซื้อของคุณ</div>`}
    else {box.innerHTML=`<div class="pin-title-v1089">🔐 ${c?'บัญชีเดิมยังไม่มี PIN — ตั้ง PIN เพื่อใช้งานครั้งต่อไป':'ลูกค้าใหม่ — ตั้ง PIN 4 หลัก'}</div><div class="pin-grid-v1089"><div><label>ตั้ง PIN 4 หลัก</label><input id="coPin89" type="password" inputmode="numeric" maxlength="4" autocomplete="new-password"></div><div><label>ยืนยัน PIN</label><input id="coPinConfirm89" type="password" inputmode="numeric" maxlength="4" autocomplete="new-password"></div></div><div class="small">PIN ใช้สำหรับติดตาม Order และดูประวัติการซื้อ กรุณาจำ PIN นี้ไว้</div>`}
  };
  phoneEl.addEventListener('input',draw);draw();return r;
};
const submit89=window.submitCheckoutV104;
window.submitCheckoutV104=function(qrType){
  const p=phone(document.getElementById('coPhone')?.value),c=customerByPhone(p),pin=document.getElementById('coPin89')?.value||'',confirmPin=document.getElementById('coPinConfirm89')?.value||'';
  if(p.length>=9){
    if(c&&c.pinHash){if(!/^\d{4}$/.test(pin)||c.pinHash!==hash(pin))return alert('PIN เดิมไม่ถูกต้อง กรุณาลองอีกครั้ง')}
    else {if(!/^\d{4}$/.test(pin))return alert('PIN ต้องเป็นตัวเลข 4 หลัก');if(pin!==confirmPin)return alert('PIN ยืนยันไม่ตรงกัน')}
  }
  const r=submit89.apply(this,arguments),saved=customerByPhone(p);
  if(saved&&!saved.pinHash&&/^\d{4}$/.test(pin)){saved.pinHash=hash(pin);saved.pinCreatedAt=new Date().toISOString();sv('customers')}
  return r;
};

/* Clear order progress: completed / current / upcoming. */
window.orderCustomerCard=function(o){
 const orderSteps=['New','Accepted','Payment Submitted','Confirmed','Preparing','Packed','Shipping','Completed'];
 const labels={New:'รอฟาร์มรับ Order',Accepted:'ฟาร์มรับ Order แล้ว','Payment Submitted':'ส่งหลักฐานชำระแล้ว',Confirmed:'ยืนยันการชำระแล้ว',Preparing:'กำลังเตรียมสินค้า',Packed:'เตรียมสินค้าเรียบร้อย',Shipping:'กำลังจัดส่ง/พร้อมรับ',Completed:'สำเร็จ'};
 const current=orderSteps.indexOf(o.status),items=(o.items||[]).length?(o.items||[]).map(i=>`${esc(i.name||'-')} × ${+i.qty||0}`).join(', '):esc(D.products.find(x=>x.id===o.productId)?.name||'-');
 const progress=o.status==='Rejected'?`<div class="order-current-v1089 rejected">❌ สถานะปัจจุบัน: ${esc(statusTH[o.status]||o.status)}</div>`:`<div class="order-current-v1089">📦 สถานะปัจจุบัน: <b>${esc(labels[o.status]||statusTH[o.status]||o.status)}</b></div><div class="order-stepper-v1089">${orderSteps.map((st,i)=>`<div class="order-step-v1089 ${i<current?'past':i===current?'current':'future'}"><span>${i<current?'✓':i===current?'●':'○'}</span><small>${esc(labels[st])}</small></div>`).join('')}</div>`;
 return `<div class="customer-order-v1089"><b>${esc(o.no||'-')}</b><p>${items} • ฿${money(o.total)}</p>${customerNotice(o)}${progress}${o.status==='Accepted'?`<p><label>แนบหลักฐานการชำระเงิน</label><input id="sl_${o.id}" type="file" accept="image/*,.pdf"><button class="btn" onclick="submitPay('${o.id}')">ส่งหลักฐาน</button></p>`:''}${o.preparePhoto?`<p><b>📸 รูปสินค้าที่พนักงานเตรียม:</b><br><img class="thumb" style="width:180px;height:130px" src="${o.preparePhoto}"><br>${esc(o.remark)}</p>`:''}${historyHTML(o)}</div>`;
};

/* Separate purchase-history page; customer master remains unchanged. */
window.customerPurchaseHistoryV1089=function(){
 if(me?.role==='Customer'||me?.role==='Sponsor Viewer')return go(me.role==='Customer'?'shop':'sponsor');
 const q=String(window.customerPurchaseQ1089||'').toLowerCase(),rows=(D.orders||[]).slice().reverse().filter(o=>!q||[o.no,o.customer,o.phone,...(o.items||[]).map(i=>i.name)].join(' ').toLowerCase().includes(q));
 content.innerHTML=`<div class="pageHero"><div><span class="eyebrow">CUSTOMER PURCHASE HISTORY</span><h2>🧾 ประวัติการซื้อของลูกค้า</h2><p>ค้นหา Order ย้อนหลังตามลูกค้า เบอร์โทร Order หรือสินค้า</p></div><div class="heroActions"><button class="btn2" onclick="go('customers')">👥 ฐานข้อมูลลูกค้า</button><button class="btn2" onclick="go('orders')">📦 Orders</button></div></div><div class="card"><input style="max-width:520px" placeholder="🔎 ค้นหาชื่อ / เบอร์ / Order / สินค้า" value="${esc(window.customerPurchaseQ1089||'')}" oninput="window.customerPurchaseQ1089=this.value;customerPurchaseHistoryV1089()"><div class="tableWrap"><table><tr><th>Order</th><th>วันที่</th><th>ลูกค้า</th><th>สินค้า</th><th>ยอด</th><th>สถานะ</th></tr>${rows.map(o=>`<tr><td><b>${esc(o.no||'-')}</b></td><td>${esc(o.created||'-')}</td><td>${esc(o.customer||'-')}<br><span class="small">${esc(o.phone||'-')}</span></td><td>${(o.items||[]).map(i=>`${esc(i.name||'-')} × ${+i.qty||0}`).join('<br>')||esc(D.products.find(p=>p.id===o.productId)?.name||'-')}</td><td>฿${money(o.total)}</td><td>${statusBadge(o.status)}</td></tr>`).join('')||'<tr><td colspan="6">ยังไม่มีประวัติการซื้อ</td></tr>'}</table></div></div>`;
};

/* Farm Analytics entry point: avoid the old brittle post-render DOM assertion. */
window.openFarmAnalyticsV1089=function(){
 try{if(typeof window.farmAnalyticsV1045!=='function')throw new Error('ไม่พบ Farm Analytics');window.farmAnalyticsV1045();window.scrollTo({top:0,behavior:'smooth'})}
 catch(e){console.error('Farm Analytics',e);alert('ไม่สามารถเปิด Farm Analytics: '+(e.message||e))}
};
const dash89=window.dashboard;
window.dashboard=function(){const r=dash89.apply(this,arguments);document.querySelectorAll('.analyticsOpenV1045').forEach(b=>{b.setAttribute('onclick','openFarmAnalyticsV1089()');b.textContent='ดูรายละเอียดและวิเคราะห์ฟาร์ม →'});return r};
})();
