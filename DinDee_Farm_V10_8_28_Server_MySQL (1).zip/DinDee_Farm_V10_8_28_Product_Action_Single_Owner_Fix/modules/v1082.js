/* DinDee Farm V10.8.2 — Shop Category Delete */
(function(){
'use strict';
window.deleteShopCatV1082=function(cid){
 const c=D.shopCategories.find(x=>x.id===cid);if(!c)return;
 const products=(D.products||[]).filter(p=>p.categoryId===cid);
 if(products.length){
   return alert(`ยังลบหมวด “${c.name}” ไม่ได้\nมีสินค้า/บริการเชื่อมอยู่ ${products.length} รายการ\n\nกรุณาย้ายสินค้าไปหมวดอื่นก่อน หรือใช้ปุ่ม ⏸ ปิดใช้งาน`);
 }
 if(!confirm(`ยืนยันลบหมวด “${c.name}” ?\n\nIncome Mapping ของหมวดนี้จะถูกลบด้วย แต่ไม่กระทบประวัติรายได้/Order ที่บันทึกไว้แล้ว`))return;
 D.shopCategories=D.shopCategories.filter(x=>x.id!==cid);sv('shopCategories');logAudit('DELETE','Shop Category',cid,c.name);closeEditModal();manageShopCats();
};
const oldManage=window.manageShopCats;
window.manageShopCats=function(){
 oldManage();
 const modal=document.querySelector('.modal,.modalBox,.editModal')||document.body;
 const rows=[...modal.querySelectorAll('table tr')].slice(1);
 const cats=D.shopCategories.slice().sort((a,b)=>(a.sort||0)-(b.sort||0));
 rows.forEach((tr,i)=>{
   const c=cats[i];if(!c)return;
   const td=tr.lastElementChild;if(!td||td.querySelector('[data-v1082-delete]'))return;
   td.insertAdjacentHTML('beforeend',`<button type="button" class="btn2 dangerBtn purchase-icon-btn" data-v1082-delete title="ลบหมวดสินค้า" onclick="deleteShopCatV1082('${c.id}')">🗑️</button>`);
 });
};
})();
