/* DinDee Farm V10.8.12 — Sales menu order + reliable Farm Shop cart entry */
(function(){
'use strict';

/* Use one reliable cart entry point. Capture phase prevents stale inline handlers
   from blocking the active V10.8.11 cart implementation. */
function openActiveCartV10812(){
  if(typeof window.openCartV1043==='function') return window.openCartV1043();
  if(typeof window.openCartV104==='function') return window.openCartV104();
  alert('ไม่สามารถเปิดตะกร้าได้ กรุณารีเฟรชหน้าแล้วลองอีกครั้ง');
}
window.openActiveCartV10812=openActiveCartV10812;
document.addEventListener('click',function(e){
  const btn=e.target&&e.target.closest?e.target.closest('.cartButton'):null;
  if(!btn)return;
  e.preventDefault();
  e.stopImmediatePropagation();
  openActiveCartV10812();
},true);

/* Keep the visible badge synchronized whenever the shop page is rendered. */
const shop10812=window.shop;
window.shop=function(){
  const r=shop10812.apply(this,arguments);
  if(typeof window.refreshCartBadgeV10811==='function')window.refreshCartBadgeV10811();
  return r;
};
})();
