/* DinDee Farm V10.8.4 — reliable Shop Category delete button */
(function(){
'use strict';
window.manageShopCats=function(){
 const rows=D.shopCategories.slice().sort((a,b)=>(a.sort||0)-(b.sort||0));
 showEditModal('หมวดหมู่สินค้า + Income Mapping',`<div class="helpbox">Master กลาง: หมวดร้านค้า → Income Category → Income Tag → Dashboard</div>
 <div class="tableWrap"><table><tr><th>หมวดร้านค้า</th><th>Income Category</th><th>Income Tag</th><th>สถานะ</th><th>จัดการ</th></tr>
 ${rows.map(c=>`<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.incomeCategory||'-')}</td><td>${esc(c.incomeTag||'-')}</td><td>${c.active!==false?'ใช้งาน':'ปิด'}</td><td class="shopcat-actions-v1084"><button type="button" class="btn2 purchase-icon-btn" title="แก้ไข Mapping" onclick="editShopCatMapV1078('${c.id}')">✏️</button><button type="button" class="btn2 purchase-icon-btn" title="${c.active!==false?'ปิด':'เปิด'}ใช้งาน" onclick="toggleShopCatV1042('${c.id}')">${c.active!==false?'⏸':'▶'}</button><button type="button" class="btn2 dangerBtn purchase-icon-btn" title="ลบหมวดสินค้า" onclick="deleteShopCatV1082('${c.id}')">🗑️</button></td></tr>`).join('')}</table></div>
 <div class="form"><div class="span2"><label>เพิ่มหมวดร้านค้าใหม่</label><input id="newShopCat" placeholder="ชื่อหมวดหมู่"></div></div>`,()=>{
   const n=newShopCat.value.trim();if(n){if(D.shopCategories.some(c=>String(c.name).toLowerCase()===n.toLowerCase()))return alert('มีหมวดหมู่นี้อยู่แล้ว');D.shopCategories.push({id:'cat-'+Date.now().toString(36),name:n,active:true,sort:D.shopCategories.length+1,incomeCategory:'Farm Product Sales',incomeTag:''});sv('shopCategories')}
   closeEditModal();shopadmin();
 });
};
})();
