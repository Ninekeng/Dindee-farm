/* DinDee Farm V10.5.7 - Settings/User management + UI clarity */
(function(){
'use strict';
const admin=()=>{try{return typeof me!=='undefined'&&!!me&&me.role==='Admin'}catch(e){return false}};
const save=k=>typeof sv==='function'&&sv(k);
const audit=(a,t,i,d)=>typeof logAudit==='function'&&logAudit(a,t,i,d||'');

function masterRefs(k,i){
 const checks={
  areaTypes:()=>[], // area type IDs are master metadata; historical houses retain their own type values
  taskTypes:()=>D.tasks.filter(x=>x.typeId===i),
  species:()=>D.yearPlans.filter(x=>x.speciesId===i),
  units:()=>[...D.stock,...D.purchases,...D.usages,...D.harvests].filter(x=>x.unitId===i),
  suppliers:()=>D.purchases.filter(x=>x.supplierId===i)
 };
 try{return (checks[k]?checks[k]():[])}catch(e){return []}
}
window.editMasterV1057=function(k,i){
 if(!admin())return alert('เฉพาะ Admin เท่านั้น');
 const x=(D[k]||[]).find(y=>y.id===i);if(!x)return;
 showEditModal('✏️ แก้ไขข้อมูลหลัก',`<div class="form"><div class="span2"><label>ชื่อ</label><input id="m57name" value="${esc(x.name||'')}"></div><div><label>สถานะ</label><select id="m57active"><option value="1" ${x.active!==false?'selected':''}>ใช้งาน</option><option value="0" ${x.active===false?'selected':''}>ปิดใช้งาน</option></select></div></div>`,()=>{
   const n=m57name.value.trim();if(!n)return alert('กรุณากรอกชื่อ');
   x.name=n;x.active=m57active.value==='1';save(k);audit('EDIT','Master '+k,i,n);closeEditModal();render();
 });
};
window.deleteMasterV1057=function(k,i){
 if(!admin())return alert('เฉพาะ Admin เท่านั้น');
 const x=(D[k]||[]).find(y=>y.id===i);if(!x)return;
 const refs=masterRefs(k,i);
 if(refs.length){
   if(!confirm(`“${x.name}” ถูกใช้งานแล้ว ${refs.length} รายการ\nเพื่อรักษาประวัติ ระบบจะปิดใช้งานแทนการลบถาวร\n\nยืนยันหรือไม่?`))return;
   x.active=false;save(k);audit('DEACTIVATE','Master '+k,i,x.name);render();return;
 }
 if(!confirm(`ยืนยันลบ “${x.name}” ออกจากข้อมูลหลักถาวร?`))return;
 D[k]=D[k].filter(y=>y.id!==i);save(k);audit('DELETE','Master '+k,i,x.name);render();
};
window.settings=function(){
 normalizeMasters();
 const box=(title,k,ph)=>{
   const rows=(D[k]||[]).map(x=>`<tr><td><div class="master-name">${esc(x.name)}</div></td><td><span class="status-chip ${x.active!==false?'is-on':'is-off'}">${x.active!==false?'● ใช้งาน':'○ ปิดใช้งาน'}</span></td><td class="action-cell"><button class="btn2" onclick="editMasterV1057('${k}','${x.id}')">✏️ แก้ไข</button><button class="btn2 dangerBtn" onclick="deleteMasterV1057('${k}','${x.id}')">🗑️ ลบ</button><button class="btn2 compact" onclick="toggleMaster('${k}','${x.id}')">${x.active!==false?'ปิด':'เปิด'}</button></td></tr>`).join('');
   return `<div class="card settings-card"><div class="settings-head"><h3>${title}</h3><span class="pill">${(D[k]||[]).length} รายการ</span></div><div class="add-master-row"><input id="new_${k}" placeholder="${ph}"><button class="btn" onclick="addMaster('${k}')">＋ เพิ่ม</button></div><div class="tableWrap"><table class="clean-table"><tr><th>ชื่อ</th><th>สถานะ</th><th>จัดการ</th></tr>${rows||'<tr><td colspan="3" class="muted">ยังไม่มีข้อมูล</td></tr>'}</table></div></div>`;
 };
 content.innerHTML=`<div class="pageHero settings-hero"><div><span class="eyebrow">SYSTEM MASTER DATA</span><h2>⚙️ ตั้งค่าระบบ / ข้อมูลหลัก</h2><p>จัดการข้อมูลกลางที่ใช้ร่วมกันทั้งระบบ • แก้ไข / ลบ / ปิดใช้งานได้จากแต่ละรายการ</p></div></div>
 <div class="settings-grid">${box('🏡 ประเภทโรง / พื้นที่','areaTypes','เช่น บ่อปลา')}${box('🧰 ประเภทงาน','taskTypes','เช่น ให้อาหารสัตว์')}${box('🌱 ชนิดพืช / สัตว์','species','เช่น เคล / ไก่ไข่')}${box('📏 หน่วยนับ','units','เช่น ฟอง')}${box('🚚 Supplier / แหล่งวัตถุดิบ','suppliers','ชื่อผู้ขาย')}</div>
 <div class="card dangerbox"><h3>♻️ Reset ระบบ</h3><p class="muted">ใช้เฉพาะเมื่อต้องการล้างข้อมูลทดลอง ควร Export / Backup ก่อนทุกครั้ง</p><button class="btn2" onclick="resetTransactions()">ล้างข้อมูล Transaction ทดลอง</button> <button class="btn2 dangerBtn" onclick="factoryReset()">⚠️ Factory Reset ทั้งระบบ</button></div>`;
};

window.editUserV1057=function(uid){
 if(!admin())return alert('เฉพาะ Admin เท่านั้น');
 const u=D.users.find(x=>x.id===uid);if(!u)return;
 showEditModal('✏️ แก้ไขผู้ใช้งาน',`<div class="form"><div><label>Username</label><input id="u57name" value="${esc(u.user||'')}"></div><div><label>สิทธิ์</label><select id="u57role">${['Admin','Staff','Customer','Sponsor Viewer'].map(r=>`<option ${u.role===r?'selected':''}>${r}</option>`).join('')}</select></div></div>`,()=>{
  const name=u57name.value.trim();if(!name)return alert('กรุณากรอก Username');
  if(D.users.some(x=>x.id!==uid&&(x.user||'').toLowerCase()===name.toLowerCase()))return alert('Username นี้มีอยู่แล้ว');
  if(u.id===me.id&&u57role.value!=='Admin')return alert('ไม่สามารถลดสิทธิ์ Admin ของบัญชีที่กำลังใช้งานอยู่');
  u.user=name;u.role=u57role.value;save('users');audit('EDIT','User',uid,`${name} • ${u.role}`);closeEditModal();render();
 });
};
window.changeUserPasswordV1057=function(uid){
 if(!admin())return alert('เฉพาะ Admin เท่านั้น');
 const u=D.users.find(x=>x.id===uid);if(!u)return;
 showEditModal('🔑 เปลี่ยนรหัสผ่าน',`<div class="form"><div><label>Username</label><input value="${esc(u.user)}" disabled></div><div><label>Password ใหม่</label><input id="u57pass" type="text" value="${esc(u.plainPass||'')}"></div></div>`,()=>{
  const p=u57pass.value.trim();if(!p)return alert('กรุณากรอก Password');
  u.pass=hash(p);u.plainPass=p;save('users');audit('EDIT','User Password',uid,u.user);closeEditModal();render();
 });
};
window.changeUserRoleV1057=function(uid){
 if(!admin())return alert('เฉพาะ Admin เท่านั้น');
 const u=D.users.find(x=>x.id===uid);if(!u)return;
 showEditModal('🛡️ เปลี่ยนสิทธิ์ผู้ใช้งาน',`<div class="form"><div><label>Username</label><input value="${esc(u.user)}" disabled></div><div><label>Role</label><select id="u57roleonly">${['Admin','Staff','Customer','Sponsor Viewer'].map(r=>`<option ${u.role===r?'selected':''}>${r}</option>`).join('')}</select></div></div>`,()=>{
  if(u.id===me.id&&u57roleonly.value!=='Admin')return alert('ไม่สามารถลดสิทธิ์ Admin ของบัญชีที่กำลังใช้งานอยู่');
  u.role=u57roleonly.value;save('users');audit('EDIT','User Role',uid,`${u.user} • ${u.role}`);closeEditModal();render();
 });
};
window.deleteUserV1057=function(uid){
 if(!admin())return alert('เฉพาะ Admin เท่านั้น');
 const u=D.users.find(x=>x.id===uid);if(!u)return;
 if(u.id===me.id)return alert('ไม่สามารถลบบัญชีที่กำลัง Login อยู่');
 if(u.role==='Admin'&&D.users.filter(x=>x.role==='Admin').length<=1)return alert('ระบบต้องมี Admin อย่างน้อย 1 บัญชี');
 if(!confirm(`ยืนยันลบผู้ใช้งาน “${u.user}” ?`))return;
 D.users=D.users.filter(x=>x.id!==uid);save('users');audit('DELETE','User',uid,u.user);render();
};
window.users=function(){
 if(!admin())return;
 content.innerHTML=`<div class="pageHero users-hero"><div><span class="eyebrow">USER & ACCESS CONTROL</span><h2>👥 จัดการผู้ใช้งาน</h2><p>จัดการ Username • Password • สิทธิ์การใช้งาน และบัญชีผู้ใช้จากจุดเดียว</p></div></div>
 <div class="card user-add-card"><h3>＋ เพิ่มผู้ใช้งาน</h3><div class="form"><div><label>Username</label><input id="uu"></div><div><label>Password</label><input id="up" placeholder="Password"></div><div><label>Role</label><select id="ur"><option>Staff</option><option>Customer</option><option>Sponsor Viewer</option><option>Admin</option></select></div></div><br><button class="btn" onclick="addUser()">＋ เพิ่ม User</button></div>
 <div class="card"><div class="settings-head"><h3>รายชื่อผู้ใช้งาน</h3><span class="pill">${D.users.length} บัญชี</span></div><div class="tableWrap"><table class="clean-table users-table"><tr><th>User</th><th>Password</th><th>Role</th><th>จัดการ</th></tr>${D.users.map(u=>`<tr><td><div class="user-name">👤 <b>${esc(u.user)}</b>${u.id===me.id?'<span class="you-chip">บัญชีนี้</span>':''}</div></td><td><code class="pass-chip">${esc(u.plainPass||'••••••')}</code></td><td><span class="role-chip role-${String(u.role).toLowerCase().replace(/\s+/g,'-')}">${esc(u.role)}</span></td><td class="action-cell user-actions"><button class="btn2" onclick="editUserV1057('${u.id}')">✏️ แก้ไข</button><button class="btn2" onclick="changeUserPasswordV1057('${u.id}')">🔑 รหัส</button><button class="btn2" onclick="changeUserRoleV1057('${u.id}')">🛡️ สิทธิ์</button><button class="btn2 dangerBtn" onclick="deleteUserV1057('${u.id}')">🗑️ ลบ</button></td></tr>`).join('')}</table></div><div class="helpbox small">ระบบต้นแบบยังแสดง Password สำหรับ Admin ตามรูปแบบเดิม เมื่อใช้งานออนไลน์จริงควรใช้ Password Reset และเก็บเฉพาะ Hash</div></div>`;
};
})();
