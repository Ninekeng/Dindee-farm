/* DinDee Farm V10.6.3 - Reliable Notification Center */
(function(){
'use strict';
const num=v=>Number(v)||0;
const house=id=>(D.houses.find(h=>h.id===id)||{}).name||'-';
const plusDays=(d,n)=>{const x=new Date(d+'T12:00:00');x.setDate(x.getDate()+n);return x.toISOString().slice(0,10)};
const realExp=()=> (D.expenses||[]).filter(e=>e.source!=='Purchase');
window.alertsData=function(){
 const now=today(),a=[];
 (D.tasks||[]).forEach(t=>{try{if(t.status!=='Done'&&t.date&&t.date<=now)a.push({kind:'task',level:t.date<now?'bad':'warn',text:`${t.date<now?'เลยกำหนด':'ถึงกำหนด'}: ${t.action||t.type||'งาน'} • ${house(t.houseId)}`,id:t.id})}catch(e){}});
 (D.orders||[]).forEach(o=>{try{if(['New','Payment Submitted'].includes(o.status))a.push({kind:'order',level:'warn',text:`Order ${o.no||o.id} • ${o.status==='Payment Submitted'?'ส่งหลักฐานแล้ว รอตรวจสอบ':'Order ใหม่'}`,id:o.id})}catch(e){}});
 (D.stock||[]).forEach(s=>{try{const q=num(s.qty),min=num(s.minStock);if(s.active!==false&&!s.archived&&q<=0)a.push({kind:'stock',level:'bad',text:`Stock หมด: ${s.name} • Lot ${s.lot||'-'}`,id:s.id});else if(s.active!==false&&!s.archived&&min>0&&q<=min)a.push({kind:'stock',level:'warn',text:`Stock ต่ำ: ${s.name} • Lot ${s.lot||'-'} เหลือ ${q} ${s.unit||''}`,id:s.id});if(s.active!==false&&!s.archived&&s.expiryDate&&q>0&&s.expiryDate<=plusDays(now,30))a.push({kind:'stock',level:s.expiryDate<now?'bad':'warn',text:`${s.expiryDate<now?'หมดอายุ':'ใกล้หมดอายุ'}: ${s.name} • ${s.expiryDate}`,id:s.id})}catch(e){}});
 (D.funds||[]).forEach(f=>{try{if(f.active===false)return;const used=(D.purchases||[]).filter(p=>p.fundId===f.id).reduce((q,x)=>q+num(x.total),0)+realExp().filter(e=>e.fundId===f.id).reduce((q,x)=>q+num(x.amount),0);if(num(f.amount)>0&&(num(f.amount)-used)/num(f.amount)<=.15)a.push({kind:'sponsor',level:'warn',text:`Sponsor ใกล้หมด: ${f.project||f.sponsor||'-'} • คงเหลือ ฿${money(num(f.amount)-used)}`,id:f.id})}catch(e){}});
 return a;
};
let bellLast=-1;
window.updateBell=function(){let list=[];try{list=window.alertsData()}catch(e){console.error('Notification engine',e)}const n=list.length,b=document.getElementById('bellCount'),side=document.getElementById('sideAlert');if(b){b.textContent=n;b.classList.toggle('hidden',n===0)}if(side)side.innerHTML=n?`<span class="badge">${n}</span>`:'';if(bellLast>=0&&n>bellLast)try{beep()}catch(e){}bellLast=n;return n};
window.alertRows=function(){const a=window.alertsData(),label={task:'งานฟาร์ม',order:'Order',stock:'Stock',sponsor:'Sponsor'};return a.length?`<table><tr><th>ประเภท</th><th>รายการ</th></tr>${a.map(x=>`<tr style="cursor:pointer" onclick="jumpAlert('${x.kind}','${x.id}')"><td><span class="pill ${x.level}">${label[x.kind]||x.kind}</span></td><td>${esc(x.text)} <span class="small">→ เปิดรายการ</span></td></tr>`).join('')}</table>`:'ไม่มีรายการแจ้งเตือน'};
window.alerts=function(){content.innerHTML=`<div class="pageHero"><div><span class="eyebrow">NOTIFICATION CENTER</span><h2>🔔 การแจ้งเตือน</h2><p>งานถึงกำหนด/เลยกำหนด • Order ใหม่/ส่งหลักฐาน • Stock ต่ำ/หมด/ใกล้หมดอายุ • Sponsor ใกล้หมด</p></div><div><button class="btn2" onclick="soundOn=!soundOn;this.textContent=soundOn?'🔊 เสียงเปิด':'🔇 เสียงปิด'">${soundOn?'🔊 เสียงเปิด':'🔇 เสียงปิด'}</button></div></div><div class="card">${window.alertRows()}</div>`;window.updateBell()};
const oldJump=window.jumpAlert;window.jumpAlert=function(kind,id){if(kind==='stock'){page='stock';render();return}if(kind==='sponsor'){page='sponsor';render();if(typeof sponsorDrillV105==='function')setTimeout(()=>sponsorDrillV105(id),100);return}if(typeof oldJump==='function')return oldJump(kind,id)};
const render63=window.render;window.render=function(){const r=render63.apply(this,arguments);setTimeout(()=>window.updateBell(),0);return r};
setInterval(()=>{const app=document.getElementById('app');if(app&&!app.classList.contains('hidden'))window.updateBell()},30000);
window.addEventListener('focus',()=>setTimeout(()=>window.updateBell(),0));
})();
