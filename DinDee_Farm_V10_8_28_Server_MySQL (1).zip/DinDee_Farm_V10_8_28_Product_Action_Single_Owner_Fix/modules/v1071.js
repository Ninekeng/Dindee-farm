/* DinDee Farm V10.7.1 — Species master confirmation */
(function(){
'use strict';
window.ensureSpeciesMasterV1071=function(name){
 name=String(name||'').trim();if(!name)return false;
 D.species=D.species||[];
 const exists=D.species.some(x=>String(x.name||'').trim().toLocaleLowerCase('th-TH')===name.toLocaleLowerCase('th-TH'));
 if(exists)return false;
 if(confirm(`"${name}" ยังไม่มีใน Master ชนิดพืช / สัตว์\n\nต้องการเพิ่มเข้า Master เพื่อใช้เลือกในครั้งต่อไปหรือไม่?`)){
   D.species.push({id:'sp'+Date.now().toString(36)+Math.random().toString(36).slice(2,5),name,active:true});
   sv('species');
   if(typeof logAudit==='function')logAudit('CREATE','Species','',name);
   return true;
 }
 return false;
};
})();
