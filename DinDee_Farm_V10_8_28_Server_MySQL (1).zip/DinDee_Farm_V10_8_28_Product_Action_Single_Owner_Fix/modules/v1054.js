/* DinDee Farm V10.5.4 - Visible delete actions on actual list pages */
(function(){
'use strict';
function admin(){try{return typeof me!=='undefined'&&!!me&&me.role==='Admin'}catch(e){return false}}
function addAfterEdit(prefix,delFn,cls){
 if(!admin())return;
 document.querySelectorAll('#content button[onclick^="'+prefix+'"]').forEach(function(b){
  const cell=b.closest('td')||b.parentElement;if(!cell||cell.querySelector('.'+cls))return;
  const m=(b.getAttribute('onclick')||'').match(/\('([^']+)'\)/);if(!m)return;
  const d=document.createElement('button');d.type='button';d.className='btn2 dangerBtn '+cls;d.textContent='🗑️ ลบ';
  d.onclick=function(){if(typeof window[delFn]==='function')window[delFn](m[1]);else alert('ไม่พบฟังก์ชันลบ');};
  b.insertAdjacentElement('afterend',d);
 });
}
function pass(){
 addAfterEdit('editPlan(', 'deletePlan','v1054-del-cycle');
 addAfterEdit('editHouseV101(', 'deleteHouseV1051','v1054-del-house');
 addAfterEdit('editStockV1043(', 'deleteStockV1052','v1054-del-stock');
 addAfterEdit('editStockV101(', 'deleteStockV1052','v1054-del-stock');
 addAfterEdit('editStock(', 'deleteStockV1052','v1054-del-stock');
 addAfterEdit('editProduct(', 'deleteProductV1052','v1054-del-product');
 addAfterEdit('editSalesDoc(', 'deleteSalesDocV1051','v1054-del-sales');
 addAfterEdit('editFund(', 'deleteFundV1051','v1054-del-fund');
}
['year','cycles','houses','stock','shopadmin','salesDocsPage','sponsor'].forEach(function(name){
 const old=window[name];if(typeof old!=='function')return;
 window[name]=function(){const r=old.apply(this,arguments);pass();setTimeout(pass,0);return r;};
});
const oldRender=window.render;if(typeof oldRender==='function')window.render=function(){const r=oldRender.apply(this,arguments);pass();setTimeout(pass,0);return r;};
})();
