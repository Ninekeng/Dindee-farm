'use strict';
/* DinDee Farm V10.8.18 — Dashboard 6-month chart: Income / Expense / Net */
(function(){
 const num=v=>Number(v)||0;
 const realExpenses=()=> (D.expenses||[]).filter(e=>e.source!=='Purchase');
 const cashExpenseRows=()=>[...realExpenses(),...(D.purchases||[]).map(x=>({...x,amount:num(x.total),source:'Purchase',name:x.item||x.name}))];
 const operatingIncomeRows=()=>D.income||[];
 window.sixMonthChart=function(){
   const now=new Date(),rows=[];
   for(let i=5;i>=0;i--){
     const d=new Date(now.getFullYear(),now.getMonth()-i,1),key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
     const inc=operatingIncomeRows().filter(x=>(x.date||'').startsWith(key)).reduce((a,x)=>a+num(x.amount??x.total),0);
     const ex=cashExpenseRows().filter(x=>(x.date||'').startsWith(key)).reduce((a,x)=>a+num(x.amount??x.total),0);
     rows.push({label:d.toLocaleDateString('th-TH',{month:'short'}),inc,ex,net:inc-ex});
   }
   const mx=Math.max(1,...rows.flatMap(x=>[x.inc,x.ex,Math.abs(x.net)]));
   const h=v=>Math.max(v===0?0:2,Math.abs(v)/mx*78);
   return `<div class="trendLegend v10818-legend"><span>■ รายรับ</span><span>■ รายจ่าย</span><span>■ กำไรสุทธิ (Net)</span></div><div class="trend6-v10818">${rows.map(x=>`<div class="trendCol-v10818"><div class="trendPlot-v10818"><div class="trendZero-v10818"></div><i class="income" title="รายรับ ฿${money(x.inc)}" style="height:${h(x.inc)}px"></i><i class="expense" title="รายจ่าย ฿${money(x.ex)}" style="height:${h(x.ex)}px"></i><i class="net ${x.net<0?'negative':'positive'}" title="กำไรสุทธิ (Net) ฿${money(x.net)}" style="height:${h(x.net)}px"></i></div><b>${x.label}</b><small class="${x.net<0?'net-negative-v10818':'net-positive-v10818'}">Net ${x.net>=0?'+':''}${money(x.net)}</small><div class="trend-values-v10818">รายรับ ${money(x.inc)}<br>รายจ่าย ${money(x.ex)}</div></div>`).join('')}</div><div class="small muted">Net = รายรับ − รายจ่าย • Sponsor แยกแสดงในส่วนเงินสนับสนุนและไม่รวมในกราฟผลการดำเนินงาน • ต้นทุนทางตรงไม่ถูกนับเป็นรายจ่ายเงินสดซ้ำ</div>`;
 };
})();
