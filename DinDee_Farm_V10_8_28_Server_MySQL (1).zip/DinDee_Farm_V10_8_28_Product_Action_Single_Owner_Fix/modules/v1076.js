/* DinDee Farm V10.7.6 — Shop categories: Course/Workshop vs Activity */
(function(){
'use strict';
function norm(s){return String(s||'').trim().toLocaleLowerCase('th-TH')}
function ensureCat(id,name,sort){
 let c=(D.shopCategories||[]).find(x=>x.id===id)||D.shopCategories.find(x=>norm(x.name)===norm(name));
 if(!c){c={id,name,active:true,sort};D.shopCategories.push(c)}
 c.name=name;c.active=true;c.sort=sort;return c;
}
function migrateShopSplitV1076(){
 D.shopCategories=D.shopCategories||[];
 const course=ensureCat('cat-course','คอร์ส / Workshop',7);
 const activity=ensureCat('cat-activity','กิจกรรม',8);
 D.shopCategories.forEach(c=>{
   const n=norm(c.name);
   if(c.id!==course.id&&c.id!==activity.id&&(/คอร์ส\s*\/\s*กิจกรรม/.test(n)||n==='คอร์ส'||n==='กิจกรรม / workshop'))c.active=false;
 });
 (D.products||[]).forEach(p=>{
   const n=norm(p.category),cid=p.categoryId;
   if(cid===course.id||n==='คอร์ส'||n==='คอร์ส / workshop'||/คอร์ส\s*\/\s*กิจกรรม/.test(n)){
     p.categoryId=course.id;p.category=course.name;
   }else if(cid===activity.id||n==='กิจกรรม'||n==='กิจกรรม / workshop'){
     p.categoryId=activity.id;p.category=activity.name;
     if(n==='กิจกรรม / workshop')p.categoryReview=true; // old combined category: admin can move Workshop items to Course/Workshop.
   }
 });
 sv('shopCategories');sv('products');
}
migrateShopSplitV1076();

/* Keep category labels stable whenever Shop/Admin is opened, even if an older module ran first. */
const oldShopAdmin=window.shopadmin;
window.shopadmin=function(){migrateShopSplitV1076();oldShopAdmin()};
const oldShop=window.shop;
window.shop=function(){migrateShopSplitV1076();oldShop()};

/* Both Course/Workshop and Activity are learning-center services and continue to use Activity QR. */
window.isLearningShopCategoryV1076=function(p){
 const c=(D.shopCategories||[]).find(x=>x.id===p?.categoryId)?.name||p?.category||'';
 return /คอร์ส|workshop|กิจกรรม/i.test(c);
};
})();
