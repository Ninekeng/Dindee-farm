'use strict';
/* DinDee Farm V10.8.19 — Dashboard readability: stack Profit and Latest Transactions full-width */
(function(){
  const previousDashboard=window.dashboard;
  if(typeof previousDashboard!=='function') return;

  function improveDashboardLayout(){
    const grids=[...document.querySelectorAll('#content .grid2')];
    const target=grids.find(grid=>{
      const text=grid.textContent||'';
      return text.includes('กำไรตามสินค้า / ผลผลิต') && text.includes('รายการล่าสุด');
    });
    if(!target) return;
    target.classList.add('dashboard-stack-v10819');
    const cards=[...target.children].filter(el=>el.classList&&el.classList.contains('card'));
    cards.forEach(card=>card.classList.add('dashboard-full-card-v10819'));
  }

  window.dashboard=function(){
    const result=previousDashboard.apply(this,arguments);
    improveDashboardLayout();
    return result;
  };
})();
