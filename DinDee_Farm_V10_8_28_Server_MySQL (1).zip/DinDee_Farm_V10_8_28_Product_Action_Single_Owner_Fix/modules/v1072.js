/* DinDee Farm V10.7.2 — monthly dates, purchase dashboard/history, Excel round-trip */
(function(){
'use strict';
const n=v=>Number(v||0), lower=v=>String(v||'').trim().toLocaleLowerCase('th-TH');
const activeExpenseCats=()=>((window.DinDee&&DinDee.master&&DinDee.master.expenseCats)||[]).slice();
const categoryCanonical=v=>{const a=activeExpenseCats(),raw=String(v||'').trim(),base=raw.split(' — ')[0].trim(),x=lower(base);return a.find(c=>lower(c)===x)||base};
const tagCanonical=(cat,v)=>{const a=(typeof TAGS!=='undefined'&&TAGS[cat])||[],x=lower(v);return a.find(t=>lower(t)===x)||String(v||'').trim()};
const unitCanonical=v=>{const a=(D.units||[]).filter(x=>x.active!==false).map(x=>x.name),q=lower(v);return a.find(u=>lower(u)===q)||String(v||'').trim()};
function repairPurchaseCategoriesV1073(){
 let changed={p:false,s:false,e:false};
 (D.purchases||[]).forEach(x=>{const c=categoryCanonical(x.category);if(c&&c!==x.category){x.category=c;changed.p=true}});
 (D.stock||[]).forEach(x=>{const c=categoryCanonical(x.category);if(c&&c!==x.category){x.category=c;changed.s=true}});
 (D.expenses||[]).filter(x=>x.source==='Purchase').forEach(x=>{const c=categoryCanonical(x.category);if(c&&c!==x.category){x.category=c;changed.e=true}});
 if(changed.p)sv('purchases');if(changed.s)sv('stock');if(changed.e)sv('expenses');
}
repairPurchaseCategoriesV1073();
function linkedExpense(pid){return (D.expenses||[]).find(e=>e.source==='Purchase'&&e.refId===pid)}
function linkedStock(p){return (D.stock||[]).find(s=>s.name===p.item&&s.category===p.category&&s.unit===p.unit&&(s.lot||'')===(p.lot||''))}
function purchaseUsed(p){const st=linkedStock(p);if(!st)return true;return n(st.qty)+1e-9<n(p.qty)}
window.copyPurchaseV1072=function(pid){
 const p=D.purchases.find(x=>x.id===pid);if(!p)return;
 const set=(id,val)=>{const e=document.getElementById(id);if(e)e.value=val??''};
 set('pd',today());set('pi',p.item);set('pc',p.category);const pcEl=document.getElementById('pc');if(pcEl){pcEl.dispatchEvent(new Event('change'));set('ptag',p.tag)}
 set('psupplier',p.supplier||'');set('plot',p.lot||'');set('pstart',p.productionStart||'');set('pmfg',p.mfgDate||'');set('pexp',p.expiryDate||'');set('pq',p.qty);set('pu',p.unit);set('pt',p.total);set('pfund',p.fundId||'');
 document.getElementById('pd')?.scrollIntoView({behavior:'smooth',block:'center'});
};
window.editPurchaseV1072=function(pid){
 if(me?.role!=='Admin')return;const p=D.purchases.find(x=>x.id===pid);if(!p)return alert('ไม่พบรายการซื้อ');
 const cats=activeExpenseCats(),units=(D.units||[]).filter(x=>x.active!==false);
 showEditModal('✏️ แก้ไขประวัติการซื้อ',`<div class="form">
 <div><label>วันที่ซื้อ</label><input id="v72d" type="date" value="${esc(p.date||'')}"></div>
 <div><label>รายการ</label><input id="v72i" value="${esc(p.item||'')}"></div>
 <div><label>Category</label><select id="v72c" onchange="v72t.innerHTML=tagOptions(v72c.value)">${cats.map(x=>`<option value="${esc(x)}" ${x===p.category?'selected':''}>${esc(typeof catLabel==='function'?catLabel(x):x)}</option>`).join('')}</select></div>
 <div><label>Tag</label><select id="v72t">${tagOptions(p.category,p.tag)}</select></div>
 <div><label>Supplier</label><input id="v72s" value="${esc(p.supplier||'')}"></div>
 <div><label>Lot</label><input id="v72l" value="${esc(p.lot||'')}"></div>
 <div><label>วันที่เริ่มผลิต</label><input id="v72ps" type="date" value="${esc(p.productionStart||'')}"></div>
 <div><label>วันที่ผลิต / พร้อมใช้</label><input id="v72m" type="date" value="${esc(p.mfgDate||'')}"></div>
 <div><label>วันหมดอายุ</label><input id="v72e" type="date" value="${esc(p.expiryDate||'')}"></div>
 <div><label>จำนวน</label><input id="v72q" type="number" min="0" step=".01" value="${n(p.qty)}"></div>
 <div><label>หน่วย</label><select id="v72u">${units.map(x=>`<option ${x.name===p.unit?'selected':''}>${esc(x.name)}</option>`).join('')}</select></div>
 <div><label>ยอดรวม</label><input id="v72total" type="number" min="0" step=".01" value="${n(p.total)}"></div></div>
 <p class="small">ถ้ามีการเบิกใช้ Stock จาก Lot นี้แล้ว ระบบจะไม่อนุญาตให้เปลี่ยน จำนวน / รายการ / Category / Lot / หน่วย เพื่อป้องกันประวัติ Stock ผิด</p>`,()=>{
   const q=n(v72q.value),total=n(v72total.value);if(!v72d.value||!v72i.value.trim()||!(q>0)||!v72u.value||total<0)return alert('กรอกข้อมูลให้ครบ');
   const used=purchaseUsed(p),identityChanged=v72i.value.trim()!==p.item||v72c.value!==p.category||v72l.value!==String(p.lot||'')||v72u.value!==p.unit||q!==n(p.qty);
   if(used&&identityChanged)return alert('Lot นี้มีการเบิกใช้แล้ว จึงแก้รายการ Category Lot หน่วย หรือจำนวนไม่ได้');
   const st=linkedStock(p),oldQty=n(p.qty);if(st&&!used){st.qty=n(st.qty)+(q-oldQty);st.name=v72i.value.trim();st.category=v72c.value;st.tag=v72t.value.trim();st.supplier=v72s.value.trim();st.lot=v72l.value.trim();st.productionStart=v72ps.value;st.mfgDate=v72m.value;st.expiryDate=v72e.value;st.unit=v72u.value}
   Object.assign(p,{date:v72d.value,item:v72i.value.trim(),category:v72c.value,tag:v72t.value,supplier:v72s.value.trim(),lot:v72l.value.trim(),productionStart:v72ps.value,mfgDate:v72m.value,expiryDate:v72e.value,qty:q,unit:v72u.value,total});
   const ex=linkedExpense(pid);if(ex)Object.assign(ex,{date:p.date,category:p.category,tag:p.tag,name:p.item,amount:p.total,fundId:p.fundId});
   sv('purchases');sv('stock');sv('expenses');if(typeof logAudit==='function')logAudit('EDIT','Purchase',pid,p.item);closeEditModal();purchase();
 });
};
window.deletePurchaseV1072=function(pid){
 if(me?.role!=='Admin')return;const p=D.purchases.find(x=>x.id===pid);if(!p)return;
 if(purchaseUsed(p))return alert('ลบไม่ได้: Lot นี้มีการเบิกใช้แล้ว เพื่อรักษาประวัติ Stock และต้นทุน');
 if(!confirm(`ยืนยันลบรายการซื้อ "${p.item}" ${p.qty} ${p.unit}?\nStock และค่าใช้จ่ายที่สร้างจากรายการนี้จะถูกย้อนกลับพร้อมกัน`))return;
 const st=linkedStock(p);if(st){st.qty=Math.max(0,n(st.qty)-n(p.qty));if(st.qty<=0&&!((D.usages||[]).some(u=>u.stockId===st.id)))D.stock=D.stock.filter(x=>x.id!==st.id)}
 D.expenses=D.expenses.filter(e=>!(e.source==='Purchase'&&e.refId===pid));D.purchases=D.purchases.filter(x=>x.id!==pid);
 sv('purchases');sv('stock');sv('expenses');if(typeof logAudit==='function')logAudit('DELETE','Purchase',pid,p.item);purchase();
};

/* Purchase history controls: add without replacing procurement logic. */
const oldPurchase=window.purchase;
window.purchase=function(){oldPurchase();if(me?.role!=='Admin')return;
 const table=[...document.querySelectorAll('#content table')].find(t=>t.textContent.includes('Supplier')&&t.textContent.includes('ยอดรวม'));
 if(!table||table.dataset.v1072)return;table.dataset.v1072='1';
 const hr=table.rows[0];if(hr){const th=document.createElement('th');th.textContent='จัดการ';hr.appendChild(th)}
 const rows=[...table.rows].slice(1),ps=(D.purchases||[]).slice().reverse();
 rows.forEach((tr,i)=>{const p=ps[i];if(!p)return;const td=document.createElement('td');td.className='purchase-actions-v1074';td.innerHTML=`<button class="btn2 purchase-icon-btn" title="แก้ไข" aria-label="แก้ไข" onclick="editPurchaseV1072('${p.id}')">✏️</button><button class="btn2 purchase-icon-btn" title="Copy" aria-label="Copy" onclick="copyPurchaseV1072('${p.id}')">📋</button><button class="btn2 dangerBtn purchase-icon-btn" title="ลบ" aria-label="ลบ" onclick="deletePurchaseV1072('${p.id}')">🗑️</button>`;tr.appendChild(td)});
};

/* Dashboard: ensure purchase total is visible even if auto Purchase expense is filtered to prevent double counting. */
const oldDashboard=window.dashboard;
window.dashboard=function(){oldDashboard();if(me?.role==='Staff')return;
 const S=window.dashS||today().slice(0,7)+'-01',E=window.dashE||today(),rows=(D.purchases||[]).filter(x=>(x.date||'')>=S&&(x.date||'')<=E),sum=rows.reduce((a,x)=>a+n(x.total),0);
 const grids=document.querySelector('#content .grid4');if(grids&&!document.querySelector('.purchase-kpi-v1072'))grids.insertAdjacentHTML('afterend',`<div class="card purchase-kpi-v1072"><div class="sectionTitle"><h3>🛒 การซื้อวัตถุดิบในช่วงที่เลือก</h3><span class="pill">${rows.length} รายการ</span></div><div class="grid2"><div class="metric">ยอดซื้อวัตถุดิบ<b>฿${money(sum)}</b></div><div class="metric">รายการล่าสุด<b>${rows.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||''))[0]?.date||'-'}</b></div></div></div>`);
};

/* Excel round-trip validator: exact same canonical Master used by the web form. */
window.normalizePurchaseImportV1072=function(x){
 const y={...x};y.Category=categoryCanonical(y.Category);y.Tag=tagCanonical(y.Category,y.Tag);y.Unit=unitCanonical(y.Unit);return y;
};
window.validatePurchaseImportV1072=function(x){
 x=normalizePurchaseImportV1072(x);let e=[];const cats=activeExpenseCats(),units=(D.units||[]).filter(z=>z.active!==false).map(z=>z.name),tags=(typeof TAGS!=='undefined'&&TAGS[x.Category])||[];
 if(!x.Date||!x.Item)e.push('วันที่/รายการว่าง');if(cats.length&&!cats.includes(x.Category))e.push('Category ไม่ตรง Master');if(x.Tag&&tags.length&&!tags.includes(x.Tag))e.push('Tag ไม่ตรง Master');if(units.length&&!units.includes(x.Unit))e.push('Unit ไม่ตรง Settings');if(!(Number(x.Qty)>0))e.push('Qty ไม่ถูกต้อง');if(isNaN(Number(x.Total)))e.push('Total ไม่ถูกต้อง');if(x.MfgDate&&x.ExpiryDate&&x.MfgDate>x.ExpiryDate)e.push('วันหมดอายุก่อนวันผลิต');return{x,e};
};
})();
