/* DinDee Farm V10.5.6 - Consolidated actions + Work History */
(function(){
'use strict';
function isAdmin(){try{return typeof me!=='undefined'&&!!me&&me.role==='Admin'}catch(e){return false}}
function e(s){return typeof esc==='function'?esc(s):String(s??'')}
function owner(t){try{return typeof ownerName==='function'?(ownerName(t)||'-'):(t.owner||'-')}catch(_){return t.owner||'-'}}
function houseName(id){return (D.houses.find(h=>h.id===id)||{}).name||'-'}
function cycleName(id){const p=D.yearPlans.find(x=>x.id===id);return p?(p.crop||'-'):'งานทั่วไป'}
function statusText(s){return s==='Done'?'ทำแล้ว':s==='Problem'?'มีปัญหา':s==='Postponed'?'เลื่อนงาน':(s||'-')}

/* One visible delete action only.
   Older patch modules may add their own delete buttons; normalize after every render. */
const pageRules=[
 {edit:'editPlan(', del:'deletePlan', cls:'v1056-del-cycle'},
 {edit:'editHouseV101(', del:'deleteHouseV1051', cls:'v1056-del-house'},
 {edit:'editStockV1043(', del:'deleteStockV1052', cls:'v1056-del-stock'},
 {edit:'editStockV101(', del:'deleteStockV1052', cls:'v1056-del-stock'},
 {edit:'editStock(', del:'deleteStockV1052', cls:'v1056-del-stock'},
 {edit:'editSalesDoc(', del:'deleteSalesDocV1051', cls:'v1056-del-sales'},
 {edit:'editFund(', del:'deleteFundV1051', cls:'v1056-del-fund'}
];
function extractId(b){const m=(b.getAttribute('onclick')||'').match(/\('([^']+)'\)/);return m&&m[1]}
function normalizeActions(){
 if(!isAdmin())return;
 const all=[...document.querySelectorAll('#content button')];
 for(const rule of pageRules){
   const edits=all.filter(b=>(b.getAttribute('onclick')||'').startsWith(rule.edit));
   edits.forEach(edit=>{
     // Annual Production Plan is a visualization/edit surface only.
     // Never inject Delete actions into Gantt/timeline rows.
     if(edit.closest('.annualCard,.annualTrack,.annualRow'))return;
     const cell=edit.closest('td')||edit.parentElement;if(!cell)return;
     const id=extractId(edit);if(!id)return;
     // Remove ALL legacy/generated delete buttons in this action cell.
     [...cell.querySelectorAll('button')].forEach(b=>{
       if(b===edit)return;
       const oc=b.getAttribute('onclick')||'', tx=(b.textContent||'').trim();
       if(tx.includes('ลบ') || oc.includes('deletePlan') || oc.includes('deleteHouseV1051') ||
          oc.includes('deleteStockV1052') || oc.includes('deleteProductV1052') ||
          oc.includes('deleteSalesDocV1051') || oc.includes('deleteFundV1051')) b.remove();
     });
     const d=document.createElement('button');
     d.type='button';d.className='btn2 dangerBtn v1056-delete '+rule.cls;d.textContent='🗑️ ลบ';
     d.onclick=()=>{const fn=window[rule.del];if(typeof fn==='function')fn(id);else alert('ไม่พบฟังก์ชันลบ '+rule.del)};
     edit.insertAdjacentElement('afterend',d);
   });
 }
 // Remove accidental test/instruction text from content if it was injected by an old patch.
 [...document.querySelectorAll('#content p,#content div')].forEach(n=>{
   const t=(n.textContent||'').trim();
   if(t.startsWith('รอบนี้ให้ลอง โรงเรือน/พื้นที่ ก่อนครับ') && n.children.length===0)n.remove();
 });
}
const render1056=window.render;
window.render=function(){const r=render1056.apply(this,arguments);normalizeActions();setTimeout(normalizeActions,0);return r};

/* Work history: source of truth = existing D.tasks, no duplicate history database. */
window.workHistoryV1056=function(){
 const done=(D.tasks||[]).filter(t=>['Done','Problem','Postponed'].includes(t.status)||t.actualDate)
   .sort((a,b)=>String(b.actualDate||b.date||'').localeCompare(String(a.actualDate||a.date||'')));
 const houses=[...new Set(done.map(t=>t.houseId).filter(Boolean))];
 const cycles=[...new Set(done.map(t=>t.cycleId).filter(Boolean))];
 content.innerHTML=`<div class="card"><h2>📋 ประวัติการทำงาน</h2>
 <p class="small">ข้อมูลจากงานที่บันทึกทำจริงแล้ว สามารถกรองและย้อนดูตามโรงเรือน / รอบการผลิต / ผู้ปฏิบัติงานได้</p>
 <div class="form">
  <div><label>ตั้งแต่</label><input id="whFrom" type="date"></div>
  <div><label>ถึง</label><input id="whTo" type="date"></div>
  <div><label>โรงเรือน / พื้นที่</label><select id="whHouse"><option value="">ทั้งหมด</option>${houses.map(id=>`<option value="${e(id)}">${e(houseName(id))}</option>`).join('')}</select></div>
  <div><label>รอบการผลิต</label><select id="whCycle"><option value="">ทั้งหมด</option>${cycles.map(id=>`<option value="${e(id)}">${e(cycleName(id))}</option>`).join('')}</select></div>
  <div><label>สถานะ</label><select id="whStatus"><option value="">ทั้งหมด</option><option value="Done">ทำแล้ว</option><option value="Problem">มีปัญหา</option><option value="Postponed">เลื่อนงาน</option></select></div>
  <div><label>ค้นหา</label><input id="whQ" placeholder="งาน / ผู้ปฏิบัติงาน / หมายเหตุ"></div>
 </div><br><button class="btn" onclick="filterWorkHistoryV1056()">🔎 แสดงข้อมูล</button>
 <button class="btn2" onclick="printCurrent()">🖨️ พิมพ์</button></div>
 <div class="card" id="whArea"></div>`;
 window._whData1056=done;filterWorkHistoryV1056();
};
window.filterWorkHistoryV1056=function(){
 let a=window._whData1056||[],f=document.getElementById('whFrom')?.value||'',to=document.getElementById('whTo')?.value||'',
 h=document.getElementById('whHouse')?.value||'',c=document.getElementById('whCycle')?.value||'',
 st=document.getElementById('whStatus')?.value||'',q=(document.getElementById('whQ')?.value||'').toLowerCase();
 a=a.filter(t=>{const d=t.actualDate||t.date||'', hay=[t.action,t.actualRemark,t.note,owner(t),houseName(t.houseId),cycleName(t.cycleId)].join(' ').toLowerCase();
 return (!f||d>=f)&&(!to||d<=to)&&(!h||t.houseId===h)&&(!c||t.cycleId===c)&&(!st||t.status===st)&&(!q||hay.includes(q))});
 const area=document.getElementById('whArea');if(!area)return;
 area.innerHTML=`<h3>รายการประวัติ (${a.length})</h3><div style="overflow:auto"><table><tr><th>วันที่ทำจริง</th><th>โรงเรือน</th><th>รอบการผลิต</th><th>งาน</th><th>ผู้ปฏิบัติงาน</th><th>สถานะ</th><th>วัตถุดิบ</th><th>หมายเหตุ</th><th>หลักฐาน</th><th class="noPrint">จัดการ</th></tr>
 ${a.map(t=>{const u=(D.usages||[]).filter(x=>x.taskId===t.id);const mat=u.map(x=>`${e(x.item||((D.stock.find(s=>s.id===x.stockId)||{}).name)||'-')} ${Number(x.qty||0)} ${e(x.unit||'')}`).join('<br>')||'-';
 return `<tr><td>${e(t.actualDate||t.date||'-')}</td><td>${e(houseName(t.houseId))}</td><td>${e(cycleName(t.cycleId))}</td><td><b>${e(t.action||'-')}</b><br><span class="small">${e(t.type||'')}</span></td><td>${e(owner(t))}</td><td>${e(statusText(t.status))}</td><td>${mat}</td><td>${e(t.actualRemark||t.note||'-')}</td><td>${t.actualPhoto?`<button class="btn2" onclick="viewWorkPhotoV1056('${t.id}')">📷 ดูรูป</button>`:'-'}</td><td class="noPrint"><button class="btn2" onclick="editTask('${t.id}')">✏️ แก้ไข</button>${isAdmin()?` <button class="btn2 dangerBtn" onclick="deleteTask('${t.id}')">🗑️ ลบ</button>`:''}</td></tr>`}).join('')||'<tr><td colspan="10">ยังไม่มีประวัติการทำงานตามเงื่อนไข</td></tr>'}</table></div>`;
};
window.viewWorkPhotoV1056=function(id){const t=D.tasks.find(x=>x.id===id);if(!t?.actualPhoto)return alert('ไม่มีรูปหลักฐาน');showEditModal('📷 หลักฐานการทำงาน',`<img src="${t.actualPhoto}" style="max-width:100%;max-height:70vh;border-radius:12px">`,()=>closeEditModal());};

/* Add a visible Work History card to Today without replacing existing task functionality. */
const today1056=window.todayPage;
window.todayPage=function(){
 const r=today1056.apply(this,arguments);
 const done=(D.tasks||[]).filter(t=>['Done','Problem','Postponed'].includes(t.status)||t.actualDate).length;
 const card=document.createElement('div');card.className='card';
 card.innerHTML=`<h3>📋 ประวัติการทำงาน</h3><p>มีประวัติที่บันทึกแล้ว <b>${done}</b> รายการ</p><button class="btn2" onclick="workHistoryV1056()">ดูประวัติการทำงาน →</button>`;
 content.appendChild(card);return r;
};
})();
