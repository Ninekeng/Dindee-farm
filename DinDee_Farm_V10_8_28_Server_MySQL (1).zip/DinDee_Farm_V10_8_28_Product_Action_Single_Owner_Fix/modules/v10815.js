/* DinDee Farm V10.8.15 — Customer search focus + Test Order cleanup */
(function(){
'use strict';
const testMode=()=>me?.role==='Admin' && !!(D.appSettings&&D.appSettings.allowHardDeleteUsage);

/* Keep the Customer Database search box focused: filter existing table rows instead of re-rendering the page per keystroke. */
const customerPage10815=window.customerHistoryV1062;
window.customerHistoryV1062=function(){
 customerPage10815();
 const input=document.querySelector('#content .customer-tools input');
 const table=document.querySelector('#content .customer-table');
 const pill=document.querySelector('#content .customer-tools .pill');
 if(!input||!table)return;
 input.oninput=function(){
   window.customerQ1062=this.value;
   const q=String(this.value||'').trim().toLowerCase();
   let shown=0;
   [...table.querySelectorAll('tr')].slice(1).forEach(tr=>{
     const hit=!q||String(tr.textContent||'').toLowerCase().includes(q);
     tr.style.display=hit?'':'none';if(hit)shown++;
   });
   if(pill)pill.textContent=`${shown} ลูกค้า`;
 };
};

function restoreOrderProducts10815(o){
 const lines=(o.items&&o.items.length)?o.items:(o.productId?[{productId:o.productId,qty:o.qty}]:[]);
 lines.forEach(line=>{const p=(D.products||[]).find(x=>x.id===line.productId);if(p)p.qty=(Number(p.qty)||0)+(Number(line.qty)||0)});
}
window.deleteTestCustomerOrderV10815=function(oid){
 if(!testMode())return alert('ลบ Order ทดสอบได้เฉพาะ Admin ขณะเปิด Test Mode');
 const o=(D.orders||[]).find(x=>x.id===oid);if(!o)return alert('ไม่พบ Order นี้');
 const linkedIncome=(D.income||[]).filter(x=>x.source==='Farm Shop'&&x.refId===oid);
 const lines=(o.items&&o.items.length)?o.items.map(i=>`${i.name||'-'} × ${Number(i.qty)||0}`).join('\n'):`${o.no||'-'} × ${Number(o.qty)||0}`;
 if(!confirm(`TEST MODE — ลบ Order ทดสอบ ${o.no||''} แบบถาวร?\n\n${lines}\n\nระบบจะคืนจำนวนสินค้าเข้าร้าน และลบ Income ที่เชื่อมกับ Order นี้ ${linkedIncome.length} รายการ\nข้อมูลลูกค้าจะไม่ถูกลบ`))return;
 restoreOrderProducts10815(o);
 D.orders=D.orders.filter(x=>x.id!==oid);
 D.income=(D.income||[]).filter(x=>!(x.source==='Farm Shop'&&x.refId===oid));
 sv('products');sv('orders');sv('income');
 logAudit('HARD DELETE','Test Farm Shop Order',oid,`${o.no||oid}; restored product qty; removed ${linkedIncome.length} income row(s)`);
 customerPurchaseHistoryV1089();
};

/* Purchase history: show permanent delete only for Admin + Test Mode. Search also filters in place. */
window.customerPurchaseHistoryV1089=function(){
 if(me?.role==='Customer'||me?.role==='Sponsor Viewer')return go(me.role==='Customer'?'shop':'sponsor');
 const rows=(D.orders||[]).slice().reverse();
 const canDelete=testMode();
 content.innerHTML=`<div class="pageHero"><div><span class="eyebrow">CUSTOMER PURCHASE HISTORY</span><h2>🧾 ประวัติการซื้อของลูกค้า</h2><p>ค้นหา Order ย้อนหลังตามลูกค้า เบอร์โทร Order หรือสินค้า</p></div><div class="heroActions"><button class="btn2" onclick="go('customers')">👥 ฐานข้อมูลลูกค้า</button><button class="btn2" onclick="go('orders')">📦 Orders</button></div></div>
 <div class="card"><div class="sectionTitle"><input id="customerPurchaseSearch10815" style="max-width:520px" placeholder="🔎 ค้นหาชื่อ / เบอร์ / Order / สินค้า" value="${esc(window.customerPurchaseQ1089||'')}">${canDelete?'<span class="pill">🧪 Test Mode • Admin</span>':''}</div>
 ${canDelete?'<div class="notice">ปุ่ม 🗑️ ใช้ลบ Order ทดสอบแบบถาวร ระบบจะคืนจำนวนสินค้าและลบ Income ที่เชื่อมกับ Order แต่จะไม่ลบข้อมูลลูกค้า</div>':''}
 <div class="tableWrap"><table id="customerPurchaseTable10815"><tr><th>Order</th><th>วันที่</th><th>ลูกค้า</th><th>สินค้า</th><th>ยอด</th><th>สถานะ</th>${canDelete?'<th>จัดการ</th>':''}</tr>${rows.map(o=>`<tr><td><b>${esc(o.no||'-')}</b></td><td>${esc(o.created||'-')}</td><td>${esc(o.customer||'-')}<br><span class="small">${esc(o.phone||'-')}</span></td><td>${(o.items||[]).map(i=>`${esc(i.name||'-')} × ${+i.qty||0}`).join('<br>')||esc(D.products.find(p=>p.id===o.productId)?.name||'-')}</td><td>฿${money(o.total)}</td><td>${statusBadge(o.status)}</td>${canDelete?`<td><button class="btn2 dangerBtn purchase-icon-btn" title="ลบ Order ทดสอบ" onclick="deleteTestCustomerOrderV10815('${o.id}')">🗑️</button></td>`:''}</tr>`).join('')||`<tr><td colspan="${canDelete?7:6}">ยังไม่มีประวัติการซื้อ</td></tr>`}</table></div></div>`;
 const input=document.getElementById('customerPurchaseSearch10815'),table=document.getElementById('customerPurchaseTable10815');
 if(input&&table){input.oninput=function(){window.customerPurchaseQ1089=this.value;const q=String(this.value||'').trim().toLowerCase();[...table.querySelectorAll('tr')].slice(1).forEach(tr=>tr.style.display=(!q||String(tr.textContent||'').toLowerCase().includes(q))?'':'none')};input.oninput()}
};
})();
