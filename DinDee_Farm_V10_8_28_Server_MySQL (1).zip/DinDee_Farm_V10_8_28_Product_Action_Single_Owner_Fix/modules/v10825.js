/* DinDee Farm V10.8.25 — continuous UI actions + checkout completion */
(function(){
'use strict';
const A=x=>Array.isArray(x)?x:[], n=x=>Number(x)||0, digits=x=>String(x||'').replace(/\D/g,'');
let checkoutBusy=false;
function customerByPhone(p){const q=digits(p);return A(D.customers).find(c=>digits(c.phone)===q)}
function cartItems(){return A(window.cart).map(x=>({...x,p:A(D.products).find(p=>p.id===x.productId)})).filter(x=>x.p&&n(x.qty)>0)}
function sourceSnapshot(p,q){let unitCost=0;if(typeof window.productUnitCostV10824==='function')unitCost=n(window.productUnitCostV10824(p));else if(p.sourceType==='farm'&&p.sourceCycleId){const h=A(D.harvests).filter(x=>x.cycleId===p.sourceCycleId).reduce((s,x)=>s+Math.max(0,n(x.qty)-n(x.waste)),0),c=A(D.costs).filter(x=>x.cycleId===p.sourceCycleId).reduce((s,x)=>s+n(x.amount),0);unitCost=h?c/h:0}else unitCost=n(p.manualUnitCost);return {sourceType:p.sourceType||'other',sourceCycleId:p.sourceCycleId||'',sourceHouseId:p.sourceHouseId||'',sourceStockId:p.sourceStockId||'',unitCost,costTotal:n(q)*unitCost}}
function setSubmitBusy(on){checkoutBusy=!!on;const b=document.getElementById('emSave');if(b){b.disabled=!!on;b.textContent=on?'กำลังบันทึก...':'ยืนยันคำสั่งซื้อ'}}
function showCheckoutSuccess(o){
 const body=`<div style="text-align:center;padding:18px 6px"><div style="font-size:3rem">✅</div><h2>สั่งซื้อสำเร็จ</h2><p>เลขที่คำสั่งซื้อ</p><h2>${esc(o.no||'-')}</h2><p class="muted">ยอดรวม ฿${money(o.total)}</p><div class="modalactions" style="justify-content:center"><button class="btn2" type="button" onclick="closeEditModal();shop()">กลับร้านค้า</button><button class="btn" type="button" onclick="closeEditModal();go('track')">ติดตามคำสั่งซื้อ</button></div></div>`;
 const title=document.getElementById('emTitle'),host=document.getElementById('emBody'),save=document.getElementById('emSave');if(title)title.textContent='คำสั่งซื้อสำเร็จ';if(host)host.innerHTML=body;if(save)save.style.display='none';
}
window.submitCheckoutV10825=function(qrType){
 if(checkoutBusy)return;
 const name=document.getElementById('coName')?.value.trim()||'',phone=digits(document.getElementById('coPhone')?.value),pay=document.getElementById('coPay')?.value||'qr',delivery=document.getElementById('coDelivery')?.value||'',address=document.getElementById('coAddress')?.value.trim()||'',note=document.getElementById('coNote')?.value.trim()||'';
 if(!name||phone.length<9)return alert('กรุณากรอกชื่อและเบอร์โทรให้ถูกต้อง');
 const items=cartItems();if(!items.length)return alert('ไม่พบสินค้าในตะกร้า กรุณากลับไปเลือกสินค้าใหม่');for(const x of items)if(n(x.qty)>n(x.p.qty))return alert(`สินค้า ${x.p.name} คงเหลือไม่เพียงพอ`);
 let c=customerByPhone(phone),pin=document.getElementById('coPin89')?.value||'',pin2=document.getElementById('coPinConfirm89')?.value||'';
 if(c&&c.pinHash){if(!/^\d{4}$/.test(pin)||c.pinHash!==hash(pin))return alert('PIN เดิมไม่ถูกต้อง กรุณาลองอีกครั้ง')}else{if(!/^\d{4}$/.test(pin))return alert('PIN ต้องเป็นตัวเลข 4 หลัก');if(pin!==pin2)return alert('PIN ยืนยันไม่ตรงกัน')}
 const slip=document.getElementById('coSlip')?.files?.[0];if(pay==='qr'&&!slip)return alert('กรุณาแนบหลักฐานการชำระเงินก่อนส่งคำสั่งซื้อ');
 setSubmitBusy(true);
 const commit=(slipData)=>{try{
   if(!c){c={id:id(),phone,name,created:today(),active:true};D.customers.push(c)}c.name=name||c.name;c.address=address||c.address;c.note=note||c.note;c.active=c.active!==false;if(!c.pinHash){c.pinHash=hash(pin);c.pinCreatedAt=new Date().toISOString()}
   const total=items.reduce((s,x)=>s+n(x.qty)*n(x.p.price),0),created=new Date().toLocaleString('th-TH');
   const o={id:id(),no:nextOrderNo(),customerId:c.id,customer:name,phone,items:items.map(x=>({productId:x.p.id,name:x.p.name,qty:n(x.qty),unit:x.p.unit,price:n(x.p.price),...sourceSnapshot(x.p,x.qty)})),qty:items.reduce((s,x)=>s+n(x.qty),0),total,paymentMethod:pay,paymentQr:qrType,delivery,address,note,status:pay==='qr'?'Payment Submitted':'New',cashStatus:pay==='cash'?'Pending Cash':'',created,slip:slipData||'',history:[]};
   o.cogs=o.items.reduce((s,x)=>s+n(x.costTotal),0);o.history.push({status:o.status,time:created,note:pay==='qr'?'ส่งคำสั่งซื้อพร้อมหลักฐานชำระเงิน':'สั่งซื้อและเลือกชำระเงินสด'});
   D.orders.push(o);items.forEach(x=>x.p.qty=Math.max(0,n(x.p.qty)-n(x.qty)));sv('customers');sv('orders');sv('products');if(Array.isArray(window.cart))window.cart.length=0;
   try{logAudit('CREATE','Farm Shop Order',o.id,o.no)}catch(e){console.error('audit',e)}
   showCheckoutSuccess(o);checkoutBusy=false;
 }catch(e){console.error('Checkout commit failed',e);checkoutBusy=false;setSubmitBusy(false);alert('บันทึกคำสั่งซื้อไม่สำเร็จ: '+(e.message||e))}};
 if(pay==='qr'){try{fileData(slip,commit)}catch(e){checkoutBusy=false;setSubmitBusy(false);console.error(e);alert('อ่านไฟล์หลักฐานไม่สำเร็จ')}}else commit('');
};
/* Bind the active checkout save button every time the checkout modal is rendered. */
const open25=window.openCheckoutV10814;window.openCheckoutV10814=function(){checkoutBusy=false;const r=open25.apply(this,arguments),save=document.getElementById('emSave');if(save){save.style.display='';save.disabled=false;save.textContent='ยืนยันคำสั่งซื้อ';save.onclick=function(){const act=cartItems().some(x=>/กิจกรรม|workshop|course|คอร์ส/i.test(((D.shopCategories||[]).find(c=>c.id===x.p.categoryId)?.name||x.p.category||'')));window.submitCheckoutV10825(act?'activity':'farm')}}return r};
/* Stable delete: mutate arrays in place, persist, then rerender. This keeps references and repeated actions alive. */
window.deleteTestCustomerOrderV10825=function(oid){
 const test=me?.role==='Admin'&&!!(D.appSettings&&D.appSettings.allowHardDeleteUsage);if(!test)return alert('ลบ Order ทดสอบได้เฉพาะ Admin ขณะเปิด Test Mode');
 const idx=A(D.orders).findIndex(x=>x.id===oid);if(idx<0)return alert('ไม่พบ Order นี้');const o=D.orders[idx],linked=A(D.income).filter(x=>x.source==='Farm Shop'&&x.refId===oid),lines=A(o.items).map(i=>`${i.name||'-'} × ${n(i.qty)}`).join('\n')||o.no||'-';
 if(!confirm(`TEST MODE — ลบ Order ทดสอบ ${o.no||''} แบบถาวร?\n\n${lines}\n\nระบบจะคืนจำนวนสินค้าเข้าร้าน และลบ Income ที่เชื่อมกับ Order นี้ ${linked.length} รายการ\nข้อมูลลูกค้าจะไม่ถูกลบ`))return;
 A(o.items).forEach(line=>{const p=A(D.products).find(x=>x.id===line.productId);if(p)p.qty=n(p.qty)+n(line.qty)});D.orders.splice(idx,1);for(let i=D.income.length-1;i>=0;i--)if(D.income[i].source==='Farm Shop'&&D.income[i].refId===oid)D.income.splice(i,1);
 sv('products');sv('orders');sv('income');try{logAudit('HARD DELETE','Test Farm Shop Order',oid,`${o.no||oid}; restored product qty; removed ${linked.length} income row(s)`)}catch(e){console.error('audit',e)}window.customerPurchaseHistoryV1089();
};
/* Delegated click survives table rerenders and supports repeated deletes without page navigation. */
document.addEventListener('click',function(e){const b=e.target.closest('[data-delete-test-order-v10825]');if(!b)return;e.preventDefault();e.stopPropagation();window.deleteTestCustomerOrderV10825(b.getAttribute('data-delete-test-order-v10825'))});
const hist25=window.customerPurchaseHistoryV1089;window.customerPurchaseHistoryV1089=function(){const r=hist25.apply(this,arguments);document.querySelectorAll('#customerPurchaseTable10815 button[onclick*="deleteTestCustomerOrderV10815"]').forEach(b=>{const m=(b.getAttribute('onclick')||'').match(/deleteTestCustomerOrderV10815\('([^']+)'\)/);if(m){b.removeAttribute('onclick');b.setAttribute('data-delete-test-order-v10825',m[1])}});return r};
})();
