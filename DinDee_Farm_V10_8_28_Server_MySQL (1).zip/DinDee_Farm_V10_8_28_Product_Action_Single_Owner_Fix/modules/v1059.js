/* DinDee Farm V10.5.9 - Task Management Center */
(function(){
'use strict';
const hn=id=>(D.houses.find(x=>x.id===id)||{}).name||'-';
const cn=id=>{const p=D.yearPlans.find(x=>x.id===id);return p?p.crop||'-':'งานทั่วไป'};
const own=t=>t.owner||((D.responsibles||[]).find(x=>x.id===t.ownerId)||{}).name||'-';
const st=t=>t.status==='Done'?'ทำแล้ว':t.status==='Issue'||t.status==='Problem'?'มีปัญหา':t.status==='Postponed'?'เลื่อนงาน':'รอดำเนินการ';
const admin=()=>{try{return typeof me!=='undefined'&&me&&me.role==='Admin'}catch(e){return false}};

window.taskCenterV1059=function(){
 const a=D.tasks||[], counts={
 all:a.length,pending:a.filter(t=>!['Done','Issue','Problem','Postponed'].includes(t.status)).length,
 done:a.filter(t=>t.status==='Done').length,issue:a.filter(t=>['Issue','Problem'].includes(t.status)).length,
 postponed:a.filter(t=>t.status==='Postponed').length
 };
 content.innerHTML=`<div class="pageHero"><div><span class="eyebrow">TASK MANAGEMENT</span><h2>📋 สรุปและจัดการงาน</h2><p>ดูงานที่ต้องทำและงานที่ทำแล้วทั้งหมด • แก้ไข บันทึกผล หรือลบจากหน้าจอเดียว</p></div><div class="heroActions"><button class="btn2" onclick="go('plan30')">← แผนรายเดือน</button></div></div>
 <div class="task-kpis">
  <button onclick="setTaskStatusV1059('')"><span>${counts.all}</span>งานทั้งหมด</button>
  <button onclick="setTaskStatusV1059('Pending')"><span>${counts.pending}</span>รอดำเนินการ</button>
  <button onclick="setTaskStatusV1059('Done')"><span>${counts.done}</span>ทำแล้ว</button>
  <button onclick="setTaskStatusV1059('Issue')"><span>${counts.issue}</span>มีปัญหา</button>
  <button onclick="setTaskStatusV1059('Postponed')"><span>${counts.postponed}</span>เลื่อนงาน</button>
 </div>
 <div class="card task-filter"><h3>🔎 ค้นหา / กรองงาน</h3><div class="form">
  <div><label>ตั้งแต่</label><input id="tcFrom" type="date"></div><div><label>ถึง</label><input id="tcTo" type="date"></div>
  <div><label>โรงเรือน</label><select id="tcHouse"><option value="">ทั้งหมด</option>${D.houses.map(h=>`<option value="${h.id}">${esc(h.name)}</option>`).join('')}</select></div>
  <div><label>Crop Cycle</label><select id="tcCycle"><option value="">ทั้งหมด</option>${D.yearPlans.map(p=>`<option value="${p.id}">${esc(hn(p.houseId))} • ${esc(p.crop||'-')}</option>`).join('')}</select></div>
  <div><label>ผู้รับผิดชอบ</label><select id="tcOwner"><option value="">ทั้งหมด</option>${(D.responsibles||[]).map(o=>`<option value="${o.id}">${esc(o.name)}</option>`).join('')}</select></div>
  <div><label>สถานะ</label><select id="tcStatus"><option value="">ทั้งหมด</option><option value="Pending">รอดำเนินการ</option><option value="Done">ทำแล้ว</option><option value="Issue">มีปัญหา</option><option value="Postponed">เลื่อนงาน</option></select></div>
  <div class="span2"><label>ค้นหา</label><input id="tcQ" placeholder="ชื่องาน / ประเภท / หมายเหตุ"></div>
 </div><br><button class="btn" onclick="filterTaskCenterV1059()">แสดงข้อมูล</button> <button class="btn2" onclick="resetTaskCenterV1059()">ล้างตัวกรอง</button></div>
 <div class="card"><div class="sectionTitle"><div><h3>รายการงาน</h3><span class="muted" id="tcCount"></span></div><button class="btn2" onclick="printCurrent()">🖨️ พิมพ์</button></div><div id="tcArea"></div></div>`;
 filterTaskCenterV1059();
};
window.setTaskStatusV1059=function(v){const x=document.getElementById('tcStatus');if(x)x.value=v;filterTaskCenterV1059()};
window.resetTaskCenterV1059=function(){['tcFrom','tcTo','tcHouse','tcCycle','tcOwner','tcStatus','tcQ'].forEach(id=>{const x=document.getElementById(id);if(x)x.value=''});filterTaskCenterV1059()};
window.filterTaskCenterV1059=function(){
 const val=id=>document.getElementById(id)?.value||'', f=val('tcFrom'),to=val('tcTo'),h=val('tcHouse'),c=val('tcCycle'),o=val('tcOwner'),status=val('tcStatus'),q=val('tcQ').toLowerCase();
 let a=[...(D.tasks||[])].filter(t=>{
  const d=t.date||'', real=t.status==='Issue'||t.status==='Problem'?'Issue':t.status||'Pending';
  const hay=[t.action,t.type,t.note,t.actualRemark,hn(t.houseId),cn(t.cycleId),own(t)].join(' ').toLowerCase();
  return (!f||d>=f)&&(!to||d<=to)&&(!h||t.houseId===h)&&(!c||t.cycleId===c)&&(!o||t.ownerId===o)&&(!status||(status==='Pending'?!['Done','Issue','Problem','Postponed'].includes(t.status):real===status))&&(!q||hay.includes(q));
 }).sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 const count=document.getElementById('tcCount');if(count)count.textContent=`${a.length} รายการ`;
 const area=document.getElementById('tcArea');if(!area)return;
 area.innerHTML=`<div class="tableWrap"><table class="task-center-table"><tr><th>วันที่</th><th>รอบการผลิต</th><th>โรงเรือน</th><th>ประเภท</th><th>งาน</th><th>ผู้รับผิดชอบ</th><th>สถานะ</th><th>วันที่ทำจริง</th><th class="noPrint">จัดการ</th></tr>
 ${a.map(t=>`<tr><td>${esc(t.date||'-')}</td><td>${esc(cn(t.cycleId))}</td><td>${esc(hn(t.houseId))}</td><td>${esc(t.type||'-')}</td><td><b>${esc(t.action||'-')}</b>${t.note?`<div class="task-note">${esc(t.note)}</div>`:''}</td><td>${esc(own(t))}</td><td><span class="task-status task-${t.status||'Pending'}">${esc(st(t))}</span></td><td>${esc(t.actualDate||'-')}</td><td class="noPrint task-actions"><button class="btn2" onclick="viewTaskV1059('${t.id}')">👁️ ดู</button><button class="btn2" onclick="editTask('${t.id}')">✏️ แก้ไข</button>${t.status!=='Done'?`<button class="btn2 successBtn" onclick="doneTask('${t.id}')">✅ บันทึกผล</button>`:''}${admin()?`<button class="btn2 dangerBtn" onclick="deleteTaskSafeV1059('${t.id}')">🗑️ ลบ</button>`:''}</td></tr>`).join('')||'<tr><td colspan="9">ไม่พบงานตามเงื่อนไข</td></tr>'}</table></div>`;
};
window.viewTaskV1059=function(id){
 const t=D.tasks.find(x=>x.id===id);if(!t)return;
 const usages=(D.usages||[]).filter(x=>x.taskId===id);
 showEditModal('👁️ รายละเอียดงาน',`<div class="task-detail-grid">
 <div><small>วันที่แผน</small><b>${esc(t.date||'-')}</b></div><div><small>วันที่ทำจริง</small><b>${esc(t.actualDate||'-')}</b></div>
 <div><small>โรงเรือน</small><b>${esc(hn(t.houseId))}</b></div><div><small>Crop Cycle</small><b>${esc(cn(t.cycleId))}</b></div>
 <div><small>ประเภท</small><b>${esc(t.type||'-')}</b></div><div><small>ผู้รับผิดชอบ</small><b>${esc(own(t))}</b></div>
 <div class="wide"><small>งาน</small><b>${esc(t.action||'-')}</b></div><div class="wide"><small>ผล / หมายเหตุ</small><span>${esc(t.actualRemark||t.note||'-')}</span></div>
 <div class="wide"><small>วัตถุดิบที่ใช้</small><span>${usages.map(u=>`${esc(u.item||'-')} • Lot ${esc(u.lot||'-')} • ${Number(u.qty||0)} ${esc(u.unit||'')}`).join('<br>')||'-'}</span></div>
 ${t.actualPhoto?`<div class="wide"><img src="${t.actualPhoto}" style="max-width:320px;max-height:220px;border-radius:12px"></div>`:''}</div>`,()=>closeEditModal());
};
window.deleteTaskSafeV1059=function(id){
 if(!admin())return;
 const t=D.tasks.find(x=>x.id===id);if(!t)return;
 const usages=(D.usages||[]).filter(x=>x.taskId===id);
 let msg=`ยืนยันลบงาน “${t.action}” ?`;
 if(usages.length)msg+=`\n\nงานนี้มีการเบิกวัตถุดิบ ${usages.length} รายการ ระบบจะคืนจำนวนกลับ Stock/Lot ก่อนลบ`;
 if(!confirm(msg))return;
 usages.forEach(u=>{const s=D.stock.find(x=>x.id===u.stockId);if(s)s.qty=(+s.qty||0)+(+u.qty||0)});
 if(usages.length){const ids=new Set(usages.map(x=>x.id));D.usages=D.usages.filter(x=>!ids.has(x.id));sv('usages');sv('stock')}
 D.tasks=D.tasks.filter(x=>x.id!==id);sv('tasks');logAudit('DELETE','Task',id,t.action);taskCenterV1059();
};

/* Add task-center entry to Monthly Plan without changing calendar/timeline behavior. */
const p30=window.plan30;
window.plan30=function(){
 const r=p30.apply(this,arguments);
 const hero=content.querySelector('.pageHero');
 if(hero&&!hero.querySelector('.task-center-link'))hero.querySelector('.heroActions')?.insertAdjacentHTML('beforeend','<button class="btn task-center-link" onclick="taskCenterV1059()">📋 สรุปและจัดการงาน</button>');
 if(!hero){const first=content.firstElementChild;first?.insertAdjacentHTML('afterbegin','<button class="btn task-center-link noPrint" onclick="taskCenterV1059()" style="float:right">📋 สรุปและจัดการงาน</button>')}
 return r;
};
})();
