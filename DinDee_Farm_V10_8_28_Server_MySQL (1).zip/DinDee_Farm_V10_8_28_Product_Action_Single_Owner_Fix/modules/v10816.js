'use strict';
/* DinDee Farm V10.8.16 — Finance import date normalization + compact edit/delete actions */
(function(){
 const prevFinance=window.finance;
 const isProtected=x=>['Purchase','Farm Shop'].includes(String(x.source||''));
 const rows=()=>[
  ...(D.income||[]).map(x=>({...x,_finType:'Income'})),
  ...(D.expenses||[]).map(x=>({...x,_finType:'Expense'}))
 ].sort((a,b)=>(b.date||'').localeCompare(a.date||''));
 function actions(x){
  if(isProtected(x))return '<span class="small muted" title="แก้ไขจากรายการต้นทาง">🔒 ต้นทาง</span>';
  return `<button type="button" class="btn2 purchase-icon-btn" title="แก้ไขรายการ" onclick="editFinanceV10816('${x._finType}','${x.id}')">✏️</button> <button type="button" class="btn2 dangerBtn purchase-icon-btn" title="ลบรายการ" onclick="deleteFinanceV10816('${x._finType}','${x.id}')">🗑️</button>`;
 }
 function renderTable(){
  return `<div class="tableWrap"><table><tr><th>วันที่</th><th>ประเภท</th><th>Category</th><th>Tag</th><th>สินค้า</th><th>รายละเอียด</th><th>จำนวนเงิน</th><th>จัดการ</th></tr>${rows().map(x=>`<tr><td>${esc(x.date||'-')}</td><td>${x._finType}</td><td>${esc(x.category||'-')}</td><td>${esc(x.tag||'-')}</td><td>${esc(x.product||'-')}</td><td>${esc(x.name||'-')}</td><td>฿${money(x.amount??x.total??0)}</td><td class="finance-actions-v10816">${actions(x)}</td></tr>`).join('')}</table></div>`;
 }
 window.finance=function(){
  prevFinance();
  const cards=[...content.querySelectorAll('.card')];
  const c=cards.find(z=>z.querySelector('h3')?.textContent.trim()==='รายการบัญชี');
  if(c)c.innerHTML='<h3>รายการบัญชี</h3>'+renderTable();
  const imp=cards.find(z=>z.querySelector('h3')?.textContent.includes('Import / Export รายรับ'));
  if(imp){const p=document.createElement('p');p.className='small muted';p.textContent='Date ใน Template ใช้ YYYY-MM-DD เช่น 2026-09-30 • Import รองรับ DD/MM/YYYY และ Excel Date โดยระบบจะแปลงเป็น YYYY-MM-DD ก่อนบันทึก';imp.appendChild(p)}
 };
 window.editFinanceV10816=function(type,fid){
  const arr=type==='Income'?D.income:D.expenses,x=(arr||[]).find(z=>z.id===fid);if(!x)return alert('ไม่พบรายการ');if(isProtected(x))return alert('รายการนี้สร้างจากระบบอัตโนมัติ กรุณาแก้ไขจากรายการต้นทาง');
  const cats=type==='Income'?['Farm Product Sales','Food & Beverage Income','Learning Center Income','Event Income','Support Income','Other Income']:window.DinDee.master.expenseCats;
  const catOpts=cats.map(c=>`<option ${c===x.category?'selected':''}>${esc(c)}</option>`).join('');
  showEditModal('✏️ แก้ไขรายการบัญชี',`<div class="form"><div><label>วันที่</label><input id="efDate" type="date" value="${esc(x.date||today())}"></div><div><label>ประเภท</label><input value="${type}" disabled></div><div><label>Category</label><select id="efCat" onchange="efTag.innerHTML=tagOptions(efCat.value)">${catOpts}</select></div><div><label>Tag</label><select id="efTag"></select></div><div><label>สินค้า/ผลผลิต</label><input id="efProduct" value="${esc(x.product||'')}"></div><div><label>รายละเอียด</label><input id="efName" value="${esc(x.name||'')}"></div><div><label>จำนวนเงิน</label><input id="efAmount" type="number" min="0" step="0.01" value="${Number(x.amount??x.total??0)}"></div></div>`,()=>{if(!efDate.value||!efName.value.trim()||!(+efAmount.value>=0))return alert('กรุณากรอกวันที่ รายละเอียด และจำนวนเงินให้ถูกต้อง');Object.assign(x,{date:efDate.value,category:efCat.value,tag:efTag.value,product:efProduct.value.trim(),name:efName.value.trim(),amount:+efAmount.value});sv(type==='Income'?'income':'expenses');logAudit('UPDATE','Finance',fid,type);closeEditModal();finance()});
  efTag.innerHTML=tagOptions(efCat.value);efTag.value=x.tag||'';
 };
 window.deleteFinanceV10816=function(type,fid){
  const key=type==='Income'?'income':'expenses',arr=D[key]||[],x=arr.find(z=>z.id===fid);if(!x)return alert('ไม่พบรายการ');if(isProtected(x))return alert('รายการนี้สร้างจากระบบอัตโนมัติ กรุณาลบ/ยกเลิกจากรายการต้นทาง');if(!confirm(`ยืนยันลบรายการบัญชีนี้?\n\n${x.date||'-'} • ${x.name||'-'} • ฿${money(x.amount??0)}`))return;D[key]=arr.filter(z=>z.id!==fid);sv(key);logAudit('DELETE','Finance',fid,type);finance();
 };
 const oldAdd=window.addFin;
 window.addFin=function(){oldAdd();const lists=[D.income,D.expenses];for(const a of lists){const x=a[a.length-1];if(x&&x.source==null){x.source='Manual';sv(a===D.income?'income':'expenses')}}};
})();
