/* DinDee Farm V10.8.3 — Unified Work History Edit Popup */
(function(){
'use strict';
const n=x=>Number(x)||0;
function taskUsages(tid){return (D.usages||[]).filter(u=>u.taskId===tid&&u.status!=='Cancelled')}
function stockLabel(u){return `${esc(u.item||'-')} / Lot ${esc(u.lot||'-')} / ${n(u.qty)} ${esc(u.unit||'')}`}
window.editWorkHistoryV1083=function(tid){
 const t=D.tasks.find(x=>x.id===tid);if(!t)return alert('ไม่พบงาน');
 const usages=taskUsages(tid),houses=D.houses.filter(x=>x.active!==false),cycles=D.yearPlans||[];
 const ownerOpts=typeof responsibleOptions==='function'?responsibleOptions(t.ownerId||''):'';
 const typeOpts=typeof taskTypeOptions==='function'?taskTypeOptions(t.typeId||''):'';
 showEditModal('✏️ แก้ไขประวัติงาน',`<div class="form">
 <div><label>วันที่ทำจริง</label><input id="v83date" type="date" value="${esc(t.actualDate||t.date||today())}"></div>
 <div><label>โรงเรือน / พื้นที่</label><select id="v83house"><option value="">-- ไม่ระบุ --</option>${houses.map(h=>`<option value="${h.id}" ${h.id===t.houseId?'selected':''}>${esc(h.name)}</option>`).join('')}</select></div>
 <div><label>รอบการผลิต</label><select id="v83cycle"><option value="">-- งานทั่วไป --</option>${cycles.map(c=>`<option value="${c.id}" ${c.id===t.cycleId?'selected':''}>${esc((D.houses.find(h=>h.id===c.houseId)||{}).name||'-')} • ${esc(c.crop||'-')}</option>`).join('')}</select></div>
 <div><label>ประเภทงาน</label><select id="v83type">${typeOpts}</select></div>
 <div class="span2"><label>งาน / รายละเอียด</label><input id="v83action" value="${esc(t.action||'')}"></div>
 <div><label>ผู้ปฏิบัติงาน</label><select id="v83owner">${ownerOpts}</select></div>
 <div><label>สถานะ</label><select id="v83status"><option value="Pending" ${t.status==='Pending'?'selected':''}>Pending</option><option value="Done" ${t.status==='Done'?'selected':''}>ทำแล้ว</option><option value="Problem" ${['Problem','Issue'].includes(t.status)?'selected':''}>มีปัญหา</option><option value="Postponed" ${t.status==='Postponed'?'selected':''}>เลื่อนงาน</option></select></div>
 <div class="span2"><label>หมายเหตุ</label><textarea id="v83remark" rows="2">${esc(t.actualRemark||t.note||'')}</textarea></div>
 <div class="span2"><label>หลักฐาน</label><div>${t.actualPhoto?'📷 มีรูปหลักฐานเดิม':'ยังไม่มีรูป'}</div><input id="v83photo" type="file" accept="image/*"></div>
 </div>
 <div class="card work-materials-v1083"><div class="sectionTitle"><div><h3>🧪 วัตถุดิบที่ใช้จริง</h3><span class="small">จัดการวัตถุดิบภายใน Popup เดียว</span></div><button type="button" class="btn2" onclick="addWorkUsageV1080('${tid}')">＋ เพิ่ม</button></div>
 ${usages.map(u=>`<div class="taskLine"><div><b>${stockLabel(u)}</b><small>${esc(u.note||'')}</small></div><span><button type="button" class="btn2 purchase-icon-btn" title="แก้ไขวัตถุดิบ" onclick="editWorkUsageV1080('${u.id}','${tid}')">✏️</button><button type="button" class="btn2 purchase-icon-btn" title="คืน Stock" onclick="returnUsageV1081('${u.id}')">↩️</button></span></div>`).join('')||'<div class="muted">ยังไม่มีวัตถุดิบที่ใช้จริง</div>'}
 </div>`,()=>{
   const ty=D.taskTypes.find(x=>x.id===v83type.value),cy=D.yearPlans.find(x=>x.id===v83cycle.value);
   t.actualDate=v83date.value||t.actualDate||t.date;t.date=t.date||v83date.value;
   t.houseId=cy?.houseId||v83house.value;t.cycleId=v83cycle.value;t.typeId=v83type.value;t.type=ty?.name||t.type||'';
   t.action=v83action.value.trim();t.ownerId=v83owner.value;t.owner='';t.status=v83status.value;t.actualRemark=v83remark.value.trim();
   const commit=photo=>{if(photo)t.actualPhoto=photo;sv('tasks');logAudit('EDIT','Work History',tid,t.action);closeEditModal();workHistoryV1056()};
   const f=v83photo.files?.[0];if(f)fileData(f,commit);else commit('');
 });
};

/* Keep filters from V10.5.6 but make history table clean: material is text only; actions are compact icons. */
const oldFilter=window.filterWorkHistoryV1056;
window.filterWorkHistoryV1056=function(){
 oldFilter();
 const area=document.getElementById('whArea');if(!area)return;const table=area.querySelector('table');if(!table)return;
 const data=window._whData1056||[],f=document.getElementById('whFrom')?.value||'',to=document.getElementById('whTo')?.value||'',h=document.getElementById('whHouse')?.value||'',c=document.getElementById('whCycle')?.value||'',st=document.getElementById('whStatus')?.value||'',q=(document.getElementById('whQ')?.value||'').toLowerCase();
 const a=data.filter(t=>{const d=t.actualDate||t.date||'',owner=t.owner||((D.responsibles||[]).find(x=>x.id===t.ownerId)||{}).name||'',house=(D.houses.find(x=>x.id===t.houseId)||{}).name||'',cycle=(D.yearPlans.find(x=>x.id===t.cycleId)||{}).crop||'',hay=[t.action,t.actualRemark,t.note,owner,house,cycle].join(' ').toLowerCase();return(!f||d>=f)&&(!to||d<=to)&&(!h||t.houseId===h)&&(!c||t.cycleId===c)&&(!st||t.status===st)&&(!q||hay.includes(q))});
 const trs=[...table.querySelectorAll('tr')].slice(1);
 trs.forEach((tr,i)=>{const t=a[i];if(!t)return;const cells=tr.children;
   if(cells[6])cells[6].innerHTML=taskUsages(t.id).map(stockLabel).join('<br>')||'-';
   const action=cells[cells.length-1];if(action){action.classList.add('compact-work-actions-v1083');action.innerHTML=`<button class="btn2 purchase-icon-btn" title="แก้ไขงานและวัตถุดิบ" onclick="editWorkHistoryV1083('${t.id}')">✏️</button>${me?.role==='Admin'?`<button class="btn2 dangerBtn purchase-icon-btn" title="ลบงาน" onclick="deleteTask('${t.id}')">🗑️</button>`:''}`;}
 });
};
})();
