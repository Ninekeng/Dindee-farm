
'use strict';
(function(){
  const expenseCats=['Crop Production','Livestock & Animals','Food & Beverage','Learning Center & Activities','Farm Infrastructure','Farm Development'];
  D.responsibles=L('responsibles',[]);
  D.salesDocs=L('salesDocs',[]);
  D.salespeople=L('salespeople',[]);
  window.DinDee.master={expenseCats};

  window.responsibleOptions=function(selected=''){
    return '<option value="">-- ยังไม่ระบุ --</option>'+D.responsibles.filter(x=>x.active!==false).map(x=>`<option value="${x.id}" ${x.id===selected?'selected':''}>${esc(x.name)}</option>`).join('');
  };
  window.ownerName=function(task){
    if(task.ownerId){let x=D.responsibles.find(r=>r.id===task.ownerId);if(x)return x.name}
    return task.owner||'';
  };
  window.renameMaster=function(k,i){
    let x=D[k].find(y=>y.id===i); if(!x)return;
    showEditModal('✏️ แก้ไขข้อมูลหลัก',`<div class="form"><div class="span2"><label>ชื่อ</label><input id="masterName" value="${esc(x.name)}"></div></div>`,()=>{
      let n=masterName.value.trim(); if(!n)return alert('กรุณากรอกชื่อ');
      x.name=n; sv(k); logAudit('EDIT','Master '+k,i,n); closeEditModal(); render();
    });
  };
  window.settings=function(){
    normalizeMasters();
    const box=(title,k,ph)=>`<div class="card"><h3>${title}</h3><div class="noPrint" style="display:flex;gap:8px"><input id="new_${k}" placeholder="${ph}"><button class="btn" onclick="addMaster('${k}')">+ เพิ่ม</button></div><table><tr><th>ชื่อ</th><th>สถานะ</th><th>จัดการ</th></tr>${D[k].map(x=>`<tr><td>${esc(x.name)}</td><td>${x.active!==false?'ใช้งาน':'ปิดใช้งาน'}</td><td><button class="btn2" onclick="renameMaster('${k}','${x.id}')">✏️ แก้ไข</button> <button class="btn2" onclick="toggleMaster('${k}','${x.id}')">${x.active!==false?'ปิด':'เปิด'}</button></td></tr>`).join('')}</table></div>`;
    content.innerHTML=`<div class="card"><h2>⚙️ ตั้งค่าระบบ / ข้อมูลหลัก</h2><p>ข้อมูลในหน้านี้เป็น Master กลาง ทุกหน้าต้องใช้รายการเดียวกัน เพื่อลดปัญหาชื่อไม่ตรงกัน</p></div>
    ${box('🏡 ประเภทโรง / พื้นที่','areaTypes','เช่น บ่อปลา')}
    ${box('🧰 ประเภทงาน','taskTypes','เช่น ให้อาหารสัตว์')}
    ${box('👷 ผู้รับผิดชอบ','responsibles','ชื่อผู้รับผิดชอบ')}
    ${box('🌱 ชนิดพืช / สัตว์','species','เช่น เคล / ไก่ไข่')}
    ${box('📏 หน่วยนับ','units','เช่น ฟอง')}
    ${box('🚚 Supplier / แหล่งวัตถุดิบ','suppliers','ชื่อผู้ขาย')}
    <div class="card dangerbox"><h3>♻️ Reset ระบบ</h3><p>ควร Export / Backup ก่อนทุกครั้ง</p><button class="btn2" onclick="resetTransactions()">ล้างข้อมูล Transaction ทดลอง</button> <button class="btn2" onclick="factoryReset()">⚠️ Factory Reset ทั้งระบบ</button></div>`;
  };
})();

window.unitOptions=function(selected=''){
  return '<option value="">-- เลือกหน่วยนับ --</option>'+D.units.filter(x=>x.active!==false).map(x=>`<option value="${x.name}" ${x.name===selected?'selected':''}>${esc(x.name)}</option>`).join('');
};

/* V10.3.1 Supplier relationship helpers */
window.supplierName=function(supplierId,fallback=''){
  const x=(D.suppliers||[]).find(s=>s.id===supplierId);
  return x?x.name:(fallback||'');
};
window.findSupplierByName=function(name){
  const n=(name||'').trim().toLocaleLowerCase();
  return (D.suppliers||[]).find(s=>(s.name||'').trim().toLocaleLowerCase()===n);
};
window.ensureSupplier=function(name){
  const clean=(name||'').trim(); if(!clean)return null;
  let x=findSupplierByName(clean);
  if(x)return x;
  x={id:id(),name:clean,active:true};
  D.suppliers.push(x); sv('suppliers'); logAudit('CREATE','Master suppliers',x.id,clean);
  return x;
};
window.supplierDatalist=function(){
  return (D.suppliers||[]).filter(x=>x.active!==false).map(x=>`<option value="${esc(x.name)}"></option>`).join('');
};
