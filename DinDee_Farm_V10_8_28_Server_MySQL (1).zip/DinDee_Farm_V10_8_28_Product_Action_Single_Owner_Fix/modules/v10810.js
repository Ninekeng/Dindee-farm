/* DinDee Farm V10.8.10 — Checkout PIN + Customer Database reliability */
(function(){
'use strict';
const digits=v=>String(v||'').replace(/\D/g,'');
const byPhone=p=>(D.customers||[]).find(c=>digits(c.phone)===digits(p));

function pinFieldsV10810(){
 const phoneEl=document.getElementById('coPhone'),box=document.getElementById('coPinBox10810');
 if(!phoneEl||!box)return;
 const p=digits(phoneEl.value),c=byPhone(p);
 if(p.length<9){box.innerHTML='<div class="notice">🔐 กรอกเบอร์โทรก่อน ระบบจะแสดงช่อง PIN อัตโนมัติ</div>';return;}
 if(c&&c.pinHash){
   box.innerHTML=`<div class="pin-title-v10810">🔐 พบลูกค้าเดิม: ${esc(c.name||'ลูกค้า')}</div><label><b>กรอก PIN เดิม 4 หลัก</b></label><input id="coPin89" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="4" autocomplete="current-password" placeholder="••••"><div class="small">ใช้ PIN เดิมที่ตั้งไว้ หากจำไม่ได้ให้ติดต่อ Admin เพื่อ Reset PIN</div>`;
 }else{
   box.innerHTML=`<div class="pin-title-v10810">🔐 ${c?'บัญชีนี้ยังไม่มี PIN — ตั้ง PIN ครั้งแรก':'ลูกค้าใหม่ — ตั้ง PIN 4 หลัก'}</div><div class="pin-grid-v1089"><div><label><b>ตั้ง PIN 4 หลัก</b></label><input id="coPin89" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="4" autocomplete="new-password" placeholder="••••"></div><div><label><b>ยืนยัน PIN</b></label><input id="coPinConfirm89" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="4" autocomplete="new-password" placeholder="••••"></div></div><div class="small">PIN ใช้ติดตาม Order และดูประวัติการซื้อ กรุณาจำ PIN นี้ไว้</div>`;
 }
}
window.pinFieldsV10810=pinFieldsV10810;

/* Override the ACTIVE checkout used by Farm Shop (v1043), with PIN built into the modal itself. */
window.openCheckoutV1043=function(){
 let items=cart.map(x=>({...x,p:D.products.find(p=>p.id===x.productId)})).filter(x=>x.p),total=items.reduce((a,x)=>a+x.qty*num(x.p.price),0),act=items.some(x=>isActivity(x.p)),qr=act?D.farmProfile.activityQr:D.farmProfile.farmQr;
 showEditModal('ยืนยันคำสั่งซื้อ',`<div class="checkoutGrid"><div><h3>ข้อมูลลูกค้า</h3><div class="form oneCol"><div><label>ชื่อ-นามสกุล</label><input id="coName"></div><div><label>เบอร์โทร</label><input id="coPhone" inputmode="tel" oninput="pinFieldsV10810()"></div><div id="coPinBox10810" class="pin-box-v1089"><div class="notice">🔐 กรอกเบอร์โทรก่อน ระบบจะแสดงช่อง PIN อัตโนมัติ</div></div><div><label>วิธีรับสินค้า</label><select id="coDelivery" onchange="deliveryNoteV1043()"><option>รับที่ฟาร์ม</option><option>จัดส่ง - โทรสอบถามก่อน</option></select></div><div id="deliveryWarn" class="notice hidden">🚚 กรุณาโทรสอบถามดินดีฟาร์มเพื่อยืนยันพื้นที่จัดส่งและค่าจัดส่งก่อนชำระเงิน</div><div><label>ที่อยู่ / รายละเอียดการรับ</label><textarea id="coAddress"></textarea></div><div><label>หมายเหตุ</label><textarea id="coNote"></textarea></div></div></div><div class="checkoutSummary"><h3>รายการสินค้า</h3>${items.map(x=>`<div class="sumLine"><span>${esc(x.p.name)} · ${x.qty} ${esc(x.p.unit)} × ฿${money(x.p.price)}</span><b>฿${money(x.qty*x.p.price)}</b></div>`).join('')}<div class="checkoutTotal"><span>ยอดชำระ</span><b>฿${money(total)}</b></div><label>วิธีชำระเงิน</label><select id="coPay" onchange="toggleCheckoutPayV104()"><option value="qr">QR Code</option><option value="cash">เงินสดตอนรับสินค้า</option></select><div id="coQrBox" class="qrBox">${qr?`<img src="${qr}"><b>${act?'Activity QR':'Farm QR'}</b>`:'<div class="notice">ยังไม่ได้ตั้งค่า QR ใน Settings</div>'}<label>แนบหลักฐานการชำระเงิน</label><input id="coSlip" type="file" accept="image/*,.pdf"></div><div id="coCashBox" class="notice hidden">ชำระเงินสดตอนรับสินค้า ไม่ต้องแนบสลิป</div></div></div>`,()=>submitCheckoutV104(act?'activity':'farm'));
 pinFieldsV10810();
};

/* Customer master page: make it unmistakably a database and expose PIN state/reset. */
const customerBase=window.customerHistoryV1062;
window.customerHistoryV1062=function(){
 customerBase();
 const hero=document.querySelector('#content .pageHero');
 if(hero){const h=hero.querySelector('h2'),p=hero.querySelector('p');if(h)h.textContent='👥 ฐานข้อมูลลูกค้า';if(p)p.textContent='จัดการข้อมูลลูกค้า เบอร์โทร สถานะ PIN และเปิดดูประวัติการซื้อ';}
 const table=document.querySelector('#content .customer-table');if(!table)return;
 const head=table.querySelector('tr');if(head&&!head.querySelector('.pin-head-v10810')){
   const th=document.createElement('th');th.className='pin-head-v10810';th.textContent='PIN';head.insertBefore(th,head.lastElementChild);
 }
 const q=(window.customerQ1062||'').toLowerCase(),cs=(D.customers||[]).filter(c=>!q||[c.name,c.phone,c.address,c.note].join(' ').toLowerCase().includes(q));
 [...table.querySelectorAll('tr')].slice(1).forEach((tr,i)=>{
   const c=cs[i];if(!c||tr.querySelector('.pin-cell-v10810'))return;
   const td=document.createElement('td');td.className='pin-cell-v10810';td.innerHTML=c.pinHash?'<span class="pill">🔐 ตั้งแล้ว</span>':'<span class="small">ยังไม่ตั้ง</span>';
   tr.insertBefore(td,tr.lastElementChild);
   const action=tr.lastElementChild;if(action&&!action.querySelector('[data-pin-reset]'))action.insertAdjacentHTML('beforeend',` <button class="btn2 purchase-icon-btn" data-pin-reset title="Reset PIN" onclick="resetCustomerPinV1085('${c.id}')">🔑</button>`);
 });
};
})();
