/* DinDee Farm V10.5.1 - Safe delete controls */
(function(){
  'use strict';
  const persist=(k)=>{ if(typeof sv==='function') sv(k); };
  const audit=(action,type,id,detail)=>{ if(typeof logAudit==='function') logAudit(action,type,id,detail||''); };
  const admin=()=>{try{return typeof me!=='undefined'&&!!me&&me.role==='Admin'}catch(e){return false}};
  const ask=(msg)=>window.confirm(msg);

  // Crop cycle: protect historical/financial traceability. Empty cycles can be deleted permanently.
  window.deletePlan=function(cid){
    if(!admin()) return alert('เฉพาะ Admin เท่านั้น');
    const c=D.yearPlans.find(x=>x.id===cid); if(!c) return;
    const tasks=D.tasks.filter(x=>x.cycleId===cid);
    const usages=D.usages.filter(x=>x.cycleId===cid);
    const harvests=D.harvests.filter(x=>x.cycleId===cid);
    const costs=D.costs.filter(x=>x.cycleId===cid);
    const incomes=(D.income||[]).filter(x=>x.cycleId===cid);
    const linked=usages.length+harvests.length+costs.length+incomes.length;
    if(linked){
      alert(`รอบการผลิตนี้มีข้อมูลประวัติเชื่อมโยง\nเบิกวัตถุดิบ ${usages.length} | ผลผลิต ${harvests.length} | ต้นทุน ${costs.length} | รายรับ ${incomes.length}\n\nเพื่อรักษา Stock/ต้นทุน/รายงาน ระบบจะไม่ลบข้อมูลประวัติ กรุณาปิด/สิ้นสุดรอบแทน`);
      return;
    }
    if(!ask(`ยืนยันลบรอบการผลิต “${c.crop||'-'}” ?\nงานแผนที่ผูกกับรอบนี้ ${tasks.length} งานจะถูกลบด้วย`)) return;
    D.tasks=D.tasks.filter(x=>x.cycleId!==cid); D.yearPlans=D.yearPlans.filter(x=>x.id!==cid);
    persist('tasks');persist('yearPlans');audit('DELETE','Crop Cycle',cid,c.crop);render();
  };

  // Houses: permanent delete only when never referenced; otherwise deactivate to preserve history.
  window.deleteHouseV1051=function(hid){
    if(!admin()) return alert('เฉพาะ Admin เท่านั้น');
    const h=D.houses.find(x=>x.id===hid); if(!h) return;
    const refs={cycles:D.yearPlans.filter(x=>x.houseId===hid).length,tasks:D.tasks.filter(x=>x.houseId===hid).length,usages:D.usages.filter(x=>x.houseId===hid).length,harvests:D.harvests.filter(x=>x.houseId===hid).length,products:D.products.filter(x=>x.houseId===hid||x.house===hid).length};
    const total=Object.values(refs).reduce((a,b)=>a+b,0);
    if(total){
      if(!ask(`“${h.name}” มีข้อมูลเชื่อมโยง ${total} รายการ\nรอบผลิต ${refs.cycles} | งาน ${refs.tasks} | เบิกใช้ ${refs.usages} | ผลผลิต ${refs.harvests} | สินค้า ${refs.products}\n\nไม่ควรลบถาวร ต้องการ “ปิดใช้งาน” แทนหรือไม่?`)) return;
      h.active=false;persist('houses');audit('DEACTIVATE','House',hid,h.name);render();return;
    }
    if(!ask(`ยืนยันลบโรงเรือน / พื้นที่ “${h.name}” ถาวร?`)) return;
    D.houses=D.houses.filter(x=>x.id!==hid);persist('houses');audit('DELETE','House',hid,h.name);render();
  };
  const oldHouses=window.houses;
  window.houses=function(){oldHouses(); if(!admin())return; document.querySelectorAll('#content table tr').forEach(tr=>{const b=tr.querySelector("button[onclick^=\"editHouseV101\"]");if(!b||tr.querySelector('.v1051-del-house'))return;const m=(b.getAttribute('onclick')||'').match(/editHouseV101\('([^']+)'\)/);if(m)b.parentElement.insertAdjacentHTML('beforeend',` <button class="btn2 v1051-del-house" onclick="deleteHouseV1051('${m[1]}')">🗑️ ลบ</button>`);});};

  // Farm Shop Product row actions are owned by v1052 only.
  // Do not inject a second delete button here; later modules may re-render the catalog.

  // Sales documents: draft/unlinked documents can be deleted. Linked/paid docs are cancelled instead.
  window.deleteSalesDocV1051=function(did){
    if(!admin()) return alert('เฉพาะ Admin เท่านั้น');
    const d=D.salesDocs.find(x=>x.id===did);if(!d)return;
    const linkedOrder=D.orders.some(o=>o.salesDocId===did||o.docId===did||o.invoiceId===did||o.salesDocNo===d.no);
    const linkedIncome=(D.income||[]).some(x=>x.salesDocId===did||x.docId===did||x.ref===did||x.refNo===d.no);
    const protectedDoc=linkedOrder||linkedIncome||['Paid','Partially Paid'].includes(d.status)||d.type==='CashSale';
    if(protectedDoc){
      if(!ask(`เอกสาร ${d.no||''} มีประวัติการขาย/การชำระเงินเชื่อมโยง\nเพื่อรักษารายงานย้อนหลัง ระบบจะเปลี่ยนสถานะเป็น “Cancelled” แทนการลบถาวร\n\nยืนยันหรือไม่?`))return;
      d.status='Cancelled';d.cancelledAt=new Date().toISOString();persist('salesDocs');audit('CANCEL','Sales Document',did,d.no);salesDocsPage();return;
    }
    if(!ask(`ยืนยันลบเอกสาร ${d.no||''} ถาวร?`))return;
    D.salesDocs=D.salesDocs.filter(x=>x.id!==did);persist('salesDocs');audit('DELETE','Sales Document',did,d.no);salesDocsPage();
  };
  const oldSalesDocs=window.salesDocsPage;
  window.salesDocsPage=function(){oldSalesDocs();if(!admin())return;document.querySelectorAll('#content table tr').forEach(tr=>{const b=tr.querySelector("button[onclick^=\"editSalesDoc\"]");if(!b||tr.querySelector('.v1051-del-doc'))return;const m=(b.getAttribute('onclick')||'').match(/editSalesDoc\('([^']+)'\)/);if(m)b.parentElement.insertAdjacentHTML('beforeend',` <button class="btn2 v1051-del-doc" onclick="deleteSalesDocV1051('${m[1]}')">🗑️ ลบ</button>`);});};

  // Sponsor Fund: permanent delete only if unused; used funds remain for traceability and can be closed.
  window.deleteFundV1051=function(fid){
    if(!admin())return alert('เฉพาะ Admin เท่านั้น');
    const f=D.funds.find(x=>x.id===fid);if(!f)return;
    const purchases=D.purchases.filter(x=>x.fundId===fid), expenses=(D.expenses||[]).filter(x=>x.fundId===fid);
    if(purchases.length||expenses.length){
      if(!ask(`Sponsor Fund “${f.project||f.sponsor}” มีรายการใช้เงิน ${purchases.length+expenses.length} รายการ\nไม่สามารถลบถาวรโดยไม่ทำให้ประวัติการเงินเสียหาย\n\nต้องการปิดใช้งานกองทุนแทนหรือไม่?`))return;
      f.active=false;f.closedAt=new Date().toISOString();persist('funds');audit('DEACTIVATE','Sponsor Fund',fid,f.project||f.sponsor);render();return;
    }
    if(!ask(`ยืนยันลบ Sponsor Fund “${f.project||f.sponsor}” ถาวร?`))return;
    D.funds=D.funds.filter(x=>x.id!==fid);persist('funds');audit('DELETE','Sponsor Fund',fid,f.project||f.sponsor);render();
  };
  const oldSponsor=window.sponsor;
  window.sponsor=function(){oldSponsor();if(!admin())return;document.querySelectorAll('#content button[onclick^="editFund"]').forEach(b=>{if(b.parentElement.querySelector('.v1051-del-fund'))return;const m=(b.getAttribute('onclick')||'').match(/editFund\('([^']+)'\)/);if(m)b.insertAdjacentHTML('afterend',` <button class="btn2 v1051-del-fund" onclick="deleteFundV1051('${m[1]}')">🗑️ ลบ</button>`);});};
})();
