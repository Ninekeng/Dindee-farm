/* DinDee Farm V10.7.8 — Shop Income Mapping + Sales History */
(function(){
'use strict';
const INC=[
 ['Farm Product Sales','ขายผลผลิตจากฟาร์ม'],
 ['Food & Beverage Income','รายได้อาหารและเครื่องดื่ม'],
 ['Learning Center Income','รายได้ศูนย์เรียนรู้'],
 ['Event Income','รายได้จากงานและกิจกรรม'],
 ['Support Income','เงินสนับสนุน'],
 ['Other Income','รายได้อื่น ๆ']
];
function tags(cat){return (typeof TAGS!=='undefined'&&TAGS[cat])||[]}
function incomeOpts(sel=''){return INC.map(([v,th])=>`<option value="${v}" ${v===sel?'selected':''}>${v} — ${th}</option>`).join('')}
function tagOpts(cat,sel=''){return tags(cat).map(v=>`<option ${v===sel?'selected':''}>${v}</option>`).join('')}
function defaultMap(c){
 const n=String(c?.name||'');
 if(/คอร์ส|workshop/i.test(n))return ['Learning Center Income','Workshop Income'];
 if(/กิจกรรม/i.test(n))return ['Learning Center Income','Activity Income'];
 if(/เครื่องดื่ม|กาแฟ|ชา|น้ำดื่ม/i.test(n))return ['Food & Beverage Income','Beverage Sales'];
 if(/อาหาร/i.test(n))return ['Food & Beverage Income','Food Sales'];
 if(/event|อีเวนต์/i.test(n))return ['Event Income','Event Income'];
 return ['Farm Product Sales',''];
}
function ensureMaps(){
 (D.shopCategories||[]).forEach(c=>{if(!c.incomeCategory){let m=defaultMap(c);c.incomeCategory=m[0];c.incomeTag=m[1]}});
 sv('shopCategories');
}
ensureMaps();
window.refreshShopIncomeTagV1078=function(catId='v78inc',tagId='v78tag'){
 const c=document.getElementById(catId),t=document.getElementById(tagId);if(c&&t)t.innerHTML=tagOpts(c.value,t.value);
};
window.editShopCatMapV1078=function(cid){
 const c=D.shopCategories.find(x=>x.id===cid);if(!c)return;
 showEditModal('เชื่อมหมวดร้านค้ากับ Income Master',`<div class="form">
 <div><label>หมวดร้านค้า</label><input value="${esc(c.name)}" disabled></div>
 <div><label>Income Category</label><select id="v78inc" onchange="refreshShopIncomeTagV1078()">${incomeOpts(c.incomeCategory)}</select></div>
 <div><label>Income Tag</label><select id="v78tag">${tagOpts(c.incomeCategory,c.incomeTag)}</select></div>
 </div><div class="helpbox">เมื่อ Order ชำระเงิน ระบบจะใช้ Category / Tag นี้บันทึกรายได้และแสดงใน Dashboard</div>`,()=>{
   c.incomeCategory=v78inc.value;c.incomeTag=v78tag.value||'';sv('shopCategories');logAudit('EDIT','Shop Income Mapping',c.id,`${c.name} → ${c.incomeCategory} / ${c.incomeTag}`);closeEditModal();manageShopCats();
 });
};
window.manageShopCats=function(){
 ensureMaps();const rows=D.shopCategories.slice().sort((a,b)=>(a.sort||0)-(b.sort||0));
 showEditModal('หมวดหมู่สินค้า + Income Mapping',`<div class="helpbox">Master กลาง: หมวดร้านค้า → Income Category → Income Tag → Dashboard</div>
 <div class="tableWrap"><table><tr><th>หมวดร้านค้า</th><th>Income Category</th><th>Income Tag</th><th>สถานะ</th><th></th></tr>
 ${rows.map(c=>`<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.incomeCategory||'-')}</td><td>${esc(c.incomeTag||'-')}</td><td>${c.active!==false?'ใช้งาน':'ปิด'}</td><td><button class="btn2 purchase-icon-btn" title="แก้ไข Mapping" onclick="editShopCatMapV1078('${c.id}')">✏️</button><button class="btn2 purchase-icon-btn" title="${c.active!==false?'ปิด':'เปิด'}ใช้งาน" onclick="toggleShopCatV1042('${c.id}')">${c.active!==false?'⏸':'▶'}</button></td></tr>`).join('')}</table></div>
 <div class="form"><div class="span2"><label>เพิ่มหมวดร้านค้าใหม่</label><input id="newShopCat" placeholder="ชื่อหมวดหมู่"></div></div>`,()=>{
   const n=newShopCat.value.trim();if(n){if(D.shopCategories.some(c=>String(c.name).toLowerCase()===n.toLowerCase()))return alert('มีหมวดหมู่นี้อยู่แล้ว');let c={id:'cat-'+Date.now().toString(36),name:n,active:true,sort:D.shopCategories.length+1,incomeCategory:'Farm Product Sales',incomeTag:''};D.shopCategories.push(c);sv('shopCategories')}
   closeEditModal();shopadmin();
 });
};
function productMap(p){
 const c=D.shopCategories.find(x=>x.id===p?.categoryId);if(c?.incomeCategory)return [c.incomeCategory,c.incomeTag||''];
 return defaultMap(c||{name:p?.category||''});
}
function orderLines(o){
 let a=(o.items||[]).map(i=>{let p=D.products.find(x=>x.id===i.productId);return {productId:i.productId,name:i.name||p?.name||'-',qty:+i.qty||0,price:+(i.price??p?.price)||0,p}});
 if(!a.length&&o.productId){let p=D.products.find(x=>x.id===o.productId);a=[{productId:o.productId,name:p?.name||'-',qty:+o.qty||1,price:+(o.price??p?.price)||0,p}]}
 return a;
}
/* One income row per category/tag for mixed baskets; exact total is allocated from order line values. */
window.syncShopIncomeV1078=function(o){
 if(!o)return;let paid=o.cashReceived||['Confirmed','Preparing','Packed','Shipping','Completed'].includes(o.status);
 if(!paid)return;
 let groups={};orderLines(o).forEach(l=>{let [cat,tag]=productMap(l.p),k=cat+'\u0001'+tag;(groups[k]??={category:cat,tag,amount:0}).amount+=l.qty*l.price});
 let vals=Object.values(groups);if(!vals.length)vals=[{category:'Other Income',tag:'Other Income',amount:+o.total||0}];
 let calc=vals.reduce((a,x)=>a+x.amount,0),delta=(+o.total||0)-calc;if(vals.length)vals[0].amount+=delta;
 D.income=D.income.filter(x=>!(x.source==='Farm Shop'&&x.refId===o.id));
 vals.forEach((g,i)=>D.income.push({id:id(),date:(o.paidDate||o.date||today()).slice(0,10),category:g.category,tag:g.tag,name:`Order ${o.no}${vals.length>1?' #'+(i+1):''}`,amount:g.amount,source:'Farm Shop',refId:o.id}));
 sv('income');
};
/* Upgrade historical/paid orders using the configured mapping. */
(D.orders||[]).forEach(o=>{if(D.income.some(x=>x.source==='Farm Shop'&&x.refId===o.id)||o.cashReceived)syncShopIncomeV1078(o)});

/* Wrap status/cash paths so dashboard and history stay synchronized. */
const oldSetOrder=window.setOrder;
window.setOrder=function(i,s,note=''){oldSetOrder(i,s,note);let o=D.orders.find(x=>x.id===i);if(o&&['Confirmed','Preparing','Packed','Shipping','Completed'].includes(s))syncShopIncomeV1078(o)};
const oldReceiveCash=window.receiveCashV1043;
if(oldReceiveCash)window.receiveCashV1043=function(i){oldReceiveCash(i);syncShopIncomeV1078(D.orders.find(x=>x.id===i))};

function paid(o){return o.cashReceived||D.income.some(x=>x.source==='Farm Shop'&&x.refId===o.id)}
window.editShopSaleV1078=function(oid){
 const o=D.orders.find(x=>x.id===oid);if(!o)return;
 showEditModal('แก้ไขประวัติการขาย',`<div class="form">
 <div><label>Order</label><input value="${esc(o.no||'-')}" disabled></div>
 <div><label>ลูกค้า</label><input id="v78cust" value="${esc(o.customer||'')}"></div>
 <div><label>เบอร์โทร</label><input id="v78phone" value="${esc(o.phone||'')}"></div>
 <div><label>ยอดรวม</label><input id="v78total" type="number" min="0" step=".01" value="${+o.total||0}"></div>
 <div><label>สถานะ</label><select id="v78status">${['New','Accepted','Payment Submitted','Confirmed','Preparing','Packed','Shipping','Completed','Rejected','Cancelled'].map(x=>`<option ${o.status===x?'selected':''}>${x}</option>`).join('')}</select></div>
 </div><div class="helpbox">การแก้ยอดรวมของรายการที่ชำระแล้วจะ Sync รายได้ของ Order นี้ใหม่ แต่ไม่เปลี่ยนรายการสินค้าเดิม</div>`,()=>{
   o.customer=v78cust.value.trim();o.phone=v78phone.value.trim();o.total=+v78total.value||0;o.status=v78status.value;sv('orders');if(paid(o))syncShopIncomeV1078(o);logAudit('EDIT','Farm Shop Sale',o.id,`${o.no} ฿${o.total}`);closeEditModal();shopSalesHistoryV1078();
 });
};
window.deleteShopSaleV1078=function(oid){
 const o=D.orders.find(x=>x.id===oid);if(!o)return;
 if(!confirm(`ลบประวัติ Order ${o.no||''} ?\nรายการรายได้ที่เชื่อมกับ Order นี้จะถูกลบด้วย`))return;
 D.orders=D.orders.filter(x=>x.id!==oid);D.income=D.income.filter(x=>!(x.source==='Farm Shop'&&x.refId===oid));sv('orders');sv('income');logAudit('DELETE','Farm Shop Sale',oid,o.no||'');shopSalesHistoryV1078();
};
window.shopSalesHistoryV1078=function(){
 const rows=(D.orders||[]).slice().sort((a,b)=>String(b.created||b.date||'').localeCompare(String(a.created||a.date||'')));
 content.innerHTML=`<div class="pageHero"><div><span class="eyebrow">FARM SHOP SALES</span><h2>ประวัติการซื้อขายร้านค้า</h2><p>Order และรายได้ที่เชื่อมกับ Dashboard</p></div><button class="btn2" onclick="shopadmin()">← จัดการสินค้า</button></div>
 <div class="card"><div class="tableWrap"><table><tr><th>Order</th><th>วันที่</th><th>ลูกค้า</th><th>รายการ</th><th>ยอด</th><th>Income</th><th>สถานะ</th><th class="purchase-actions-v1074">จัดการ</th></tr>
 ${rows.map(o=>{let inc=D.income.filter(x=>x.source==='Farm Shop'&&x.refId===o.id),ic=[...new Set(inc.map(x=>x.category))].join(', ')||'-';return `<tr><td>${esc(o.no||'-')}</td><td>${esc((o.date||o.created||'-').slice(0,10))}</td><td>${esc(o.customer||'-')}</td><td>${esc(orderLines(o).map(x=>x.name+' × '+x.qty).join(', ')||'-')}</td><td>฿${money(o.total)}</td><td>${esc(ic)}</td><td>${esc(o.status||'-')}</td><td class="purchase-actions-v1074"><button class="btn2 purchase-icon-btn" title="แก้ไข" onclick="editShopSaleV1078('${o.id}')">✏️</button><button class="btn2 dangerBtn purchase-icon-btn" title="ลบ" onclick="deleteShopSaleV1078('${o.id}')">🗑️</button></td></tr>`}).join('')||'<tr><td colspan="8">ยังไม่มีประวัติการซื้อขาย</td></tr>'}</table></div></div>`;
};
/* Add direct access from Shop Admin without replacing existing catalog. */
const oldShopAdmin=window.shopadmin;
window.shopadmin=function(){oldShopAdmin();let hero=document.querySelector('#content .pageHero');if(hero&&!document.querySelector('.sales-history-v1078'))hero.insertAdjacentHTML('beforeend',`<button class="btn2 sales-history-v1078" onclick="shopSalesHistoryV1078()">🧾 ประวัติการซื้อขาย</button>`)};
})();
