'use strict';
/* DinDee Farm V10.8.17 — Flow 4 finance/dashboard reconciliation + transaction center */
(function(){
 const num=v=>Number(v)||0;
 const realExpenses=()=> (D.expenses||[]).filter(e=>e.source!=='Purchase');
 const sourceOf=(x,type)=> type==='Cost'?'Direct Cost':(x.source||(type==='Income'||type==='Expense'?'Manual':'-'));
 const refOf=x=>window.friendlyRefV10821?window.friendlyRefV10821(x._source||x.source,x.refId,x):(x.refId||x.orderNo||x.no||x.id||'-');
 const fundName=fid=>{const f=(D.funds||[]).find(z=>z.id===fid);return f?(f.project||f.sponsor||'-'):'-'};
 const inside=(date,s,e)=>!s&&!e?true:(!s||date>=s)&&(!e||date<=e);
 function fundReceivedDate(f){
   if(f.date||f.startDate||f.createdDate)return f.date||f.startDate||f.createdDate;
   const dates=[...(D.purchases||[]).filter(x=>x.fundId===f.id).map(x=>x.date),...realExpenses().filter(x=>x.fundId===f.id).map(x=>x.date)].filter(Boolean).sort();
   return dates[0]||'';
 }
 function sponsorReceivedForMonth(key){return (D.funds||[]).filter(f=>(fundReceivedDate(f)||'').startsWith(key)).reduce((a,f)=>a+num(f.amount),0)}
 function cashExpenseRows(){return [...realExpenses(),...(D.purchases||[]).map(x=>({...x,amount:num(x.total),source:'Purchase',name:x.item||x.name}))]}
 function operatingIncomeRows(){return D.income||[]}
 function allTransactions(){
   return [
    ...operatingIncomeRows().map(x=>({...x,_kind:'Income',_amount:num(x.amount??x.total),_source:sourceOf(x,'Income')})),
    ...realExpenses().map(x=>({...x,_kind:'Expense',_amount:num(x.amount??x.total),_source:sourceOf(x,'Expense')})),
    ...(D.purchases||[]).map(x=>({...x,_kind:'Expense',_amount:num(x.total),_source:'Purchase',name:x.item||x.name})),
    ...(D.costs||[]).map(x=>({...x,_kind:'Cost',_amount:num(x.amount??x.total),_source:'Direct Cost'}))
   ];
 }
 window.sixMonthChart=function(){
   const now=new Date(),rows=[];
   for(let i=5;i>=0;i--){
    const d=new Date(now.getFullYear(),now.getMonth()-i,1),key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
    const inc=operatingIncomeRows().filter(x=>(x.date||'').startsWith(key)).reduce((a,x)=>a+num(x.amount??x.total),0);
    const ex=cashExpenseRows().filter(x=>(x.date||'').startsWith(key)).reduce((a,x)=>a+num(x.amount??x.total),0);
    rows.push({label:d.toLocaleDateString('th-TH',{month:'short'}),inc,ex,sponsor:sponsorReceivedForMonth(key),net:inc-ex});
   }
   const mx=Math.max(1,...rows.flatMap(x=>[x.inc,x.ex,x.sponsor]));
   return `<div class="trendLegend v10817-legend"><span>■ รายได้ดำเนินงาน</span><span>■ รายจ่ายเงินสด</span><span>■ Sponsor รับเข้า</span><span>● ผลต่าง = รายได้ − รายจ่าย</span></div><div class="trend6">${rows.map(x=>`<div class="trendCol"><div class="trendBars"><i title="รายได้ ฿${money(x.inc)}" style="height:${x.inc/mx*170}px"></i><i title="รายจ่าย ฿${money(x.ex)}" style="height:${x.ex/mx*170}px"></i><i title="Sponsor รับเข้า ฿${money(x.sponsor)}" style="height:${x.sponsor/mx*170}px"></i></div><b>${x.label}</b><small title="ผลต่างรายได้ดำเนินงานหักรายจ่าย">${x.net>=0?'+':''}${money(x.net)}</small><div class="trend-values-v10817">รายรับ ${money(x.inc)}<br>รายจ่าย ${money(x.ex)}<br>Sponsor ${money(x.sponsor)}</div></div>`).join('')}</div><div class="small muted">Sponsor แสดงเงินสนับสนุนที่ได้รับ ไม่รวมในผลต่างการดำเนินงาน • ต้นทุนทางตรงไม่ถูกนับเป็นรายจ่ายเงินสดซ้ำ</div>`;
 };
 window.dashboard=function(){
   if(me.role==='Staff'&&typeof staffDash==='function')return staffDash();
   const now=today(),defS=now.slice(0,7)+'-01',S=window.dashS||defS,E=window.dashE||now,ok=x=>inside(x.date||'',S,E);
   const incRows=operatingIncomeRows().filter(ok),expRows=cashExpenseRows().filter(ok);
   const inc=incRows.reduce((a,x)=>a+num(x.amount??x.total),0),ex=expRows.reduce((a,x)=>a+num(x.amount??x.total),0),profit=inc-ex,margin=inc?profit/inc*100:0;
   const sponsorTotal=(D.funds||[]).reduce((a,f)=>a+num(f.amount),0),sponsorSpent=(D.funds||[]).reduce((a,f)=>a+(D.purchases||[]).filter(x=>x.fundId===f.id).reduce((q,x)=>q+num(x.total),0)+realExpenses().filter(x=>x.fundId===f.id).reduce((q,x)=>q+num(x.amount),0),0);
   const latest=allTransactions().filter(ok).sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,10);
   const bars=(rows,key)=>{const m={};rows.forEach(x=>{const k=x[key]||'Other';m[k]=(m[k]||0)+num(x.amount??x.total)});const mx=Math.max(1,...Object.values(m));return Object.entries(m).map(([k,v])=>`<div class="miniBar"><div><span>${esc(k)}</span><b>฿${money(v)}</b></div><i><em style="width:${v/mx*100}%"></em></i></div>`).join('')||'<span class="muted">ยังไม่มีข้อมูลในช่วงนี้</span>'};
   const pm={};incRows.forEach(x=>{const k=x.product||x.name||x.category||'ไม่ระบุสินค้า';(pm[k]??={income:0,cost:0}).income+=num(x.amount)});(D.costs||[]).filter(ok).forEach(x=>{const k=x.product||x.name||x.category||'ไม่ระบุสินค้า';(pm[k]??={income:0,cost:0}).cost+=num(x.amount??x.total)});
   const profitTable=Object.entries(pm).map(([name,v])=>`<tr><td>${esc(name)}</td><td>฿${money(v.income)}</td><td>฿${money(v.cost)}</td><td>฿${money(v.income-v.cost)}</td></tr>`).join('')||'<tr><td colspan="4">ยังไม่มีข้อมูลสินค้า/ผลผลิต</td></tr>';
   content.innerHTML=`<div class="pageHero"><div><span class="eyebrow">FARM OVERVIEW</span><h2>ภาพรวมฟาร์ม</h2><p>การเงิน การดำเนินงาน และเงินสนับสนุนในมุมมองเดียว</p></div></div><div class="card"><div class="form"><div><label>ตั้งแต่วันที่</label><input id="ds" type="date" value="${S}"></div><div><label>ถึงวันที่</label><input id="de" type="date" value="${E}"></div></div><br><button class="btn" onclick="window.dashS=ds.value;window.dashE=de.value;dashboard()">แสดงผล</button> <button class="btn2" onclick="window.dashS='${defS}';window.dashE='${now}';dashboard()">เดือนนี้</button></div><div class="grid4"><div class="metric">รายได้จากการดำเนินงาน<b>฿${money(inc)}</b></div><div class="metric">รายจ่ายเงินสด<b>฿${money(ex)}</b></div><div class="metric">ผลการดำเนินงาน<b>฿${money(profit)}</b></div><div class="metric">Margin<b>${margin.toFixed(1)}%</b></div></div><div class="grid3 sponsorDash"><div class="metric">🤝 เงินสนับสนุนทั้งหมด<b>฿${money(sponsorTotal)}</b></div><div class="metric">🧾 Sponsor ใช้แล้ว<b>฿${money(sponsorSpent)}</b></div><div class="metric">🟢 Sponsor คงเหลือ<b>฿${money(sponsorTotal-sponsorSpent)}</b></div></div><div class="grid2"><div class="card"><h3>💰 รายรับมาจากอะไรบ้าง</h3>${bars(incRows,'category')}</div><div class="card"><h3>🧾 รายจ่ายตามประเภท</h3>${bars(expRows,'category')}</div></div><div class="grid2"><div class="card"><h3>💹 กำไรตามสินค้า / ผลผลิต</h3><table><tr><th>สินค้า / ผลผลิต</th><th>รายรับ</th><th>ต้นทุน</th><th>กำไร/ขาดทุน</th></tr>${profitTable}</table></div><div class="card"><div class="sectionTitle"><h3>🕘 รายการล่าสุด</h3><button class="btn2" onclick="go('finance')">ดูรายการทั้งหมด →</button></div><div class="tableWrap"><table><tr><th>วันที่</th><th>รายการ</th><th>ประเภท</th><th>ที่มา</th><th>Ref.</th><th>จำนวน</th></tr>${latest.map(x=>`<tr><td>${esc(x.date||'-')}</td><td>${esc(x.name||x.item||x.product||'-')}</td><td>${x._kind==='Income'?'รายรับ':x._kind==='Expense'?'รายจ่าย':'ต้นทุน'}</td><td><span class="pill">${esc(x._source)}</span></td><td>${esc(refOf(x))}</td><td>฿${money(x._amount)}</td></tr>`).join('')||'<tr><td colspan="6">ยังไม่มีรายการ</td></tr>'}</table></div></div></div><div class="card"><h3>📅 แนวโน้ม 6 เดือนล่าสุด</h3>${sixMonthChart()}</div>`;
 };
 function financeFilteredRows(){
   const f=window.financeFilterV10817||{},q=String(f.q||'').toLowerCase();
   return allTransactions().filter(x=>inside(x.date||'',f.start||'',f.end||'')&&(!f.type||f.type==='All'||x._kind===f.type)&&(!f.source||f.source==='All'||x._source===f.source)&&(!f.category||f.category==='All'||x.category===f.category)&&(!f.fundId||f.fundId==='All'||x.fundId===f.fundId)&&(!q||[x.name,x.item,x.product,x.category,x.tag,x._source,refOf(x)].some(v=>String(v||'').toLowerCase().includes(q)))).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
 }
 window.applyFinanceFilterV10817=function(){window.financeFilterV10817={start:tfStart.value,end:tfEnd.value,type:tfType.value,source:tfSource.value,category:tfCat.value,fundId:tfFund.value,q:tfQ.value};finance()};
 window.clearFinanceFilterV10817=function(){window.financeFilterV10817={};finance()};
 const prevFinance=window.finance;
 window.finance=function(){
   prevFinance();
   const f=window.financeFilterV10817||{},r=financeFilteredRows(),inc=r.filter(x=>x._kind==='Income').reduce((a,x)=>a+x._amount,0),ex=r.filter(x=>x._kind==='Expense').reduce((a,x)=>a+x._amount,0),cost=r.filter(x=>x._kind==='Cost').reduce((a,x)=>a+x._amount,0);
   const cats=[...new Set(allTransactions().map(x=>x.category).filter(Boolean))].sort(),sources=[...new Set(allTransactions().map(x=>x._source).filter(Boolean))].sort();
   const card=[...content.querySelectorAll('.card')].find(z=>z.querySelector('h3')?.textContent.trim()==='รายการบัญชี');
   if(!card)return;
   card.innerHTML=`<div class="sectionTitle"><div><h3>📒 รายการบัญชีทั้งหมด (Transactions)</h3><span class="muted">รวมรายรับ รายจ่าย และต้นทุนทางตรง พร้อมระบุ Source • ต้นทุนทางตรงแสดงเพื่อวิเคราะห์ แต่ไม่บวกซ้ำเป็นรายจ่ายเงินสด</span></div></div><div class="finance-filter-v10817"><input id="tfStart" type="date" value="${esc(f.start||'')}" title="ตั้งแต่วันที่"><input id="tfEnd" type="date" value="${esc(f.end||'')}" title="ถึงวันที่"><select id="tfType"><option value="All">ทุกประเภท</option><option value="Income" ${f.type==='Income'?'selected':''}>รายรับ</option><option value="Expense" ${f.type==='Expense'?'selected':''}>รายจ่าย</option><option value="Cost" ${f.type==='Cost'?'selected':''}>ต้นทุนทางตรง</option></select><select id="tfSource"><option value="All">ทุก Source</option>${sources.map(s=>`<option ${f.source===s?'selected':''}>${esc(s)}</option>`).join('')}</select><select id="tfCat"><option value="All">ทุก Category</option>${cats.map(s=>`<option ${f.category===s?'selected':''}>${esc(s)}</option>`).join('')}</select><select id="tfFund"><option value="All">ทุก Fund</option>${(D.funds||[]).map(z=>`<option value="${z.id}" ${f.fundId===z.id?'selected':''}>${esc(z.project||z.sponsor||z.id)}</option>`).join('')}</select><input id="tfQ" value="${esc(f.q||'')}" placeholder="ค้นหารายการ / Ref."><button class="btn" onclick="applyFinanceFilterV10817()">กรอง</button><button class="btn2" onclick="clearFinanceFilterV10817()">ล้าง Filter</button></div><div class="grid4 finance-summary-v10817"><div class="metric">รายรับตาม Filter<b>฿${money(inc)}</b></div><div class="metric">รายจ่ายตาม Filter<b>฿${money(ex)}</b></div><div class="metric">ผลต่าง<b>฿${money(inc-ex)}</b></div><div class="metric">ต้นทุนทางตรง<b>฿${money(cost)}</b></div></div><div class="tableWrap"><table><tr><th>วันที่</th><th>ประเภท</th><th>รายการ</th><th>Category / Tag</th><th>Source</th><th>Ref.</th><th>Fund</th><th>จำนวน</th><th>จัดการ</th></tr>${r.map(x=>{let act=x._kind==='Cost'?'<span class="small muted">🔒 ต้นทาง</span>':(['Purchase','Farm Shop'].includes(x._source)?'<span class="small muted">🔒 ต้นทาง</span>':`<button class="btn2 purchase-icon-btn" title="แก้ไข" onclick="editFinanceV10816('${x._kind}','${x.id}')">✏️</button> <button class="btn2 dangerBtn purchase-icon-btn" title="ลบ" onclick="deleteFinanceV10816('${x._kind}','${x.id}')">🗑️</button>`);return `<tr><td>${esc(x.date||'-')}</td><td>${x._kind==='Income'?'รายรับ':x._kind==='Expense'?'รายจ่าย':'ต้นทุน'}</td><td>${esc(x.name||x.item||x.product||'-')}</td><td>${esc(x.category||'-')}<br><span class="small">${esc(x.tag||'-')}</span></td><td><span class="pill">${esc(x._source)}</span></td><td>${esc(refOf(x))}</td><td>${esc(fundName(x.fundId))}</td><td>฿${money(x._amount)}</td><td>${act}</td></tr>`}).join('')||'<tr><td colspan="9">ไม่พบรายการตาม Filter</td></tr>'}</table></div>`;
 };
 const oldAddFund=window.addFund;
 window.addFund=function(){const before=(D.funds||[]).length;oldAddFund();if((D.funds||[]).length>before){const f=D.funds[D.funds.length-1];if(f&&!f.date){f.date=today();sv('funds')}}};
})();
