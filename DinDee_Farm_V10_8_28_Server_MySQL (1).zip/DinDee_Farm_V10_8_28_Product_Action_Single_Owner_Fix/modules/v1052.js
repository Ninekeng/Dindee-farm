/* DinDee Farm V10.5.2 - UI Action Fix + Purchase Import/Export + FEFO/FIFO */
(function(){
'use strict';
const isAdmin=()=>{try{return typeof me!=='undefined'&&!!me&&me.role==='Admin'}catch(e){return false}};
const save=k=>typeof sv==='function'&&sv(k);
const audit=(a,t,i,d)=>typeof logAudit==='function'&&logAudit(a,t,i,d||'');
const q=s=>document.querySelector(s);

/* ---------- Farm Analytics: reliable entry point ---------- */
window.openFarmAnalyticsV1052=function(){
  try{
    if(typeof window.farmAnalyticsV1045!=='function') throw new Error('ไม่พบ Farm Analytics');
    window.farmAnalyticsV1045();
    if(!document.querySelector('#content .pageHero') || !document.getElementById('content').textContent.includes('Farm Analytics')) throw new Error('หน้า Analytics ไม่ถูกแสดง');
    window.scrollTo({top:0,behavior:'smooth'});
  }catch(e){ console.error(e); alert('ไม่สามารถเปิด Farm Analytics: '+(e.message||e)); }
};
const dash1052=window.dashboard;
window.dashboard=function(){
  dash1052(); if(me.role==='Staff')return;
  document.querySelectorAll('.analyticsOpenV1045').forEach(b=>{b.setAttribute('onclick','openFarmAnalyticsV1052()');b.textContent='ดูรายละเอียดและวิเคราะห์ฟาร์ม →';});
};

/* ---------- Crop Cycle: visible safe-delete action ---------- */
const cycles1052=window.cycles;
window.cycles=function(){
  cycles1052(); if(!isAdmin())return;
  const table=[...document.querySelectorAll('#content table')].find(t=>t.textContent.includes('Cycle')&&t.textContent.includes('พืช'));
  if(!table)return;
  const head=table.rows[0]; if(head&&!head.textContent.includes('จัดการ')) head.insertAdjacentHTML('beforeend','<th>จัดการ</th>');
  [...table.rows].slice(1).forEach((tr,i)=>{const p=D.yearPlans[i];if(!p||tr.querySelector('.v1052-cycle-actions'))return;tr.insertAdjacentHTML('beforeend',`<td class="v1052-cycle-actions"><button class="btn2" onclick="editPlan('${p.id}')">✏️ แก้ไข</button> <button class="btn2 dangerBtn" onclick="deletePlan('${p.id}')">🗑️ ลบ</button></td>`);});
};

/* ---------- Stock: safe delete/archive ---------- */
window.deleteStockV1052=function(sid){
  if(!isAdmin())return alert('เฉพาะ Admin เท่านั้น');
  const s=D.stock.find(x=>x.id===sid); if(!s)return;
  const usages=D.usages.filter(x=>x.stockId===sid || (x.item===s.name && (x.lot||'')===(s.lot||'')));
  const purchases=D.purchases.filter(x=>x.stockId===sid || (x.item===s.name && (x.lot||'')===(s.lot||'')));
  if(usages.length||purchases.length){
    if(!confirm(`“${s.name}” Lot ${s.lot||'-'} มีประวัติซื้อ/เบิก ${purchases.length+usages.length} รายการ\nเพื่อรักษาประวัติ Stock และต้นทุน ระบบจะปิดใช้งานแทนการลบถาวร\n\nยืนยันหรือไม่?`))return;
    s.active=false;s.archived=true;s.archivedAt=new Date().toISOString();save('stock');audit('ARCHIVE','Stock',sid,s.name);render();return;
  }
  if(!confirm(`ยืนยันลบ Stock “${s.name}” Lot ${s.lot||'-'} ถาวร?`))return;
  D.stock=D.stock.filter(x=>x.id!==sid);save('stock');audit('DELETE','Stock',sid,s.name);render();
};
const stock1052=window.stock;
window.stock=function(){
  stock1052(); if(!isAdmin())return;
  document.querySelectorAll('#content button[onclick^="editStockV1043"],#content button[onclick^="editStockV101"],#content button[onclick^="editStock("]').forEach(b=>{
    const td=b.closest('td');if(!td||td.querySelector('.v1052-del-stock'))return;
    const m=(b.getAttribute('onclick')||'').match(/\('([^']+)'\)/);if(m)td.insertAdjacentHTML('beforeend',` <button class="btn2 dangerBtn v1052-del-stock" onclick="deleteStockV1052('${m[1]}')">🗑️ ลบ</button>`);
  });
};

/* ---------- House/Area: visible safe-delete action ---------- */
const houses1052=window.houses;
window.houses=function(){
  houses1052(); if(!isAdmin()||window.houseCenterId)return;
  document.querySelectorAll('#content button[onclick^="editHouseV101"]').forEach(b=>{
    const td=b.closest('td');if(!td||td.querySelector('.v1052-del-house')||td.querySelector('button[onclick^="deleteHouseV1051"]'))return;
    const m=(b.getAttribute('onclick')||'').match(/\('([^']+)'\)/);if(m)td.insertAdjacentHTML('beforeend',` <button class="btn2 dangerBtn v1052-del-house" onclick="deleteHouseV1051('${m[1]}')">🗑️ ลบ</button>`);
  });
};

/* ---------- Farm Shop: visible safe-delete action + modern order history check ---------- */
window.deleteProductV1052=function(pid){
  if(!isAdmin())return alert('เฉพาะ Admin เท่านั้น');
  const p=D.products.find(x=>x.id===pid);if(!p)return;
  const used=D.orders.some(o=>o.productId===pid || (o.items||[]).some(it=>it.productId===pid||it.id===pid));
  if(used){if(!confirm(`“${p.name}” มีประวัติ Order จึงลบถาวรไม่ได้\nต้องการ Archive / ปิดขายหรือไม่?`))return;p.status='ปิดขาย';p.archived=true;p.active=false;audit('ARCHIVE','Farm Shop',pid,p.name)}
  else {if(!confirm(`ยืนยันลบสินค้า “${p.name}” ถาวร?`))return;D.products=D.products.filter(x=>x.id!==pid);audit('DELETE','Farm Shop',pid,p.name)}
  save('products');render();
};
const shop1052=window.shopadmin;
window.shopadmin=function(){
  shop1052(); if(!isAdmin())return;
  document.querySelectorAll('#content button[onclick^="editProduct"]').forEach(b=>{const td=b.closest('td');if(!td||td.querySelector('.v1052-del-product')||td.querySelector('button[onclick^="deleteProduct("],button[onclick^="deleteProductV1052"]'))return;const m=(b.getAttribute('onclick')||'').match(/\('([^']+)'\)/);if(m)td.insertAdjacentHTML('beforeend',` <button class="btn2 dangerBtn v1052-del-product" onclick="deleteProductV1052('${m[1]}')">🗑️ ลบ</button>`);});
};

/* ---------- Sales Docs: visible safe-delete/cancel action ---------- */
const docs1052=window.salesDocsPage;
window.salesDocsPage=function(){
  docs1052(); if(!isAdmin())return;
  document.querySelectorAll('#content button[onclick^="editSalesDoc"]').forEach(b=>{const td=b.closest('td');if(!td||td.querySelector('.v1052-del-doc')||td.querySelector('button[onclick^="deleteSalesDocV1051"]'))return;const m=(b.getAttribute('onclick')||'').match(/\('([^']+)'\)/);if(m)td.insertAdjacentHTML('beforeend',` <button class="btn2 dangerBtn v1052-del-doc" onclick="deleteSalesDocV1051('${m[1]}')">🗑️ ลบ</button>`);});
};

/* ---------- Sponsor: visible safe-delete/close action ---------- */
const sponsor1052=window.sponsor;
window.sponsor=function(){
  sponsor1052(); if(!isAdmin())return;
  document.querySelectorAll('#content button[onclick^="editFund"]').forEach(b=>{const td=b.closest('td');if(!td||td.querySelector('.v1052-del-fund')||td.querySelector('button[onclick^="deleteFundV1051"]'))return;const m=(b.getAttribute('onclick')||'').match(/\('([^']+)'\)/);if(m)td.insertAdjacentHTML('beforeend',` <button class="btn2 dangerBtn v1052-del-fund" onclick="deleteFundV1051('${m[1]}')">🗑️ ลบ</button>`);});
};

/* ---------- Usage: FEFO if expiry exists, FIFO if no expiry ---------- */
window.usage=function(){
  const valid=D.stock.filter(s=>+s.qty>0&&s.active!==false&&(!s.expiryDate||s.expiryDate>=today()));
  const lots=valid.slice().sort((a,b)=>{
    const ae=!!a.expiryDate,be=!!b.expiryDate;
    if(ae&&be)return a.expiryDate.localeCompare(b.expiryDate); // FEFO
    if(ae!==be)return ae?-1:1; // expiring lots first
    const ad=a.receivedDate||a.date||D.purchases.find(p=>p.item===a.name&&(p.lot||'')===(a.lot||''))?.date||'9999-12-31';
    const bd=b.receivedDate||b.date||D.purchases.find(p=>p.item===b.name&&(p.lot||'')===(b.lot||''))?.date||'9999-12-31';
    return ad.localeCompare(bd); // FIFO
  });
  content.innerHTML=`<div class="card"><h3>📤 เบิกใช้วัตถุดิบตาม Lot</h3><p class="small">ระบบแนะนำ <b>FEFO</b> สำหรับ Lot ที่มีวันหมดอายุ และ <b>FIFO</b> สำหรับ Lot ที่ไม่มีวันหมดอายุ</p><div class="form"><div><label>วันที่</label><input id="ud" type="date" value="${today()}"></div><div><label>โรง/พื้นที่</label><select id="uh">${opt(D.houses)}</select></div><div class="span2"><label>วัตถุดิบ / Lot</label><select id="ui">${lots.map((s,i)=>`<option value="${s.id}">${i===0?'⭐ ':''}${esc(s.name)} | Lot: ${esc(s.lot||'-')} | เหลือ ${+s.qty||0} ${esc(s.unit||'')} | ${s.expiryDate?'หมดอายุ '+s.expiryDate:'FIFO'}</option>`).join('')}</select></div><div><label>จำนวน</label><input id="uq" type="number" step=".01"></div><div><label>หมายเหตุ</label><input id="un"></div></div><br><button class="btn" onclick="addUsageV1043()">เบิก</button></div><div class="card"><table><tr><th>วันที่</th><th>พื้นที่</th><th>รายการ / Lot</th><th>จำนวน</th><th>หมายเหตุ</th></tr>${D.usages.slice().reverse().map(x=>`<tr><td>${x.date}</td><td>${esc(D.houses.find(h=>h.id===x.houseId)?.name||'-')}</td><td>${esc(x.item)}<br><span class="muted">Lot: ${esc(x.lot||'-')}</span></td><td>${x.qty} ${esc(x.unit||'')}</td><td>${esc(x.note||'')}</td></tr>`).join('')}</table></div>`;
};

/* ---------- Purchase Import/Export directly on Purchase page ---------- */
function csvParse(t){let rows=[],row=[],v='',quoted=false;for(let i=0;i<t.length;i++){let c=t[i],n=t[i+1];if(c==='"'){if(quoted&&n==='"'){v+='"';i++}else quoted=!quoted}else if(c===','&&!quoted){row.push(v);v=''}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&n==='\n')i++;row.push(v);if(row.some(x=>String(x).trim()))rows.push(row);row=[];v=''}else v+=c}row.push(v);if(row.some(x=>String(x).trim()))rows.push(row);return rows}
function csv(rows){return '\ufeff'+rows.map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\r\n')}
window.downloadPurchaseTemplateV1052=function(){dl('DinDee_Purchase_Template_V10_5_2.csv',csv([['Date','Item','Category','Tag','Supplier','Lot','ProductionStart','MfgDate','ExpiryDate','Qty','Unit','Total','Fund'],[today(),'เมล็ดเคล','Crop Production','Seeds & Seedlings','','LOT-001','','','',10,'pack',500,'']]),'text/csv;charset=utf-8')};
window.exportPurchasesV1052=function(){dl('DinDee_Purchases_'+today()+'.csv',csv([['Date','Item','Category','Tag','Supplier','Lot','ProductionStart','MfgDate','ExpiryDate','Qty','Unit','Total','Fund'],...D.purchases.map(x=>[x.date,x.item,x.category,x.tag,x.supplier,x.lot,x.productionStart,x.mfgDate,x.expiryDate,x.qty,x.unit,x.total,D.funds.find(f=>f.id===x.fundId)?.project||''])]),'text/csv;charset=utf-8')};
window.importPurchaseV1052=function(){
  const f=q('#purchaseImportFileV1052')?.files?.[0];if(!f)return alert('กรุณาเลือกไฟล์ CSV');if(!/\.csv$/i.test(f.name))return alert('เวอร์ชันนี้ Import ผ่าน CSV ซึ่งเปิด/บันทึกจาก Excel ได้');
  const r=new FileReader();r.onload=()=>{const rows=csvParse(r.result);if(rows.length<2)return alert('ไม่พบข้อมูลในไฟล์');const h=rows[0].map(x=>String(x).replace(/^\ufeff/,'').trim());const objs=rows.slice(1).map(a=>Object.fromEntries(h.map((k,i)=>[k,String(a[i]??'').trim()])));const validCats=window.DinDee?.master?.expenseCats||[];const units=D.units.filter(x=>x.active!==false).map(x=>x.name);const checked=objs.map((x,i)=>{let e=[];if(!x.Date||!x.Item)e.push('วันที่/รายการว่าง');if(validCats.length&&!validCats.includes(x.Category))e.push('Category ไม่ตรง Master');if((window.TAGS?.[x.Category]||[]).length&&!(TAGS[x.Category]||[]).includes(x.Tag))e.push('Tag ไม่ตรง Master');if(units.length&&!units.includes(x.Unit))e.push('Unit ไม่ตรง Settings');if(!(Number(x.Qty)>0))e.push('Qty ไม่ถูกต้อง');if(isNaN(Number(x.Total)))e.push('Total ไม่ถูกต้อง');if(x.MfgDate&&x.ExpiryDate&&x.MfgDate>x.ExpiryDate)e.push('วันหมดอายุก่อนวันผลิต');const dup=D.purchases.some(p=>p.date===x.Date&&p.item===x.Item&&(p.lot||'')===(x.Lot||'')&&+p.qty===+x.Qty&&+p.total===+x.Total);if(dup)e.push('ข้อมูลซ้ำกับรายการเดิม');return{x,e,row:i+2}});window._purchaseImportV1052=checked;const ok=checked.filter(z=>!z.e.length).length,bad=checked.length-ok;showEditModal('📥 Preview Import Purchase',`<p><b>${esc(f.name)}</b> — ทั้งหมด ${checked.length} | ผ่าน ${ok} | ผิด/ซ้ำ ${bad}</p><div class="scroll"><table><tr><th>Row</th><th>รายการ</th><th>Lot</th><th>จำนวน</th><th>ผลตรวจ</th></tr>${checked.slice(0,150).map(z=>`<tr class="${z.e.length?'preview-bad':'preview-ok'}"><td>${z.row}</td><td>${esc(z.x.Item)}</td><td>${esc(z.x.Lot||'-')}</td><td>${esc(z.x.Qty)} ${esc(z.x.Unit)}</td><td>${z.e.length?esc(z.e.join(', ')):'✓ พร้อม Import'}</td></tr>`).join('')}</table></div><p class="small">จะบันทึกเฉพาะรายการที่ผ่านการตรวจสอบ และสร้าง Purchase + Stock + Expense ให้พร้อมกัน</p>`,()=>commitPurchaseV1052());};r.readAsText(f,'utf-8');
};
window.commitPurchaseV1052=function(){const rows=(window._purchaseImportV1052||[]).filter(z=>!z.e.length);if(!rows.length)return alert('ไม่มีรายการที่พร้อม Import');const batch='IMP-'+Date.now();rows.forEach(({x})=>{let supplier=(D.suppliers||[]).find(s=>s.name===x.Supplier);let fund=(D.funds||[]).find(f=>f.id===x.Fund||f.project===x.Fund||f.sponsor===x.Fund);let p={id:id(),date:x.Date,item:x.Item,category:x.Category,tag:x.Tag,supplierId:supplier?.id||'',supplier:x.Supplier,lot:x.Lot,productionStart:x.ProductionStart||'',mfgDate:x.MfgDate||'',expiryDate:x.ExpiryDate||'',qty:+x.Qty,unit:x.Unit,total:+x.Total,fundId:fund?.id||'',evidence:'',importBatch:batch};D.purchases.push(p);let st=D.stock.find(z=>z.name===p.item&&z.category===p.category&&z.unit===p.unit&&(z.lot||'')===(p.lot||'')&&(z.expiryDate||'')===(p.expiryDate||''));if(st){st.qty=(+st.qty||0)+p.qty;Object.assign(st,{supplierId:p.supplierId,supplier:p.supplier,productionStart:p.productionStart,mfgDate:p.mfgDate,expiryDate:p.expiryDate,active:true})}else D.stock.push({id:id(),category:p.category,name:p.item,qty:p.qty,unit:p.unit,supplierId:p.supplierId,supplier:p.supplier,lot:p.lot,img:'',tag:p.tag,productionStart:p.productionStart,mfgDate:p.mfgDate,expiryDate:p.expiryDate,active:true});D.expenses.push({id:id(),date:p.date,category:p.category,tag:p.tag,name:p.item,amount:p.total,source:'Purchase',refId:p.id,fundId:p.fundId,importBatch:batch})});['purchases','stock','expenses'].forEach(save);audit('IMPORT','Purchase',batch,rows.length+' rows');closeEditModal();alert('Import Purchase สำเร็จ '+rows.length+' รายการ');render()};
const purchase1052=window.purchase;
window.purchase=function(){purchase1052();if(!isAdmin())return;const hero=document.querySelector('#content .pageHero');if(hero&&!document.querySelector('.purchase-transfer-v1052'))hero.insertAdjacentHTML('afterend',`<div class="card purchase-transfer-v1052"><div class="sectionTitle"><div><h3>📥 Import / Export รายการซื้อจำนวนมาก</h3><span class="muted">ใช้ CSV ที่เปิดและบันทึกด้วย Excel ได้ พร้อม Preview และตรวจข้อมูลซ้ำก่อนบันทึก</span></div></div><button class="btn2" onclick="downloadPurchaseTemplateV1052()">📄 ดาวน์โหลด Template</button> <button class="btn2" onclick="exportPurchasesV1052()">📤 Export CSV</button><br><br><input id="purchaseImportFileV1052" type="file" accept=".csv,text/csv" style="max-width:360px"> <button class="btn" onclick="importPurchaseV1052()">📥 ตรวจสอบ / Preview Import</button></div>`);};
})();
