/* DinDee Farm V10.8.1 — Stock Movement: general use, return, cancel, test-mode hard delete */
(function(){
'use strict';
const n=x=>Number(x)||0;
function setting(){
 D.appSettings=D.appSettings||{};
 if(typeof D.appSettings.allowHardDeleteUsage!=='boolean')D.appSettings.allowHardDeleteUsage=true;
 try{localStorage.setItem('dindee_v7_appSettings',JSON.stringify(D.appSettings))}catch(e){}
 return D.appSettings;
}
function saveSetting(){try{localStorage.setItem('dindee_v7_appSettings',JSON.stringify(D.appSettings||{}))}catch(e){}}
setting();
function stockOf(u){return D.stock.find(s=>s.id===u.stockId)}
function restore(u,q){const s=stockOf(u);if(s)s.qty=n(s.qty)+n(q)}
function activeUsage(u){return u.status!=='Cancelled'}
function usePlace(u){if(u.useType==='General')return u.purpose||'งานทั่วไป';if(u.useType==='Learning')return 'ศูนย์เรียนรู้ / กิจกรรม';if(u.useType==='Food')return 'อาหาร / เครื่องดื่ม';if(u.useType==='Maintenance')return 'ซ่อมบำรุง';if(u.useType==='Project')return 'โครงการ / ทรัพย์สิน';if(u.useType==='Other')return u.purpose||'อื่น ๆ';return (D.houses.find(h=>h.id===u.houseId)||{}).name||u.purpose||'-'}
function typeOptions(sel='House'){return [['House','โรงเรือน / พื้นที่ผลิต'],['General','งานทั่วไป'],['Learning','ศูนย์เรียนรู้ / กิจกรรม'],['Food','อาหาร / เครื่องดื่ม'],['Maintenance','ซ่อมบำรุง'],['Project','โครงการ / ทรัพย์สิน'],['Other','อื่น ๆ']].map(([v,t])=>`<option value="${v}" ${v===sel?'selected':''}>${t}</option>`).join('')}
window.toggleUsagePlaceV1081=function(){const t=document.getElementById('v81type')?.value||'House',h=document.getElementById('v81house');if(h)h.disabled=t!=='House'};

/* Replace the usage page with a compatible movement-oriented UI while keeping the same D.usages data. */
window.usage=function(){
 const lots=D.stock.filter(s=>n(s.qty)>0&&s.active!==false&&(!s.expiryDate||s.expiryDate>=today())).sort((a,b)=>(a.expiryDate||'9999').localeCompare(b.expiryDate||'9999'));
 content.innerHTML=`<div class="card"><h3>📤 เบิกใช้วัตถุดิบ / Stock Movement</h3><div class="form">
 <div><label>วันที่</label><input id="v81date" type="date" value="${today()}"></div>
 <div><label>นำไปใช้ที่</label><select id="v81type" onchange="toggleUsagePlaceV1081()">${typeOptions()}</select></div>
 <div><label>โรงเรือน / พื้นที่</label><select id="v81house">${D.houses.filter(x=>x.active!==false).map(h=>`<option value="${h.id}">${esc(h.name)}</option>`).join('')}</select></div>
 <div><label>วัตถุดิบ / Lot</label><select id="v81stock">${lots.map(s=>`<option value="${s.id}">${esc(s.name)} | Lot ${esc(s.lot||'-')} | เหลือ ${n(s.qty)} ${esc(s.unit||'')}</option>`).join('')}</select></div>
 <div><label>จำนวน</label><input id="v81qty" type="number" min=".01" step=".01"></div>
 <div class="span2"><label>วัตถุประสงค์ / หมายเหตุ</label><input id="v81purpose" placeholder="เช่น ทำความสะอาดพื้นที่ส่วนกลาง"></div>
 </div><br><button class="btn" onclick="addUsageV1081()">📤 เบิกใช้งาน</button></div>
 <div class="card"><div class="sectionTitle"><div><h3>ประวัติ Stock Movement</h3><span class="small">แก้ไข • คืน Stock • ยกเลิก • ลบข้อมูลทดสอบ</span></div></div>
 <div class="tableWrap"><table><tr><th>วันที่</th><th>วัตถุดิบ / Lot</th><th>จำนวน</th><th>จุดใช้งาน</th><th>หมายเหตุ</th><th>สถานะ</th><th>จัดการ</th></tr>
 ${D.usages.slice().reverse().map(u=>`<tr><td>${esc(u.date||'-')}</td><td>${esc(u.item||'-')}<br><span class="small">Lot ${esc(u.lot||'-')}</span></td><td>${n(u.qty)} ${esc(u.unit||'')}</td><td>${esc(usePlace(u))}</td><td>${esc(u.note||u.purpose||'')}</td><td>${u.status==='Cancelled'?'❌ ยกเลิก':u.returnedQty?`↩️ คืนแล้ว ${n(u.returnedQty)} ${esc(u.unit||'')}`:'ใช้งาน'}</td><td><button class="btn2 purchase-icon-btn" title="แก้ไข" onclick="editUsageV1081('${u.id}')">✏️</button>${activeUsage(u)?`<button class="btn2 purchase-icon-btn" title="คืน Stock" onclick="returnUsageV1081('${u.id}')">↩️</button><button class="btn2 purchase-icon-btn" title="ยกเลิก" onclick="cancelUsageV1081('${u.id}')">❌</button>`:''}${me?.role==='Admin'&&setting().allowHardDeleteUsage?`<button class="btn2 dangerBtn purchase-icon-btn" title="ลบถาวร (Test Mode)" onclick="hardDeleteUsageV1081('${u.id}')">🗑️</button>`:''}</td></tr>`).join('')||'<tr><td colspan="7">ยังไม่มีรายการ</td></tr>'}</table></div></div>`;
};
window.addUsageV1081=function(){
 const s=D.stock.find(x=>x.id===v81stock.value),q=n(v81qty.value),typ=v81type.value;if(!s||q<=0)return alert('กรุณาเลือกวัตถุดิบและจำนวน');if(q>n(s.qty))return alert(`Stock Lot นี้เหลือ ${s.qty} ${s.unit||''}`);
 s.qty=n(s.qty)-q;D.usages.push({id:id(),date:v81date.value,useType:typ,houseId:typ==='House'?v81house.value:'',stockId:s.id,item:s.name,lot:s.lot||'',qty:q,unit:s.unit||'',purpose:v81purpose.value.trim(),note:v81purpose.value.trim(),status:'Used',returnedQty:0});
 sv('stock');sv('usages');logAudit('CREATE','Usage',s.id,`${s.name} Lot ${s.lot||'-'} ${q} ${s.unit||''} → ${typ}`);usage();
};
window.editUsageV1081=function(uid){
 const u=D.usages.find(x=>x.id===uid);if(!u||!activeUsage(u))return alert('รายการนี้ถูกยกเลิกแล้ว');
 const lots=D.stock.filter(s=>s.active!==false&&(n(s.qty)>0||s.id===u.stockId));
 showEditModal('✏️ แก้ไขรายการเบิก',`<div class="form">
 <div><label>วันที่</label><input id="v81ed" type="date" value="${esc(u.date||today())}"></div>
 <div><label>นำไปใช้ที่</label><select id="v81et">${typeOptions(u.useType||'House')}</select></div>
 <div><label>โรงเรือน / พื้นที่</label><select id="v81eh"><option value="">-- ไม่ระบุ --</option>${D.houses.filter(x=>x.active!==false).map(h=>`<option value="${h.id}" ${h.id===u.houseId?'selected':''}>${esc(h.name)}</option>`).join('')}</select></div>
 <div><label>วัตถุดิบ / Lot</label><select id="v81es">${lots.map(s=>`<option value="${s.id}" ${s.id===u.stockId?'selected':''}>${esc(s.name)} | Lot ${esc(s.lot||'-')} | เหลือ ${n(s.qty)} ${esc(s.unit||'')}</option>`).join('')}</select></div>
 <div><label>จำนวนเบิก</label><input id="v81eq" type="number" min=".01" step=".01" value="${n(u.qty)}"></div>
 <div class="span2"><label>วัตถุประสงค์ / หมายเหตุ</label><input id="v81en" value="${esc(u.note||u.purpose||'')}"></div></div>`,()=>{
  const os=stockOf(u),ns=D.stock.find(x=>x.id===v81es.value),q=n(v81eq.value),returned=n(u.returnedQty),effectiveOld=Math.max(0,n(u.qty)-returned);
  if(!ns||q<=0||q<returned)return alert('จำนวนใหม่ต้องไม่น้อยกว่าจำนวนที่คืนไปแล้ว');
  const available=n(ns.qty)+(os&&os.id===ns.id?effectiveOld:0);const effectiveNew=q-returned;if(effectiveNew>available)return alert(`Stock ไม่พอสำหรับจำนวนใหม่`);
  if(os)os.qty=n(os.qty)+effectiveOld;ns.qty=n(ns.qty)-effectiveNew;
  Object.assign(u,{date:v81ed.value,useType:v81et.value,houseId:v81et.value==='House'?v81eh.value:'',stockId:ns.id,item:ns.name,lot:ns.lot||'',qty:q,unit:ns.unit||'',purpose:v81en.value,note:v81en.value});
  sv('stock');sv('usages');logAudit('EDIT','Usage',uid,`${u.item} ${q} ${u.unit||''}`);closeEditModal();usage();
 });
};
window.returnUsageV1081=function(uid){
 const u=D.usages.find(x=>x.id===uid);if(!u||!activeUsage(u))return;const remain=Math.max(0,n(u.qty)-n(u.returnedQty));if(!remain)return alert('รายการนี้คืนครบแล้ว');
 showEditModal('↩️ คืนวัตถุดิบเข้า Stock',`<div class="helpbox">${esc(u.item)} · Lot ${esc(u.lot||'-')}<br>ยังคืนได้ ${remain} ${esc(u.unit||'')}</div><div class="form"><div><label>จำนวนคืน</label><input id="v81rq" type="number" min=".01" max="${remain}" step=".01" value="${remain}"></div><div><label>หมายเหตุการคืน</label><input id="v81rn"></div></div>`,()=>{
  const q=n(v81rq.value);if(q<=0||q>remain)return alert('จำนวนคืนไม่ถูกต้อง');restore(u,q);u.returnedQty=n(u.returnedQty)+q;u.returns=u.returns||[];u.returns.push({id:id(),date:today(),qty:q,note:v81rn.value,by:me?.name||me?.username||''});sv('stock');sv('usages');logAudit('RETURN','Usage',uid,`${q} ${u.unit||''}`);closeEditModal();usage();
 });
};
window.cancelUsageV1081=function(uid){
 const u=D.usages.find(x=>x.id===uid);if(!u||!activeUsage(u))return;const q=Math.max(0,n(u.qty)-n(u.returnedQty));
 if(!confirm(`ยกเลิกรายการเบิก ${u.item} Lot ${u.lot||'-'}?\nระบบจะคืน Stock ที่ยังไม่เคยคืน ${q} ${u.unit||''} และเก็บประวัติรายการไว้`))return;
 if(q)restore(u,q);u.status='Cancelled';u.cancelledAt=new Date().toISOString();u.cancelledBy=me?.name||me?.username||'';sv('stock');sv('usages');logAudit('CANCEL','Usage',uid,`${u.item}; restored ${q}`);usage();
};
window.hardDeleteUsageV1081=function(uid){
 if(me?.role!=='Admin'||!setting().allowHardDeleteUsage)return alert('อนุญาตเฉพาะ Admin ใน Test Mode');
 const u=D.usages.find(x=>x.id===uid);if(!u)return;const q=activeUsage(u)?Math.max(0,n(u.qty)-n(u.returnedQty)):0;
 if(!confirm(`TEST MODE — ลบถาวร\n${u.item} Lot ${u.lot||'-'} ${n(u.qty)} ${u.unit||''}\n${q?`ระบบจะคืน Stock ${q} ${u.unit||''} ก่อนลบ\n`:''}ยืนยันลบข้อมูลนี้?`))return;
 if(q)restore(u,q);D.usages=D.usages.filter(x=>x.id!==uid);D.costs=(D.costs||[]).filter(x=>x.usageId!==uid&&x.usageRefId!==uid);sv('stock');sv('usages');sv('costs');logAudit('HARD DELETE','Usage',uid,`${u.item} [Test Mode]`);usage();
};
window.setUsageHardDeleteV1081=function(on){D.appSettings=D.appSettings||{};D.appSettings.allowHardDeleteUsage=!!on;saveSetting();alert(`Admin ลบถาวรข้อมูลเบิก: ${on?'เปิด':'ปิด'}`)};

/* Add the Test Mode switch to Settings without disturbing the existing settings form. */
const oldSettings=window.settings;
if(oldSettings)window.settings=function(){oldSettings();if(me?.role!=='Admin')return;const host=document.querySelector('#content');if(host&&!document.querySelector('.usage-testmode-v1081'))host.insertAdjacentHTML('beforeend',`<div class="card usage-testmode-v1081"><h3>🧪 Test Mode — Stock Movement</h3><p class="small">ช่วงทดสอบสามารถอนุญาต Admin ลบรายการเบิกถาวรได้ เมื่อใช้งานจริงแนะนำให้ปิด</p><label><input type="checkbox" ${setting().allowHardDeleteUsage?'checked':''} onchange="setUsageHardDeleteV1081(this.checked)"> อนุญาต Admin ลบรายการเบิกถาวร</label></div>`)};
})();
