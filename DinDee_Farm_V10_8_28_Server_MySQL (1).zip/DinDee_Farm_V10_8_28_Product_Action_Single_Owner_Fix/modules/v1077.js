/* DinDee Farm V10.7.7 — Canonical Income Categories + Dashboard Breakdown */
(function(){
'use strict';
const INCOME_CATEGORIES_V1077=[
 ['Farm Product Sales','ขายผลผลิตจากฟาร์ม'],
 ['Food & Beverage Income','รายได้อาหารและเครื่องดื่ม'],
 ['Learning Center Income','รายได้ศูนย์เรียนรู้'],
 ['Event Income','รายได้จากงานและกิจกรรม'],
 ['Support Income','เงินสนับสนุน'],
 ['Other Income','รายได้อื่น ๆ']
];
window.DinDee=window.DinDee||{};DinDee.master=DinDee.master||{};
DinDee.master.incomeCategories=INCOME_CATEGORIES_V1077.map(([value,th])=>({value,th}));

function shopIncomeClassV1077(p){
 const c=((D.shopCategories||[]).find(x=>x.id===p?.categoryId)?.name||p?.category||'').trim();
 if(/คอร์ส|workshop/i.test(c))return ['Learning Center Income','Workshop Income'];
 if(/กิจกรรม/i.test(c))return ['Learning Center Income','Activity Income'];
 if(/เครื่องดื่ม|กาแฟ|ชา|น้ำดื่ม/i.test(c))return ['Food & Beverage Income','Beverage Sales'];
 if(/อาหาร/i.test(c))return ['Food & Beverage Income','Food Sales'];
 if(/event|อีเวนต์/i.test(c))return ['Event Income','Event Income'];
 return ['Farm Product Sales',''];
}
window.shopIncomeClassV1077=shopIncomeClassV1077;
function orderIncomeClassV1077(o){
 const items=(o?.items||[]).map(x=>D.products.find(p=>p.id===(x.productId||x.id))).filter(Boolean);
 if(!items.length&&o?.productId){const p=D.products.find(x=>x.id===o.productId);if(p)items.push(p)}
 const classes=items.map(shopIncomeClassV1077),cats=[...new Set(classes.map(x=>x[0]))],tags=[...new Set(classes.map(x=>x[1]).filter(Boolean))];
 return {category:cats.length===1?cats[0]:'Other Income',tag:cats.length===1&&tags.length===1?tags[0]:'Other Income'};
}
window.orderIncomeClassV1077=orderIncomeClassV1077;
/* Repair historical Farm Shop income classification only; amount/date stay unchanged. */
(D.income||[]).forEach(x=>{
 if(x.source!=='Farm Shop'||!x.refId)return;
 const o=(D.orders||[]).find(z=>z.id===x.refId);if(!o)return;
 const m=orderIncomeClassV1077(o);x.category=m.category;x.tag=m.tag;
});
sv('income');

const oldDashboard=window.dashboard;
window.dashboard=function(){
 oldDashboard(); if(me?.role==='Staff')return;
 const S=window.dashS||today().slice(0,7)+'-01',E=window.dashE||today(),rows=(D.income||[]).filter(x=>(x.date||'')>=S&&(x.date||'')<=E);
 const box=INCOME_CATEGORIES_V1077.map(([key,th])=>{
   const sum=rows.filter(x=>x.category===key).reduce((a,x)=>a+(+x.amount||+x.total||0),0);
   return `<div class="income-cat-v1077"><div><b>${esc(key)}</b><small>${esc(th)}</small></div><strong>฿${money(sum)}</strong></div>`;
 }).join('');
 const total=rows.reduce((a,x)=>a+(+x.amount||+x.total||0),0);
 const card=`<div class="card income-breakdown-v1077"><div class="sectionTitle"><div><h3>💰 รายได้แยกตามหมวด</h3><div class="small">Income Master 6 หมวด · ${esc(S)} ถึง ${esc(E)}</div></div><span class="pill">รวม ฿${money(total)}</span></div><div class="income-grid-v1077">${box}</div><div class="helpbox">คอร์ส / Workshop → Learning Center Income / Workshop Income · กิจกรรม → Learning Center Income / Activity Income</div></div>`;
 const purchase=document.querySelector('.purchase-kpi-v1072');
 if(purchase)purchase.insertAdjacentHTML('beforebegin',card);
 else (document.querySelector('#content .grid4')||document.querySelector('#content .card'))?.insertAdjacentHTML('afterend',card);
};
})();
