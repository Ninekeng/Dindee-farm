/* DinDee Farm V10.8.7 — Farm Flow Final Fixes */
(function(){
'use strict';
const n=x=>+x||0, e=x=>typeof esc==='function'?esc(x):String(x??'');
const activeLots=()=> (D.stock||[]).filter(s=>n(s.qty)>0&&s.active!==false&&!s.archived);
const materialNames=()=>[...new Set(activeLots().map(s=>s.name).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'th'));
const materialOptions=(sel='')=>`<option value="">-- ไม่กำหนด --</option>`+materialNames().map(x=>`<option ${x===sel?'selected':''}>${e(x)}</option>`).join('');
const lotOptionsFor=(name,sel='')=>`<option value="">-- ไม่ใช้วัตถุดิบ --</option>`+activeLots().filter(s=>!name||s.name===name).sort((a,b)=>(a.expiryDate||'9999-12-31').localeCompare(b.expiryDate||'9999-12-31')).map(s=>`<option value="${s.id}" ${s.id===sel?'selected':''}>${e(s.name)} • Lot ${e(s.lot||'-')} • เหลือ ${n(s.qty)} ${e(s.unit||'')} • Exp ${e(s.expiryDate||'-')}</option>`).join('');
const taskUsages=id=>(D.usages||[]).filter(u=>u.taskId===id&&u.status!=='Cancelled');
const matText=t=>{const a=taskUsages(t.id);return a.length?a.map(u=>`${e(u.item||'-')} • Lot ${e(u.lot||'-')} • ${n(u.qty)-n(u.returnedQty)} ${e(u.unit||'')}`).join('<br>'):'-'};
const taskResult=t=>t.resultStatus||(t.status==='Problem'||t.status==='Issue'?'Problem':'Normal');
const resultText=t=>taskResult(t)==='Problem'?'🔴 พบปัญหา':'🟢 ปกติ';
const statusText=s=>s==='Done'?'🟢 Done':s==='Postponed'?'🟠 Postponed':'🟡 Pending';

/* Backward-compatible migration: old Problem/Issue represented both completion and result. */
let migrated=false;
(D.tasks||[]).forEach(t=>{if(['Problem','Issue'].includes(t.status)){t.status='Done';t.resultStatus='Problem';migrated=true}else if(t.actualDate&&!t.resultStatus){t.resultStatus='Normal';migrated=true}});
if(migrated)sv('tasks');

/* ---------- 1. Monthly Plan: full month desktop ---------- */
const oldPlan30=window.plan30;
window.plan30=function(){oldPlan30();document.getElementById('p30area')?.classList.add('fit-month-v1087')};

/* Monthly planner: plan material by item only, not Lot; no stock deduction. */
window.newMonthlyTaskV1061=function(hid,typeId,date){
 const tp=D.taskTypes.find(x=>x.id===typeId),cycle=(D.yearPlans||[]).find(p=>p.houseId===hid&&date>=p.start&&date<=p.end);
 showEditModal(`＋ วางแผนงาน • ${date}`,`<div class="form">
 <div><label>โรงเรือน</label><input value="${e((D.houses.find(h=>h.id===hid)||{}).name||'-')}" disabled></div><div><label>ประเภทงาน</label><input value="${e(tp?.name||'-')}" disabled></div>
 <div class="span2"><label>รายละเอียดงาน</label><input id="m87action" value="${e(tp?.name||'')}"></div>
 <div><label>ผู้รับผิดชอบ</label><select id="m87owner"><option value="">-- ยังไม่ระบุ --</option>${(D.responsibles||[]).filter(x=>x.active!==false).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('')}</select></div><div><label>Crop Cycle</label><input value="${e(cycle?.crop||'งานทั่วไป')}" disabled></div>
 <div><label>วัตถุดิบที่วางแผนใช้</label><select id="m87mat">${materialOptions()}</select><div class="small">ยังไม่เลือก Lot และยังไม่ตัด Stock</div></div>
 <div><label>ปริมาณประมาณการ</label><input id="m87qty" type="number" min="0" step=".01" value="0"></div>
 <div class="span2"><label>หมายเหตุ</label><textarea id="m87note" rows="2"></textarea></div></div>`,()=>{
   const action=m87action.value.trim();if(!action)return alert('กรุณากรอกรายละเอียดงาน');
   const mat=m87mat.value,lot=activeLots().find(s=>s.name===mat);
   const t={id:id(),cycleId:cycle?.id||'',date,houseId:hid,typeId,type:tp?.name||'',action,ownerId:m87owner.value,owner:'',knowledgeId:'',note:m87note.value.trim(),status:'Pending',resultStatus:'',actualDate:'',actualRemark:'',actualPhoto:'',plannedStockId:'',plannedMaterial:mat,plannedLot:'',plannedQty:n(m87qty.value),plannedUnit:lot?.unit||''};
   D.tasks.push(t);sv('tasks');logAudit('CREATE','Task',t.id,`${date} • ${t.type}`);closeEditModal();plan30();
 });
};

/* Today add-task: optional planned material, no Lot / no stock deduction. */
const oldToday=window.todayPage;
window.todayPage=function(){
 oldToday();
 if(me?.role==='Admin'&&document.getElementById('tcycle')&&!document.getElementById('v87planMat')){
   const form=document.getElementById('tcycle').closest('.form');
   form?.insertAdjacentHTML('beforeend',`<div><label>วัตถุดิบที่วางแผนใช้</label><select id="v87planMat">${materialOptions()}</select><div class="small">ยังไม่ตัด Stock</div></div><div><label>ปริมาณประมาณการ</label><input id="v87planQty" type="number" min="0" step=".01" value="0"></div>`);
 }
};
const oldAddTask=window.addTask;
window.addTask=function(){
 const before=(D.tasks||[]).length,mat=document.getElementById('v87planMat')?.value||'',qty=n(document.getElementById('v87planQty')?.value);
 oldAddTask();
 if(D.tasks.length>before){const t=D.tasks[D.tasks.length-1],lot=activeLots().find(s=>s.name===mat);Object.assign(t,{plannedMaterial:mat,plannedStockId:'',plannedLot:'',plannedQty:qty,plannedUnit:lot?.unit||''});sv('tasks')}
};

/* ---------- 2 & 3. Separate task status/result + actual Lot usage ---------- */
function reconcilePrimaryUsage(t,stockId,qty,date,note){
 const olds=taskUsages(t.id),old=olds[0];
 if(old){const os=D.stock.find(s=>s.id===old.stockId);if(os)os.qty=n(os.qty)+Math.max(0,n(old.qty)-n(old.returnedQty));D.usages=D.usages.filter(u=>u.id!==old.id)}
 if(stockId&&qty>0){const s=D.stock.find(x=>x.id===stockId);if(!s||qty>n(s.qty))throw new Error(`Stock Lot นี้ไม่พอ (เหลือ ${s?.qty||0} ${s?.unit||''})`);s.qty=n(s.qty)-qty;D.usages.push({id:id(),taskId:t.id,cycleId:t.cycleId||'',date,houseId:t.houseId,stockId:s.id,item:s.name,lot:s.lot||'',qty,unit:s.unit,note:note||`ใช้กับงาน ${t.action}`,status:'Used',returnedQty:0})}
 sv('stock');sv('usages');
}
window.refreshActualLotsV1087=function(){const name=document.getElementById('v87actualMat')?.value||'';const el=document.getElementById('v87actualLot');if(el)el.innerHTML=lotOptionsFor(name)};

window.doneTask=function(taskId){
 const t=D.tasks.find(x=>x.id===taskId);if(!t)return alert('ไม่พบงานนี้');
 const u=taskUsages(t.id)[0],planned=t.plannedMaterial||u?.item||'',res=taskResult(t);
 showEditModal('บันทึกผลการทำงาน',`<div class="form">
 <div><label>สถานะงาน</label><select id="v87status"><option value="Done" ${t.status!=='Postponed'?'selected':''}>✓ Done — ทำงานเสร็จ</option><option value="Postponed" ${t.status==='Postponed'?'selected':''}>↪ Postponed — เลื่อนงาน</option></select></div>
 <div><label>ผลการทำงาน</label><select id="v87result" onchange="toggleProblemV1087()"><option value="Normal" ${res!=='Problem'?'selected':''}>ปกติ</option><option value="Problem" ${res==='Problem'?'selected':''}>พบปัญหา</option></select></div>
 <div><label>วันที่ทำจริง</label><input id="v87date" type="date" value="${e(t.actualDate||today())}"></div>
 <div><label>ผู้ปฏิบัติงาน</label><select id="v87owner"><option value="">-- ไม่ระบุ --</option>${(D.responsibles||[]).filter(x=>x.active!==false).map(x=>`<option value="${x.id}" ${x.id===t.ownerId?'selected':''}>${e(x.name)}</option>`).join('')}</select></div>
 <div><label>เลื่อนไปวันที่</label><input id="v87next" type="date" value="${e(t.date||today())}"></div>
 <div class="span2"><label>รายละเอียด / ผลการทำงาน</label><textarea id="v87remark" rows="2">${e(t.actualRemark||'')}</textarea></div>
 <div id="v87problemBox" class="span2"><div class="form"><div><label>รายละเอียดปัญหา</label><textarea id="v87problem" rows="2">${e(t.problemDetail||'')}</textarea></div><div><label>การแก้ไข / ติดตาม</label><textarea id="v87correct" rows="2">${e(t.correctiveAction||'')}</textarea></div></div></div>
 <div><label>วัตถุดิบที่ใช้จริง</label><select id="v87actualMat" onchange="refreshActualLotsV1087()">${materialOptions(planned)}</select></div>
 <div><label>Lot ที่ใช้จริง (FEFO)</label><select id="v87actualLot">${lotOptionsFor(planned,u?.stockId||'')}</select></div>
 <div><label>จำนวนใช้จริง</label><input id="v87qty" type="number" min="0" step=".01" value="${u?n(u.qty)-n(u.returnedQty):(t.plannedQty||'')}"></div>
 <div><label>รูปหลักฐาน</label><input id="v87photo" type="file" accept="image/*"></div>
 </div>`,()=>{
   const status=v87status.value,result=v87result.value;
   const commit=photo=>{try{
     if(status==='Postponed'){if(!v87next.value)return alert('กรุณาเลือกวันที่ใหม่');t.status='Postponed';t.postponedAt=v87date.value;t.date=v87next.value;t.resultStatus='';}
     else{t.status='Done';t.resultStatus=result;t.actualDate=v87date.value||today();t.ownerId=v87owner.value;t.actualRemark=v87remark.value.trim();t.problemDetail=result==='Problem'?v87problem.value.trim():'';t.correctiveAction=result==='Problem'?v87correct.value.trim():'';if(photo)t.actualPhoto=photo;reconcilePrimaryUsage(t,v87actualLot.value,n(v87qty.value),t.actualDate,t.actualRemark)}
     sv('tasks');logAudit('UPDATE','Task',t.id,`${t.action} → ${t.status}/${t.resultStatus||'-'}`);closeEditModal();todayPage();
   }catch(err){alert(err.message)}};
   const f=v87photo.files?.[0];if(f)fileData(f,commit);else commit('');
 });
 setTimeout(()=>toggleProblemV1087(),0);
};
window.completeTask=window.doneTask;
window.toggleProblemV1087=function(){const b=document.getElementById('v87problemBox'),r=document.getElementById('v87result');if(b)b.style.display=r?.value==='Problem'?'block':'none'};

/* Work History: explicit status + result + material/Lot/qty. */
window.workHistoryV1056=function(){
 const data=(D.tasks||[]).filter(t=>t.status==='Done'||t.status==='Postponed'||t.actualDate).sort((a,b)=>String(b.actualDate||b.date||'').localeCompare(String(a.actualDate||a.date||'')));
 window._whData1056=data;
 content.innerHTML=`<div class="card"><h2>📋 ประวัติการทำงาน</h2><div class="form">
 <div><label>ตั้งแต่</label><input id="whFrom" type="date"></div><div><label>ถึง</label><input id="whTo" type="date"></div>
 <div><label>โรงเรือน / พื้นที่</label><select id="whHouse"><option value="">ทั้งหมด</option>${(D.houses||[]).map(h=>`<option value="${h.id}">${e(h.name)}</option>`).join('')}</select></div>
 <div><label>สถานะงาน</label><select id="whStatus"><option value="">ทั้งหมด</option><option value="Done">Done</option><option value="Postponed">Postponed</option></select></div>
 <div><label>ผลการทำงาน</label><select id="whResult"><option value="">ทั้งหมด</option><option value="Normal">ปกติ</option><option value="Problem">พบปัญหา</option></select></div>
 <div><label>ค้นหา</label><input id="whQ" placeholder="งาน / วัตถุดิบ / ปัญหา"></div></div><br>
 <button class="btn" onclick="filterWorkHistoryV1056()">🔎 แสดงข้อมูล</button> <button class="btn2" onclick="printCurrent()">🖨️ พิมพ์</button></div><div class="card" id="whArea"></div>`;
 filterWorkHistoryV1056();
};
window.filterWorkHistoryV1056=function(){
 let a=window._whData1056||[],f=whFrom?.value||'',to=whTo?.value||'',h=whHouse?.value||'',st=whStatus?.value||'',rs=whResult?.value||'',q=(whQ?.value||'').toLowerCase();
 a=a.filter(t=>{const d=t.actualDate||t.date||'',hay=[t.action,t.actualRemark,t.problemDetail,t.correctiveAction,matText(t)].join(' ').toLowerCase();return(!f||d>=f)&&(!to||d<=to)&&(!h||t.houseId===h)&&(!st||t.status===st)&&(!rs||taskResult(t)===rs)&&(!q||hay.includes(q))});
 whArea.innerHTML=`<h3>รายการประวัติ (${a.length})</h3><div class="tableWrap"><table><tr><th>วันที่ทำจริง</th><th>โรงเรือน</th><th>งาน</th><th>วัตถุดิบ / Lot / จำนวน</th><th>สถานะงาน</th><th>ผลการทำงาน</th><th>ปัญหา / การแก้ไข</th><th>หมายเหตุ</th><th>จัดการ</th></tr>
 ${a.map(t=>`<tr><td>${e(t.actualDate||t.date||'-')}</td><td>${e((D.houses.find(x=>x.id===t.houseId)||{}).name||'-')}</td><td><b>${e(t.action||'-')}</b><br><span class="small">${e(t.type||'')}</span></td><td>${matText(t)}</td><td>${statusText(t.status)}</td><td>${resultText(t)}</td><td>${taskResult(t)==='Problem'?`<b>${e(t.problemDetail||'-')}</b><br><span class="small">แก้ไข: ${e(t.correctiveAction||'-')}</span>`:'-'}</td><td>${e(t.actualRemark||t.note||'-')}</td><td class="compact-work-actions-v1083"><button class="btn2 purchase-icon-btn" title="แก้ไข" onclick="editWorkHistoryV1087('${t.id}')">✏️</button>${me?.role==='Admin'?`<button class="btn2 dangerBtn purchase-icon-btn" title="ลบงาน" onclick="deleteTask('${t.id}')">🗑️</button>`:''}</td></tr>`).join('')||'<tr><td colspan="9">ยังไม่มีประวัติ</td></tr>'}</table></div>`;
};
window.editWorkHistoryV1087=function(tid){closeEditModal();doneTask(tid)};

/* ---------- 4. Stock active lots + retained history ---------- */
window.stockHistoryV1087=function(){
 const rows=(D.stock||[]).slice().sort((a,b)=>String(b.expiryDate||'').localeCompare(String(a.expiryDate||'')));
 showEditModal('🗂️ Stock / Lot History',`<div class="tableWrap"><table><tr><th>รายการ</th><th>Lot</th><th>คงเหลือ</th><th>หมดอายุ</th><th>สถานะ</th></tr>${rows.map(s=>`<tr><td>${e(s.name)}</td><td>${e(s.lot||'-')}</td><td>${n(s.qty)} ${e(s.unit||'')}</td><td>${e(s.expiryDate||'-')}</td><td>${n(s.qty)>0?'Active':'ใช้หมดแล้ว'}</td></tr>`).join('')}</table></div>`,()=>closeEditModal());
};
window.stock=function(){
 const rows=activeLots(),groups={};rows.forEach(s=>(groups[s.category||'ยังไม่จัดหมวดหมู่']??=[]).push(s));
 const state=s=>{const q=n(s.qty),min=n(s.minStock),exp=s.expiryDate||'',days=exp?Math.ceil((new Date(exp+'T00:00:00')-new Date(today()+'T00:00:00'))/86400000):99999;if(exp&&days<0)return ['🔴','หมดอายุ','stockBad'];if(exp&&days<=30)return ['🟠','ใกล้หมดอายุ','stockWarn'];if(min>0&&q<=min)return ['🟡','Stock ต่ำ','stockLow'];return ['🟢','ปกติ','stockOk']};
 content.innerHTML=`<div class="pageHero"><div><span class="eyebrow">INVENTORY & LOT TRACEABILITY</span><h2>คลังสินค้า (Stock)</h2><p>แสดงเฉพาะ Lot ที่มีคงเหลือ • Lot ที่ใช้หมดแล้วยังเก็บในประวัติ</p></div><div class="heroActions"><button class="btn2" onclick="stockHistoryV1087()">🗂️ Stock / Lot History</button></div></div>
 ${Object.entries(groups).map(([cat,rs])=>`<div class="card"><h3>${e(typeof catLabel==='function'?catLabel(cat):cat)} <span class="pill">${rs.length}</span></h3><div class="tableWrap"><table><tr><th>สถานะ</th><th>รายการ</th><th>Lot</th><th>คงเหลือ</th><th>หมดอายุ</th><th>Minimum</th><th>Supplier</th><th></th></tr>${rs.map(s=>{const st=state(s);return `<tr class="${st[2]}"><td>${st[0]} ${st[1]}</td><td><b>${e(s.name)}</b></td><td>${e(s.lot||'-')}</td><td>${n(s.qty)} ${e(s.unit||'')}</td><td>${e(s.expiryDate||'-')}</td><td>${n(s.minStock)} ${e(s.unit||'')}</td><td>${e(s.supplier||'-')}</td><td>${me?.role==='Admin'?`<button class="btn2 purchase-icon-btn" onclick="editStockV1043('${s.id}')">✏️</button>`:'-'}</td></tr>`}).join('')}</table></div></div>`).join('')||'<div class="card">ยังไม่มี Stock ที่มีคงเหลือ <button class="btn2" onclick="stockHistoryV1087()">ดูประวัติ Lot</button></div>'}`;
};
})();
