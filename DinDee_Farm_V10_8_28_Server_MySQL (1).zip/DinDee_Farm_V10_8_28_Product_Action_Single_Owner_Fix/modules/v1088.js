/* DinDee Farm V10.8.8 — Today Work History Material Summary */
(function(){
'use strict';
const n=x=>+x||0,e=x=>typeof esc==='function'?esc(x):String(x??'');
function usageRows(tid){return (D.usages||[]).filter(u=>u.taskId===tid&&u.status!=='Cancelled')}
function materialText(tid){
 const a=usageRows(tid);
 return a.length?a.map(u=>`${e(u.item||'-')}<br><span class="small">Lot ${e(u.lot||'-')} • ${Math.max(0,n(u.qty)-n(u.returnedQty))} ${e(u.unit||'')}</span>`).join('<br>'):'-';
}
function resultText(t){const r=t.resultStatus||(t.status==='Problem'||t.status==='Issue'?'Problem':'Normal');return r==='Problem'?'🔴 พบปัญหา':'🟢 ปกติ'}
function statusText(t){return t.status==='Done'?'🟢 Done':t.status==='Postponed'?'🟠 Postponed':t.status==='Pending'?'🟡 Pending':e(t.status||'-')}
function compactHistory(){
 const rows=(D.tasks||[]).filter(t=>t.status==='Done'||t.status==='Postponed'||t.actualDate)
 .sort((a,b)=>String(b.actualDate||b.date||'').localeCompare(String(a.actualDate||a.date||''))).slice(0,8);
 const hn=id=>(D.houses.find(h=>h.id===id)||{}).name||'-';
 return `<div class="card v1088-history"><div class="sectionTitle"><div><h3>📋 ประวัติการทำงาน</h3><span class="muted">8 รายการล่าสุด • แสดงวัตถุดิบที่ใช้จริงโดยไม่ต้องเปิดประวัติทั้งหมด</span></div><button class="btn2" onclick="workHistoryV1056()">ดูประวัติทั้งหมด →</button></div>
 <div class="tableWrap"><table><tr><th>วันที่ทำจริง</th><th>โรงเรือน</th><th>งาน</th><th>วัตถุดิบ / Lot / จำนวน</th><th>ผู้ปฏิบัติงาน</th><th>สถานะงาน</th><th>ผลการทำงาน</th></tr>
 ${rows.map(t=>`<tr><td>${e(t.actualDate||t.date||'-')}</td><td>${e(hn(t.houseId))}</td><td><b>${e(t.action||'-')}</b></td><td class="today-material-v1088">${materialText(t.id)}</td><td>${e(t.owner||((D.responsibles||[]).find(x=>x.id===t.ownerId)||{}).name||'-')}</td><td>${statusText(t)}</td><td>${resultText(t)}</td></tr>`).join('')||'<tr><td colspan="7">ยังไม่มีประวัติการทำงาน</td></tr>'}</table></div></div>`;
}
const oldToday=window.todayPage;
window.todayPage=function(){
 const r=oldToday.apply(this,arguments);
 [...content.querySelectorAll('.v1058-history,.v1088-history')].forEach(x=>x.remove());
 content.insertAdjacentHTML('beforeend',compactHistory());
 return r;
};
})();
