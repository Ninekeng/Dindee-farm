/* DinDee Farm V10.7.9 — clearer Shop Category / Income Mapping entry point */
(function(){
'use strict';
const oldShopAdmin=window.shopadmin;
window.shopadmin=function(){
  oldShopAdmin();
  const buttons=[...document.querySelectorAll('#content button')];
  const b=buttons.find(x=>/หมวดหมู่สินค้า|จัดการหมวดหมู่/.test(x.textContent||''));
  if(b){
    b.innerHTML='⚙️ หมวดสินค้า &amp; Income Mapping';
    b.title='กำหนดหมวดสินค้าให้เชื่อมกับ Income Category และ Income Tag';
  }
};
})();
