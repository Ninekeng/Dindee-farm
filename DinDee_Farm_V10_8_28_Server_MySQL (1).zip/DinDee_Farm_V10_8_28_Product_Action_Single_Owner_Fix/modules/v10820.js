'use strict';
/* DinDee Farm V10.8.20 — Restore Dashboard income/expense share + Farm Analytics after V10.8.17 dashboard override. */
(function(){
  const previousDashboard=window.dashboard;
  if(typeof previousDashboard!=='function') return;
  const n=v=>Number(v)||0;
  const realExpenses=()=> (D.expenses||[]).filter(e=>e.source!=='Purchase');
  const cashExpenses=()=>[...realExpenses(),...(D.purchases||[]).map(x=>({...x,amount:n(x.total),name:x.item||x.name,source:'Purchase'}))];
  const thExpense={'Crop Production':'การปลูกพืช','Livestock & Animals':'การเลี้ยงสัตว์','Food & Beverage':'อาหารและเครื่องดื่ม','Learning Center & Activities':'ศูนย์เรียนรู้และกิจกรรม','Farm Infrastructure':'ระบบและสิ่งปลูกสร้าง','Farm Development':'พัฒนาและบริหารฟาร์ม'};
  const thIncome={'Farm Product Sales':'ขายผลผลิตจากฟาร์ม','Food & Beverage Income':'รายได้อาหารและเครื่องดื่ม','Learning Center Income':'รายได้ศูนย์เรียนรู้','Event Income':'รายได้จากงานและกิจกรรม','Support Income':'เงินสนับสนุน','Other Income':'รายได้อื่น ๆ'};
  const labelCat=k=>`${k||'Other'}${(thExpense[k]||thIncome[k])?' — '+(thExpense[k]||thIncome[k]):''}`;
  const sumBy=rows=>{const m={};rows.forEach(x=>{const k=x.category||'Other';m[k]=(m[k]||0)+n(x.amount??x.total)});return Object.entries(m).sort((a,b)=>b[1]-a[1]);};
  function pie(rows,kind,empty){
    const data=sumBy(rows),total=data.reduce((a,x)=>a+x[1],0); if(!total)return `<div class="emptyState">${empty}</div>`;
    const colors=['#176b45','#42a66d','#d6a43b','#2f7da8','#845ea8','#c86555','#6f8d44','#8b6a48']; let at=0;
    const parts=data.map((x,i)=>{const a=at,b=at+x[1]/total*360;at=b;return `${colors[i%colors.length]} ${a}deg ${b}deg`});
    return `<div class="pieWrap"><div class="pieChart" style="background:conic-gradient(${parts.join(',')})"><div class="pieHole"><b>฿${money(total)}</b><small>รวม</small></div></div><div class="pieLegend">${data.map((x,i)=>`<button type="button" onclick="showFinanceDrillV10820('${kind}','${encodeURIComponent(x[0])}')"><i style="background:${colors[i%colors.length]}"></i><span>${esc(labelCat(x[0]))}</span><b>฿${money(x[1])}</b><em>${(x[1]/total*100).toFixed(1)}%</em></button>`).join('')}</div></div>`;
  }
  window.showFinanceDrillV10820=function(kind,enc){
    const k=decodeURIComponent(enc),S=window.dashS||today().slice(0,7)+'-01',E=window.dashE||today();
    const base=kind==='Income'?(D.income||[]):cashExpenses();
    const rows=base.filter(x=>(x.date||'')>=S&&(x.date||'')<=E&&(x.category||'Other')===k);
    showEditModal(labelCat(k),`<div class="tableWrap"><table><tr><th>วันที่</th><th>รายการ</th><th>ประเภท</th><th>จำนวน</th></tr>${rows.map(x=>`<tr><td>${esc(x.date||'-')}</td><td>${esc(x.name||x.item||x.product||'-')}</td><td>${kind==='Income'?'รายรับ':'รายจ่าย'}</td><td>฿${money(x.amount??x.total)}</td></tr>`).join('')||'<tr><td colspan="4">ไม่มีรายการ</td></tr>'}</table></div>`,()=>closeEditModal());
  };
  function restoreAnalytics(){
    if(document.querySelector('#content .analytics-v10820')) return;
    const S=window.dashS||today().slice(0,7)+'-01',E=window.dashE||today(),inside=x=>(x.date||'')>=S&&(x.date||'')<=E;
    const inc=(D.income||[]).filter(inside),exp=cashExpenses().filter(inside),incTop=sumBy(inc)[0],expTop=sumBy(exp)[0];
    const done=(D.tasks||[]).filter(t=>t.status==='Done'&&(t.actualDate||t.date||'')>=S&&(t.actualDate||t.date||'')<=E).length;
    const over=(D.tasks||[]).filter(t=>t.status!=='Done'&&(t.date||'')<E&&(t.date||'')<=today()).length;
    const low=(D.stock||[]).filter(s=>n(s.qty)>0&&n(s.qty)<=n(s.minStock)).length;
    const near=(D.stock||[]).filter(s=>s.expiryDate&&s.expiryDate>=today()&&((new Date(s.expiryDate)-new Date(today()))/86400000)<=30&&n(s.qty)>0).length;
    const insight=[];
    if(incTop) insight.push(`รายรับสูงสุดมาจาก <b>${esc(labelCat(incTop[0]))}</b> ${money(incTop[1])} บาท`);
    if(expTop) insight.push(`รายจ่ายสูงสุดคือ <b>${esc(labelCat(expTop[0]))}</b> ${money(expTop[1])} บาท`);
    if(over) insight.push(`มีงานค้าง/เลยกำหนด <b>${over} งาน</b>`);
    if(low) insight.push(`Stock ต่ำกว่า Minimum <b>${low} รายการ</b>`);
    if(near) insight.push(`วัตถุดิบใกล้หมดอายุภายใน 30 วัน <b>${near} Lot</b>`);
    const section=document.createElement('section'); section.className='analytics-v10820';
    section.innerHTML=`<div class="grid2"><div class="card"><h3>🍃 สัดส่วนรายรับ</h3><p class="muted">รายรับจากการดำเนินงานตามหมวดหมู่ • ไม่รวม Sponsor เป็นยอดขาย</p>${pie(inc,'Income','ยังไม่มีข้อมูลรายรับในช่วงนี้')}</div><div class="card"><h3>🧾 สัดส่วนรายจ่าย</h3><p class="muted">รายจ่ายเงินสดตามหมวดหมู่ • ไม่รวม Direct Cost ซ้ำ</p>${pie(exp,'Expense','ยังไม่มีข้อมูลรายจ่ายในช่วงนี้')}</div></div><div class="card"><div class="sectionTitle"><div><h3>🧠 Farm Analytics</h3><span class="muted">สรุปข้อมูลที่ควรใช้วิเคราะห์และตัดสินใจ</span></div><button class="btn" onclick="openFarmAnalyticsV1089()">ดูรายละเอียดและวิเคราะห์ฟาร์ม →</button></div><div class="insightGrid">${insight.map(x=>`<div class="insightItem">${x}</div>`).join('')||'<div class="emptyState">ข้อมูลยังไม่เพียงพอสำหรับวิเคราะห์</div>'}</div><div class="analyticsKpi"><span>งานเสร็จในช่วงนี้ <b>${done}</b></span><span>งานค้าง <b>${over}</b></span><span>Stock ต่ำ <b>${low}</b></span><span>ใกล้หมดอายุ <b>${near}</b></span></div></div>`;
    const profitCard=[...content.querySelectorAll('.card')].find(x=>(x.textContent||'').includes('กำไรตามสินค้า / ผลผลิต'));
    const target=profitCard?.parentElement;
    if(target) target.before(section); else content.appendChild(section);
  }
  window.dashboard=function(){const r=previousDashboard.apply(this,arguments); if(!(me&&me.role==='Staff')) restoreAnalytics(); return r;};
})();
