/* DinDee Farm V10.8.24 — reliable checkout submit + compact product actions */
(function(){
'use strict';
const A=x=>Array.isArray(x)?x:[], n=x=>Number(x)||0, digits=x=>String(x||'').replace(/\D/g,'');
function customerByPhone(p){const q=digits(p);return A(D.customers).find(c=>digits(c.phone)===q)}
function currentItems(){return A(window.cart).map(x=>({...x,p:A(D.products).find(p=>p.id===x.productId)})).filter(x=>x.p&&n(x.qty)>0)}
function sourceSnapshot(p,q){let unitCost=0;if(typeof window.productUnitCostV10824==='function')unitCost=n(window.productUnitCostV10824(p));
 else if(p.sourceType==='farm'&&p.sourceCycleId){let h=A(D.harvests).filter(x=>x.cycleId===p.sourceCycleId).reduce((s,x)=>s+Math.max(0,n(x.qty)-n(x.waste)),0),c=A(D.costs).filter(x=>x.cycleId===p.sourceCycleId).reduce((s,x)=>s+n(x.amount),0);unitCost=h?c/h:0}else unitCost=n(p.manualUnitCost);
 return {sourceType:p.sourceType||'other',sourceCycleId:p.sourceCycleId||'',sourceHouseId:p.sourceHouseId||'',sourceStockId:p.sourceStockId||'',unitCost,costTotal:n(q)*unitCost};}
window.submitCheckoutV10824=function(qrType){
 const name=document.getElementById('coName')?.value.trim()||'',phone=digits(document.getElementById('coPhone')?.value),pay=document.getElementById('coPay')?.value||'qr',delivery=document.getElementById('coDelivery')?.value||'',address=document.getElementById('coAddress')?.value.trim()||'',note=document.getElementById('coNote')?.value.trim()||'';
 if(!name||phone.length<9)return alert('กรุณากรอกชื่อและเบอร์โทรให้ถูกต้อง');
 const items=currentItems();if(!items.length)return alert('ไม่พบสินค้าในตะกร้า กรุณากลับไปเลือกสินค้าใหม่');
 for(const x of items)if(n(x.qty)>n(x.p.qty))return alert(`สินค้า ${x.p.name} คงเหลือไม่เพียงพอ`);
 let c=customerByPhone(phone),pin=document.getElementById('coPin89')?.value||'',pin2=document.getElementById('coPinConfirm89')?.value||'';
 if(c&&c.pinHash){if(!/^\d{4}$/.test(pin)||c.pinHash!==hash(pin))return alert('PIN เดิมไม่ถูกต้อง กรุณาลองอีกครั้ง')}
 else {if(!/^\d{4}$/.test(pin))return alert('PIN ต้องเป็นตัวเลข 4 หลัก');if(pin!==pin2)return alert('PIN ยืนยันไม่ตรงกัน')}
 const slip=document.getElementById('coSlip')?.files?.[0];if(pay==='qr'&&!slip)return alert('กรุณาแนบหลักฐานการชำระเงินก่อนส่งคำสั่งซื้อ');
 if(!c){c={id:id(),phone,name,created:today(),active:true};D.customers.push(c)}c.name=name||c.name;c.address=address||c.address;c.note=note||c.note;c.active=c.active!==false;if(!c.pinHash){c.pinHash=hash(pin);c.pinCreatedAt=new Date().toISOString()}sv('customers');
 const total=items.reduce((s,x)=>s+n(x.qty)*n(x.p.price),0),created=new Date().toLocaleString('th-TH');
 const o={id:id(),no:nextOrderNo(),customerId:c.id,customer:name,phone,items:items.map(x=>({productId:x.p.id,name:x.p.name,qty:n(x.qty),unit:x.p.unit,price:n(x.p.price),...sourceSnapshot(x.p,x.qty)})),qty:items.reduce((s,x)=>s+n(x.qty),0),total,paymentMethod:pay,paymentQr:qrType,delivery,address,note,status:pay==='qr'?'Payment Submitted':'New',cashStatus:pay==='cash'?'Pending Cash':'',created,slip:'',history:[]};
 o.cogs=o.items.reduce((s,x)=>s+n(x.costTotal),0);
 const finish=()=>{o.history.push({status:o.status,time:created,note:pay==='qr'?'ส่งคำสั่งซื้อพร้อมหลักฐานชำระเงิน':'สั่งซื้อและเลือกชำระเงินสด'});D.orders.push(o);items.forEach(x=>x.p.qty=Math.max(0,n(x.p.qty)-n(x.qty)));sv('orders');sv('products');if(Array.isArray(window.cart))window.cart.length=0;logAudit('CREATE','Farm Shop Order',o.id,o.no);closeEditModal();alert(`ส่งคำสั่งซื้อ ${o.no} เรียบร้อย\nยอดรวม ฿${money(total)}`);shop()};
 if(pay==='qr')fileData(slip,d=>{o.slip=d;finish()});else finish();
};
/* Make the final checkout entry call one non-wrapped submit path. */
const checkout24=window.openCheckoutV10814;window.openCheckoutV10814=function(){const r=checkout24.apply(this,arguments),save=document.getElementById('emSave');if(save){save.textContent='ยืนยันคำสั่งซื้อ';save.onclick=()=>{const act=currentItems().some(x=>/กิจกรรม|workshop|course|คอร์ส/i.test(((D.shopCategories||[]).find(c=>c.id===x.p.categoryId)?.name||x.p.category||'')));submitCheckoutV10824(act?'activity':'farm')}}return r};
/* Compact icon-only actions in Product Catalog. */
const admin24=window.shopadmin;window.shopadmin=function(){const r=admin24.apply(this,arguments);document.querySelectorAll('#content table button').forEach(b=>{const oc=b.getAttribute('onclick')||'',t=(b.textContent||'').trim();if(/editProduct\(/.test(oc)||t.includes('แก้ไข')){b.textContent='✏️';b.title='แก้ไข';b.setAttribute('aria-label','แก้ไข');b.classList.add('icon-action-v10824')}else if(/deleteProduct\(/.test(oc)||t.includes('ลบ')){b.textContent='🗑️';b.title='ลบ';b.setAttribute('aria-label','ลบ');b.classList.add('icon-action-v10824')}});return r};
})();
