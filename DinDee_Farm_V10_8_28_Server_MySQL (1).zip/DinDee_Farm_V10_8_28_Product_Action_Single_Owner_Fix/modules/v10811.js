/* DinDee Farm V10.8.11 — Farm Shop cart state + checkout transition reliability */
(function(){
'use strict';

function cartItemsV10811(){
  if(!Array.isArray(window.cart)) window.cart=[];
  for(let i=cart.length-1;i>=0;i--){
    const x=cart[i],p=D.products.find(z=>z.id===x.productId),q=Number(x.qty)||0;
    if(!p||q<=0){cart.splice(i,1);continue;}
    x.qty=Math.min(Math.max(1,q),Math.max(0,Number(p.qty)||0));
    if(x.qty<=0)cart.splice(i,1);
  }
  return cart.map(x=>({...x,p:D.products.find(p=>p.id===x.productId)})).filter(x=>x.p&&x.qty>0);
}
function cartCountV10811(){return cartItemsV10811().reduce((a,x)=>a+(Number(x.qty)||0),0)}
function refreshCartBadgeV10811(){
  document.querySelectorAll('.cartButton b').forEach(b=>b.textContent=String(cartCountV10811()));
}
window.refreshCartBadgeV10811=refreshCartBadgeV10811;

/* Generic edit dialogs should not inherit the cart's action label. */
const showBase10811=window.showEditModal;
window.showEditModal=function(title,html,onSave){
  const r=showBase10811.apply(this,arguments);
  const b=document.getElementById('emSave');if(b)b.textContent='💾 บันทึก';
  return r;
};

/* Cart is the source of truth. Qty 0 removes the line, total and badge refresh immediately. */
window.changeCartV1043=function(pid,d){
  const x=cart.find(z=>z.productId===pid),p=D.products.find(z=>z.id===pid);if(!x||!p)return;
  const next=Math.min(Number(p.qty)||0,(Number(x.qty)||0)+(Number(d)||0));
  if(next<=0)cart.splice(cart.indexOf(x),1);else x.qty=next;
  refreshCartBadgeV10811();openCartV1043();
};
window.openCartV1043=function(){
  const items=cartItemsV10811(),total=items.reduce((a,x)=>a+x.qty*num(x.p.price),0);
  showEditModal('ตะกร้าสินค้า',`<div class="cartList">${items.map(x=>`<div class="cartLine"><div><b>${esc(x.p.name)}</b><small>฿${money(x.p.price)} / ${esc(x.p.unit)} · เหลือ ${x.p.qty}</small></div><div class="qtyStepper"><button onclick="changeCartV1043('${x.p.id}',-1)">−</button><b>${x.qty}</b><button onclick="changeCartV1043('${x.p.id}',1)">+</button></div><b>฿${money(x.qty*x.p.price)}</b></div>`).join('')||'<p>ยังไม่มีสินค้าในตะกร้า</p>'}</div><div class="checkoutTotal"><span>ยอดรวม</span><b>฿${money(total)}</b></div>`,()=>{
    cartItemsV10811();refreshCartBadgeV10811();
    if(!cart.length)return alert('ยังไม่มีสินค้าในตะกร้า');
    closeEditModal();openCheckoutV1043();
  });
  const save=document.getElementById('emSave');
  if(save){save.textContent=items.length?'ดำเนินการสั่งซื้อ →':'ไม่มีสินค้า';save.disabled=!items.length;}
  refreshCartBadgeV10811();
};

/* Ensure PIN set during QR checkout is persisted after the asynchronous slip read/order save. */
const submitBase10811=window.submitCheckoutV104;
window.submitCheckoutV104=function(qrType){
  const phone=String(document.getElementById('coPhone')?.value||'').replace(/\D/g,''),pin=document.getElementById('coPin89')?.value||'',name=document.getElementById('coName')?.value?.trim()||'',pay=document.getElementById('coPay')?.value||'';
  const before=(D.customers||[]).find(c=>String(c.phone||'').replace(/\D/g,'')===phone),needsPinSave=phone.length>=9&&/^\d{4}$/.test(pin)&&(!before||!before.pinHash);
  const basicOK=!!name&&phone.length>=9&&(pay!=='qr'||!!document.getElementById('coSlip')?.files?.[0]);
  const r=submitBase10811.apply(this,arguments);
  if(needsPinSave&&basicOK){
    let tries=0;const saveWhenReady=()=>{const c=(D.customers||[]).find(x=>String(x.phone||'').replace(/\D/g,'')===phone);if(c&&!c.pinHash){c.pinHash=hash(pin);c.pinCreatedAt=new Date().toISOString();sv('customers');return}if(++tries<20)setTimeout(saveWhenReady,100)};saveWhenReady();
  }
  return r;
};
})();
