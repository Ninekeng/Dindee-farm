# Module migration map

- `dashboard` — Dashboard
- `alerts` — Alerts
- `today` — Today Tasks
- `plan30` — Monthly Plan
- `usage` — Stock Usage
- `stock` — Stock
- `year` — Annual Plan
- `cycles` — Crop Cycle
- `harvest` — Harvest
- `houses` — Houses
- `houseReport` — House Report
- `knowledge` — Knowledge
- `shopadmin` — Farm Shop Admin
- `orders` — Orders
- `shop` — Customer Shop
- `track` — Order Tracking
- `live` — Live Camera
- `purchase` — Purchase
- `directcost` — Direct Cost
- `finance` — Finance
- `sponsor` — Sponsor
- `settings` — Settings
- `auditPage` — Audit
- `evidence` — Evidence
- `users` — Users
- `exportPage` — Backup/Export

V10.0 intentionally keeps the proven V9.4.2 feature implementation in `js/app.js` while establishing a stable multi-file baseline. New changes should be extracted one module at a time, with regression tests after each extraction. This avoids a risky big-bang rewrite.
