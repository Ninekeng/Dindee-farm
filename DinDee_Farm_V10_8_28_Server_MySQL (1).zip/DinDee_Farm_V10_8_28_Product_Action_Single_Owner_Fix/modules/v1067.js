/* DinDee Farm V10.6.7 - Harvest edit/delete */
(function(){
'use strict';
window.harvest=function(){
 const canManage=me&&me.role==='Admin';
 const plans=(D.yearPlans||[]);
 content.innerHTML=`<div class="card"><h3>🥬 บันทึกเก็บเกี่ยว</h3><div class="form">
 <div><label>รอบการผลิต</label><select id="hv">${plans.map(p=>`<option value="${p.id}">${esc((D.houses.find(h=>h.id===p.houseId)||{}).name)} • ${esc(p.crop)}</option>`).join('')}</select></div>
 <div><label>วันที่</label><input id="hd" type="date" value="${today()}"></div>
 <div><label>ผลผลิต</label><input id="hq" type="number" min="0" step=".01" placeholder="ผลผลิต"></div>
 <div><label>หน่วย</label><input id="hu" value="kg"></div>
 <div><label>Loss</label><input id="hw" type="number" min="0" step=".01" placeholder="Loss"></div>
 <div><label>ปัญหา / หมายเหตุ</label><input id="hnote"></div></div><br><button class="btn" onclick="addHarvest()">บันทึก</button></div>
 <div class="card"><h3>📋 ประวัติการเก็บเกี่ยว</h3><div class="tableWrap"><table><tr><th>วันที่</th><th>โรง</th><th>พืช</th><th>ผลผลิต</th><th>Loss</th><th>หมายเหตุ</th><th>จัดการ</th></tr>
 ${(D.harvests||[]).slice().reverse().map(x=>{let p=plans.find(y=>y.id===x.cycleId)||{},h=D.houses.find(y=>y.id===p.houseId)||{};return `<tr><td>${esc(x.date||'-')}</td><td>${esc(h.name||'-')}</td><td>${esc(p.crop||'-')}</td><td>${numHarvest1067(x.qty)} ${esc(x.unit||'')}</td><td>${numHarvest1067(x.waste)} ${esc(x.unit||'')}</td><td>${esc(x.note||'')}</td><td>${canManage?`<button class="btn2" onclick="editHarvestV1067('${x.id}')">✏️ แก้ไข</button> <button class="btn2 dangerBtn" onclick="deleteHarvestV1067('${x.id}')">🗑️ ลบ</button>`:'-'}</td></tr>`}).join('')||'<tr><td colspan="7">ยังไม่มีข้อมูลเก็บเกี่ยว</td></tr>'}
 </table></div></div>`;
};
window.numHarvest1067=v=>Number(v||0).toLocaleString('th-TH',{maximumFractionDigits:2});
window.editHarvestV1067=function(hid){
 if(!me||me.role!=='Admin')return alert('เฉพาะ Admin เท่านั้น');
 const x=(D.harvests||[]).find(y=>y.id===hid);if(!x)return alert('ไม่พบรายการเก็บเกี่ยว');
 const opts=(D.yearPlans||[]).map(p=>`<option value="${p.id}" ${p.id===x.cycleId?'selected':''}>${esc((D.houses.find(h=>h.id===p.houseId)||{}).name)} • ${esc(p.crop)}</option>`).join('');
 showEditModal('✏️ แก้ไขบันทึกเก็บเกี่ยว',`<div class="modalgrid">
 <div><label>รอบการผลิต</label><select id="ehv">${opts}</select></div>
 <div><label>วันที่</label><input id="ehd" type="date" value="${esc(x.date||today())}"></div>
 <div><label>ผลผลิต</label><input id="ehq" type="number" min="0" step=".01" value="${Number(x.qty)||0}"></div>
 <div><label>หน่วย</label><input id="ehu" value="${esc(x.unit||'kg')}"></div>
 <div><label>Loss</label><input id="ehw" type="number" min="0" step=".01" value="${Number(x.waste)||0}"></div>
 <div><label>ปัญหา / หมายเหตุ</label><input id="ehnote" value="${esc(x.note||'')}"></div></div>`,()=>{
   const q=Number(ehq.value),w=Number(ehw.value);if(!ehv.value||!ehd.value||!(q>0))return alert('กรุณาระบุรอบการผลิต วันที่ และผลผลิตมากกว่า 0');
   x.cycleId=ehv.value;x.date=ehd.value;x.qty=q;x.unit=ehu.value.trim()||'kg';x.waste=Math.max(0,w||0);x.note=ehnote.value.trim();
   sv('harvests');if(typeof logAudit==='function')logAudit('EDIT','Harvest',x.id,x.qty+' '+x.unit);closeEditModal();harvest();
 });
};
window.deleteHarvestV1067=function(hid){
 if(!me||me.role!=='Admin')return alert('เฉพาะ Admin เท่านั้น');
 const x=(D.harvests||[]).find(y=>y.id===hid);if(!x)return alert('ไม่พบรายการเก็บเกี่ยว');
 if(!confirm(`ยืนยันลบบันทึกเก็บเกี่ยววันที่ ${x.date||'-'} จำนวน ${numHarvest1067(x.qty)} ${x.unit||''} ?\n\nการลบนี้ไม่สามารถย้อนกลับได้`))return;
 D.harvests=D.harvests.filter(y=>y.id!==hid);sv('harvests');if(typeof logAudit==='function')logAudit('DELETE','Harvest',hid,(x.qty||0)+' '+(x.unit||''));harvest();
};
})();
