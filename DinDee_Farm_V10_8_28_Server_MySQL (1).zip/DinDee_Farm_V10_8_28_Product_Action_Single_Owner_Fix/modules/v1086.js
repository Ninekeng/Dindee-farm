/* DinDee Farm V10.8.6 — Packed photo optional */
(function(){
'use strict';
/* Override only the active order action and packed handler; all other order flow remains unchanged. */
const oldOrderActions=window.orderActions;
window.orderActions=function(o){
 if(o.status==='Preparing')return `<div class="packed-action-v1086"><button class="btn" onclick="packed('${o.id}')">📦 เตรียมสินค้าเสร็จ</button><details><summary>＋ แนบรูป / หมายเหตุ (ไม่บังคับ)</summary><div class="packed-optional-v1086"><input id="prep_${o.id}" type="file" accept="image/*"><input id="rem_${o.id}" placeholder="หมายเหตุ (ถ้ามี)"></div></details></div>`;
 return oldOrderActions(o);
};
window.packed=function(i){
 const o=D.orders.find(x=>x.id===i);if(!o)return;
 const f=document.getElementById('prep_'+i)?.files?.[0],r=document.getElementById('rem_'+i)?.value?.trim()||'';
 const done=d=>{if(d)o.preparePhoto=d;if(r)o.remark=r;o.status='Packed';addHist(o,'Packed',r||'พนักงานเตรียมสินค้าเรียบร้อย');sv('orders');render()};
 if(f)fileData(f,done);else done('');
};
})();
