/* DinDee Farm V10.5.8 - Stock edit/delete + unified work history + annual plan cleanup */
(function(){
'use strict';
const n=v=>+v||0;
const admin=()=>{try{return typeof me!=='undefined'&&me&&me.role==='Admin'}catch(e){return false}};
const catTH={
'Crop Production':'การปลูกพืช','Livestock & Animals':'การเลี้ยงสัตว์','Food & Beverage':'อาหารและเครื่องดื่ม',
'Learning Center & Activities':'ศูนย์เรียนรู้และกิจกรรม','Farm Infrastructure':'ระบบและสิ่งปลูกสร้าง','Farm Development':'พัฒนาและบริหารฟาร์ม'
};
const catOptions=selected=>Object.keys(catTH).map(k=>`<option value="${esc(k)}" ${k===selected?'selected':''}>${esc(k)} — ${esc(catTH[k])}</option>`).join('');

/* Stock editor: use controlled master category dropdown and explicit DOM lookups. */
window.editStockV1043=function(i){
 const s=D.stock.find(x=>x.id===i);if(!s)return alert('ไม่พบ Stock');
 const units=(D.units||[]).filter(x=>x.active!==false);
 const suppliers=(D.suppliers||[]).filter(x=>x.active!==false);
 showEditModal('✏️ แก้ไข Stock / Lot',`<div class="form">
 <div><label>รายการ</label><input id="v58sn" value="${esc(s.name||'')}"></div>
 <div><label>Category</label><select id="v58cat">${catOptions(s.category||'Crop Production')}</select></div>
 <div><label>Lot</label><input id="v58lot" value="${esc(s.lot||'')}"></div>
 <div><label>คงเหลือ</label><input id="v58qty" type="number" min="0" step=".01" value="${n(s.qty)}"></div>
 <div><label>หน่วย</label><select id="v58unit">${units.map(u=>`<option value="${esc(u.name)}" ${u.name===s.unit?'selected':''}>${esc(u.name)}</option>`).join('')}${!units.length?`<option>${esc(s.unit||'')}</option>`:''}</select></div>
 <div><label>Minimum Stock</label><input id="v58min" type="number" min="0" step=".01" value="${n(s.minStock)}"></div>
 <div><label>วันหมดอายุ</label><input id="v58exp" type="date" value="${esc(s.expiryDate||'')}"></div>
 <div><label>Supplier</label><select id="v58sup"><option value="">-- ไม่ระบุ --</option>${suppliers.map(u=>`<option value="${esc(u.name)}" ${u.name===s.supplier?'selected':''}>${esc(u.name)}</option>`).join('')}</select></div>
 </div>`,()=>{
   const $=id=>document.getElementById(id),name=$('v58sn').value.trim();
   if(!name)return alert('กรุณากรอกรายการ');
   Object.assign(s,{name,category:$('v58cat').value,lot:$('v58lot').value.trim(),qty:n($('v58qty').value),unit:$('v58unit').value,minStock:n($('v58min').value),expiryDate:$('v58exp').value,supplier:$('v58sup').value});
   sv('stock');logAudit('EDIT','Stock',s.id,`${s.name} Lot ${s.lot||'-'}`);closeEditModal();render();
 });
};

/* Purchase by itself is not consumption. Only real usage/history blocks hard delete.
   If the only purchase is the source purchase for this lot, delete both together after explicit confirmation. */
window.deleteStockV1052=function(sid){
 if(!admin())return alert('เฉพาะ Admin เท่านั้น');
 const s=D.stock.find(x=>x.id===sid);if(!s)return;
 const usages=(D.usages||[]).filter(x=>x.stockId===sid || (x.item===s.name&&(x.lot||'')===(s.lot||'')));
 const costs=(D.costs||[]).filter(x=>x.stockId===sid || x.usageStockId===sid);
 const purchases=(D.purchases||[]).filter(x=>x.stockId===sid || (x.item===s.name&&(x.lot||'')===(s.lot||'')));
 if(usages.length||costs.length){
   if(!confirm(`“${s.name}” Lot ${s.lot||'-'} มีประวัติเบิกใช้/ต้นทุน ${usages.length+costs.length} รายการ\nจึงลบถาวรไม่ได้\n\nต้องการปิดใช้งาน Stock นี้แทนหรือไม่?`))return;
   s.active=false;s.archived=true;s.archivedAt=new Date().toISOString();sv('stock');logAudit('ARCHIVE','Stock',sid,s.name);render();return;
 }
 let msg=`ยืนยันลบ Stock “${s.name}” Lot ${s.lot||'-'} ถาวร?`;
 if(purchases.length)msg+=`\n\nพบรายการซื้อ/รับเข้า ${purchases.length} รายการที่สร้าง Stock นี้\nระบบจะลบรายการซื้อที่เชื่อมกับ Lot นี้และรายการ Expense อัตโนมัติของ Purchase ไปพร้อมกัน เพื่อไม่ให้ข้อมูลค้าง`;
 if(!confirm(msg))return;
 const pids=new Set(purchases.map(x=>x.id));
 D.stock=D.stock.filter(x=>x.id!==sid);
 if(pids.size){D.purchases=D.purchases.filter(x=>!pids.has(x.id));D.expenses=D.expenses.filter(x=>!(x.source==='Purchase'&&pids.has(x.refId)));sv('purchases');sv('expenses')}
 sv('stock');logAudit('DELETE','Stock',sid,`${s.name}; linked purchases removed=${pids.size}`);render();
};

/* Today: remove duplicated legacy/new history cards and render one concise recent history section. */
function unifiedHistory(){
 const rows=(D.tasks||[]).filter(t=>['Done','Problem','Postponed'].includes(t.status)||t.actualDate)
 .sort((a,b)=>String(b.actualDate||b.date||'').localeCompare(String(a.actualDate||a.date||''))).slice(0,8);
 const hn=id=>(D.houses.find(h=>h.id===id)||{}).name||'-';
 return `<div class="card v1058-history"><div class="sectionTitle"><div><h3>📋 ประวัติการทำงาน</h3><span class="muted">รายการทำงานล่าสุด • ดูรายละเอียดทั้งหมดได้จากปุ่มด้านขวา</span></div><button class="btn2" onclick="workHistoryV1056()">ดูประวัติทั้งหมด →</button></div>
 <div class="tableWrap"><table><tr><th>วันที่ทำจริง</th><th>โรงเรือน</th><th>งาน</th><th>ผู้ปฏิบัติงาน</th><th>สถานะ</th></tr>${rows.map(t=>`<tr><td>${esc(t.actualDate||t.date||'-')}</td><td>${esc(hn(t.houseId))}</td><td><b>${esc(t.action||'-')}</b></td><td>${esc(t.owner||((D.responsibles||[]).find(x=>x.id===t.ownerId)||{}).name||'-')}</td><td>${esc(t.status==='Done'?'ทำแล้ว':t.status==='Problem'?'มีปัญหา':t.status==='Postponed'?'เลื่อนงาน':t.status||'-')}</td></tr>`).join('')||'<tr><td colspan="5">ยังไม่มีประวัติการทำงาน</td></tr>'}</table></div></div>`;
}
const today58=window.todayPage;
window.todayPage=function(){
 today58.apply(this,arguments);
 // Remove both old V10.4.4 history and V10.5.6 summary card.
 [...content.querySelectorAll('.workHistory,.v1058-history')].forEach(x=>x.remove());
 [...content.querySelectorAll('.card')].forEach(x=>{const t=(x.querySelector('h3')?.textContent||'').trim();if(t.includes('ประวัติการทำงาน')||t.includes('ประวัติงานที่ทำแล้ว'))x.remove()});
 content.insertAdjacentHTML('beforeend',unifiedHistory());
};

/* Annual plan: no delete button on Gantt/timeline. Cycle bars only open Edit.
   Remove stray delete controls injected into annual grid by legacy patch code. */
const year58=window.year;
window.year=function(){
 year58.apply(this,arguments);
 const annual=content.querySelector('.annualCard');
 if(annual){
   [...annual.querySelectorAll('button')].forEach(b=>{const oc=b.getAttribute('onclick')||'',tx=b.textContent||'';if(oc.includes('deletePlan')||tx.includes('ลบ'))b.remove()});
 }
 // Explicitly remove any delete button sitting in annual row/track/house label.
 [...content.querySelectorAll('.annualRow .dangerBtn,.annualTrack button[onclick*="deletePlan"],.annualHouse button[onclick*="deletePlan"]')].forEach(x=>x.remove());
};
})();
