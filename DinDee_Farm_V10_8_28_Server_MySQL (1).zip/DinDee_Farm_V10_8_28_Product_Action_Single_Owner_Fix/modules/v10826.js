/* DinDee Farm V10.8.26 — UI continuity, Product actions, Sales Report, Evidence storage */
(function(){
'use strict';
const A=x=>Array.isArray(x)?x:[], n=x=>Number(x)||0, digits=x=>String(x||'').replace(/\D/g,'');

/* Generic modal hygiene: a previous checkout success must never hide Save on the next edit modal. */
const show26=window.showEditModal;
window.showEditModal=function(title,html,onSave){
  const r=show26.apply(this,arguments),b=document.getElementById('emSave');
  if(b){b.style.display='';b.disabled=false;b.textContent='💾 บันทึก';b.onclick=typeof onSave==='function'?onSave:null;}
  return r;
};

/* Product Catalog: exactly one edit and one delete action, both icon-only. */
const shopAdmin26=window.shopadmin;
window.shopadmin=function(){
  const r=shopAdmin26.apply(this,arguments);
  document.querySelectorAll('#content table tr').forEach(tr=>{
    const edit=[...tr.querySelectorAll('button')].filter(b=>/editProduct\(/.test(b.getAttribute('onclick')||''));
    const dels=[...tr.querySelectorAll('button')].filter(b=>/deleteProduct/.test(b.getAttribute('onclick')||'')||/ลบ/.test(b.textContent||''));
    edit.slice(1).forEach(b=>b.remove());dels.slice(1).forEach(b=>b.remove());
    if(edit[0]){edit[0].textContent='✏️';edit[0].title='แก้ไข';edit[0].setAttribute('aria-label','แก้ไข');}
    if(dels[0]){dels[0].textContent='🗑️';dels[0].title='ลบ';dels[0].setAttribute('aria-label','ลบ');}
  });
  return r;
};
const editProduct26=window.editProduct;
window.editProduct=function(){const r=editProduct26.apply(this,arguments),b=document.getElementById('emSave');if(b){b.style.display='';b.disabled=false;b.textContent='💾 บันทึก';}return r};

/* Parse ISO dates and Thai locale dates such as 30/9/2569 15:30:00 into YYYY-MM-DD. */
function orderDate26(o){
  for(const raw of [o?.paidDate,o?.date,o?.created]){
    const s=String(raw||'').trim();if(!s)continue;
    let m=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);if(m)return `${m[1]}-${String(m[2]).padStart(2,'0')}-${String(m[3]).padStart(2,'0')}`;
    m=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);if(m){let y=+m[3];if(y>2400)y-=543;return `${y}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;}
  }return '';
}
function recognized26(o){return !!(o&&(o.cashReceived||A(D.income).some(x=>x.source==='Farm Shop'&&x.refId===o.id)||['Confirmed','Preparing','Packed','Shipping','Completed'].includes(o.status)))}
function lines26(o){let ls=A(o.items);if(ls.length)return ls.map(i=>{let p=A(D.products).find(x=>x.id===i.productId);return {name:i.name||p?.name||'-',qty:n(i.qty),price:n(i.price??p?.price)}});let p=A(D.products).find(x=>x.id===o.productId);return o.productId?[{name:p?.name||'-',qty:n(o.qty)||1,price:n(o.price??p?.price)}]:[]}
function group26(rows){return Object.entries(rows.reduce((a,[k,v])=>{k=k||'ไม่ระบุ';a[k]=(a[k]||0)+n(v);return a},{})).sort((a,b)=>b[1]-a[1])}
window.salesReport=function(){
  const S=window.srS||today().slice(0,7)+'-01',E=window.srE||today();
  const orders=A(D.orders).filter(o=>{const d=orderDate26(o);return d&&d>=S&&d<=E&&!['Cancelled','Rejected'].includes(o.status)}),paid=orders.filter(recognized26);
  const total=paid.reduce((s,o)=>s+n(o.total),0),all=orders.reduce((s,o)=>s+n(o.total),0),due=Math.max(0,all-total);
  const products=group26(paid.flatMap(o=>lines26(o).map(l=>[l.name,l.qty*l.price]))),staff=group26(paid.map(o=>[o.cashReceivedBy||o.salesperson||'ไม่ระบุ',o.total])),customers=group26(paid.map(o=>[o.customer||'ไม่ระบุ',o.total]));
  content.innerHTML=`<div class="card"><h2>📊 รายงานการขาย</h2><p>อ่านข้อมูลจาก Farm Shop Order โดยตรง และรองรับวันที่ Order ภาษาไทย/พ.ศ.</p><div class="form noPrint"><div><label>ตั้งแต่</label><input id="srs" type="date" value="${S}"></div><div><label>ถึง</label><input id="sre" type="date" value="${E}"></div></div><br><button class="btn noPrint" onclick="window.srS=srs.value;window.srE=sre.value;salesReport()">🔎 แสดงผล</button> <button class="btn2 noPrint" onclick="printCurrent()">🖨️ Print</button></div>
  <div class="kpiRow"><div class="kpiBox">ยอดขายที่รับรู้แล้ว<b>฿${money(total)}</b></div><div class="kpiBox">Orders ชำระ/ยืนยัน<b>${paid.length}</b></div><div class="kpiBox">ยอด Order ที่ยังไม่รับรู้<b>฿${money(due)}</b></div><div class="kpiBox">Orders ทั้งหมด<b>${orders.length}</b></div></div>
  ${reportGroup('ยอดขายตามสินค้า',products)}${reportGroup('ยอดขายตามพนักงาน',staff)}${reportGroup('ยอดขายตามลูกค้า',customers)}
  <div class="card"><h3>🧾 รายการ Order ที่เชื่อมกับรายงาน</h3><div class="scroll"><table><tr><th>วันที่</th><th>Order</th><th>ลูกค้า</th><th>สินค้า</th><th>ยอด</th><th>สถานะ</th></tr>${orders.slice().reverse().map(o=>`<tr><td>${esc(orderDate26(o))}</td><td><b>${esc(o.no||'-')}</b></td><td>${esc(o.customer||'-')}</td><td>${lines26(o).map(l=>`${esc(l.name)} × ${l.qty}`).join('<br>')||'-'}</td><td>฿${money(o.total)}</td><td>${esc(o.status||'-')}</td></tr>`).join('')||'<tr><td colspan="6">ไม่มีข้อมูล</td></tr>'}</table></div></div>`;
};
window.orderDateV10826=orderDate26;

/* Large payment slips belong in IndexedDB, not in the dindee_v7_orders LocalStorage JSON. */
const DB='dindee_evidence_v1',STORE='files';
function db26(){return new Promise((res,rej)=>{if(!window.indexedDB)return rej(new Error('Browser นี้ไม่รองรับ IndexedDB'));const q=indexedDB.open(DB,1);q.onupgradeneeded=()=>{if(!q.result.objectStoreNames.contains(STORE))q.result.createObjectStore(STORE)};q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error||new Error('เปิด Evidence Storage ไม่สำเร็จ'))})}
async function put26(key,val){const db=await db26();return new Promise((res,rej)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(val,key);tx.oncomplete=()=>{db.close();res(key)};tx.onerror=()=>{db.close();rej(tx.error)}})}
async function get26(key){const db=await db26();return new Promise((res,rej)=>{const tx=db.transaction(STORE,'readonly'),q=tx.objectStore(STORE).get(key);q.onsuccess=()=>{db.close();res(q.result||'')};q.onerror=()=>{db.close();rej(q.error)}})}
async function del26(key){try{const db=await db26();await new Promise((res,rej)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).delete(key);tx.oncomplete=res;tx.onerror=()=>rej(tx.error)});db.close()}catch(e){console.warn(e)}}
window.previewOrderSlipV10826=async function(oid){const o=A(D.orders).find(x=>x.id===oid);if(!o)return alert('ไม่พบ Order');let u=o.slip||'';if(!u&&o.slipRef)try{u=await get26(o.slipRef)}catch(e){return alert('เปิดหลักฐานไม่สำเร็จ: '+e.message)}if(!u)return alert('Order นี้ไม่มีไฟล์หลักฐาน');showEditModal(`👁️ หลักฐาน ${o.no||''}`,`<div style="text-align:center"><img src="${u}" alt="หลักฐาน" style="max-width:100%;max-height:70vh;object-fit:contain"></div>`,null);const b=document.getElementById('emSave');if(b)b.style.display='none'};
async function migrate26(){let changed=false;for(const o of A(D.orders)){if(o.slip&&!o.slipRef){try{const key='order:'+o.id;await put26(key,o.slip);o.slipRef=key;delete o.slip;changed=true}catch(e){console.warn('Evidence migration skipped',o.no,e)}}}if(changed)try{sv('orders')}catch(e){console.error('Save migrated orders',e)}}
setTimeout(()=>migrate26(),250);

/* Active checkout path: save slip to IndexedDB first; LocalStorage order keeps only slipRef. */
let busy26=false;
function cart26(){return A(window.cart).map(x=>({...x,p:A(D.products).find(p=>p.id===x.productId)})).filter(x=>x.p&&n(x.qty)>0)}
function customer26(p){const q=digits(p);return A(D.customers).find(c=>digits(c.phone)===q)}
function costSnap26(p,q){let unitCost=typeof window.productUnitCostV10824==='function'?n(window.productUnitCostV10824(p)):n(p.manualUnitCost);return {sourceType:p.sourceType||'other',sourceCycleId:p.sourceCycleId||'',sourceHouseId:p.sourceHouseId||'',sourceStockId:p.sourceStockId||'',unitCost,costTotal:n(q)*unitCost}}
function busyBtn26(on){busy26=on;const b=document.getElementById('emSave');if(b){b.style.display='';b.disabled=on;b.textContent=on?'กำลังบันทึก...':'ยืนยันคำสั่งซื้อ'}}
window.submitCheckoutV10826=function(qrType){
 if(busy26)return;const name=document.getElementById('coName')?.value.trim()||'',phone=digits(document.getElementById('coPhone')?.value),pay=document.getElementById('coPay')?.value||'qr',delivery=document.getElementById('coDelivery')?.value||'',address=document.getElementById('coAddress')?.value.trim()||'',note=document.getElementById('coNote')?.value.trim()||'',items=cart26();
 if(!name||phone.length<9)return alert('กรุณากรอกชื่อและเบอร์โทรให้ถูกต้อง');if(!items.length)return alert('ไม่พบสินค้าในตะกร้า');for(const x of items)if(n(x.qty)>n(x.p.qty))return alert(`สินค้า ${x.p.name} คงเหลือไม่เพียงพอ`);
 let c=customer26(phone),pin=document.getElementById('coPin89')?.value||'',pin2=document.getElementById('coPinConfirm89')?.value||'';if(c&&c.pinHash){if(!/^\d{4}$/.test(pin)||c.pinHash!==hash(pin))return alert('PIN เดิมไม่ถูกต้อง กรุณาลองอีกครั้ง')}else{if(!/^\d{4}$/.test(pin))return alert('PIN ต้องเป็นตัวเลข 4 หลัก');if(pin!==pin2)return alert('PIN ยืนยันไม่ตรงกัน')}
 const file=document.getElementById('coSlip')?.files?.[0];if(pay==='qr'&&!file)return alert('กรุณาแนบหลักฐานการชำระเงินก่อนส่งคำสั่งซื้อ');busyBtn26(true);
 const run=async()=>{let slipRef='';try{if(pay==='qr'){const data=await new Promise((res,rej)=>{try{fileData(file,res)}catch(e){rej(e)}});slipRef='order:'+id();await put26(slipRef,data)}
   if(!c){c={id:id(),phone,name,created:today(),active:true};D.customers.push(c)}c.name=name||c.name;c.address=address||c.address;c.note=note||c.note;c.active=c.active!==false;if(!c.pinHash){c.pinHash=hash(pin);c.pinCreatedAt=new Date().toISOString()}
   const total=items.reduce((s,x)=>s+n(x.qty)*n(x.p.price),0),created=new Date().toLocaleString('th-TH'),o={id:id(),no:nextOrderNo(),customerId:c.id,customer:name,phone,items:items.map(x=>({productId:x.p.id,name:x.p.name,qty:n(x.qty),unit:x.p.unit,price:n(x.p.price),...costSnap26(x.p,x.qty)})),qty:items.reduce((s,x)=>s+n(x.qty),0),total,paymentMethod:pay,paymentQr:qrType,delivery,address,note,status:pay==='qr'?'Payment Submitted':'New',cashStatus:pay==='cash'?'Pending Cash':'',created,slipRef,history:[]};o.cogs=o.items.reduce((s,x)=>s+n(x.costTotal),0);o.history.push({status:o.status,time:created,note:pay==='qr'?'ส่งคำสั่งซื้อพร้อมหลักฐานชำระเงิน':'สั่งซื้อและเลือกชำระเงินสด'});
   D.orders.push(o);try{sv('customers');sv('orders')}catch(e){D.orders.pop();if(slipRef)await del26(slipRef);throw e}items.forEach(x=>x.p.qty=Math.max(0,n(x.p.qty)-n(x.qty)));sv('products');if(Array.isArray(window.cart))window.cart.length=0;try{logAudit('CREATE','Farm Shop Order',o.id,o.no)}catch(e){}
   const title=document.getElementById('emTitle'),host=document.getElementById('emBody'),save=document.getElementById('emSave');if(title)title.textContent='คำสั่งซื้อสำเร็จ';if(host)host.innerHTML=`<div style="text-align:center;padding:18px"><div style="font-size:3rem">✅</div><h2>สั่งซื้อสำเร็จ</h2><h2>${esc(o.no)}</h2><p>ยอดรวม ฿${money(o.total)}</p><button class="btn2" onclick="closeEditModal();shop()">กลับร้านค้า</button> <button class="btn" onclick="closeEditModal();go('track')">ติดตามคำสั่งซื้อ</button></div>`;if(save)save.style.display='none';busy26=false;
 }catch(e){console.error(e);busyBtn26(false);alert('บันทึกคำสั่งซื้อไม่สำเร็จ: '+(e.message||e))}};run();
};
const checkout26=window.openCheckoutV10814;window.openCheckoutV10814=function(){busy26=false;const r=checkout26.apply(this,arguments),b=document.getElementById('emSave');if(b){b.style.display='';b.disabled=false;b.textContent='ยืนยันคำสั่งซื้อ';b.onclick=()=>{const act=cart26().some(x=>/กิจกรรม|workshop|course|คอร์ส/i.test(((D.shopCategories||[]).find(c=>c.id===x.p.categoryId)?.name||x.p.category||'')));submitCheckoutV10826(act?'activity':'farm')}}return r};

/* Order page: expose IndexedDB evidence too. */
const orders26=window.orders;window.orders=function(){const r=orders26.apply(this,arguments);document.querySelectorAll('#content .orderCard').forEach(card=>{const no=card.querySelector('h3')?.textContent?.trim(),o=A(D.orders).find(x=>x.no===no);if(!o?.slipRef)return;const labels=[...card.querySelectorAll('label')],lab=labels.find(x=>x.textContent.includes('หลักฐาน')),p=lab?.parentElement?.querySelector('p');if(p&&/ยังไม่มีหลักฐาน/.test(p.textContent))p.innerHTML=`<button class="btn2" onclick="previewOrderSlipV10826('${o.id}')">🧾 ดูหลักฐาน</button>`});return r};

/* Evidence Center: preview + go to source; deletion stays at the source record. */
window.goOrderV10826=function(oid){window.orderFilter1043='all';go('orders');setTimeout(()=>{const o=A(D.orders).find(x=>x.id===oid);if(!o)return;const card=[...document.querySelectorAll('#content .orderCard')].find(c=>c.querySelector('h3')?.textContent?.trim()===o.no);if(card){card.scrollIntoView({block:'center'});card.style.outline='3px solid #0b7a61';setTimeout(()=>card.style.outline='',1800)}},50)};
window.evidence=function(){
 let q=String(window.evQ10821||'').toLowerCase(),src=window.evSrc10821||'',from=window.evFrom10821||'',to=window.evTo10821||'',rows=[];
 A(D.purchases).filter(x=>x.evidence).forEach(x=>rows.push({date:x.date,type:'ใบเสร็จ/หลักฐานซื้อ',source:'Purchase',ref:typeof friendlyRefV10821==='function'?friendlyRefV10821('Purchase',x.id):x.id,party:x.supplier||'',name:x.item||'',amount:n(x.total),data:x.evidence,id:x.id}));
 A(D.costs).filter(x=>x.evidence).forEach(x=>rows.push({date:x.date,type:'หลักฐานต้นทุน',source:'Direct Cost',ref:x.id,party:'',name:x.name||'',amount:n(x.amount||x.cost),data:x.evidence,id:x.id}));
 A(D.orders).filter(x=>x.slip||x.slipRef).forEach(o=>rows.push({date:orderDate26(o),type:'สลิปชำระเงิน',source:'Farm Shop',ref:o.no||'Order',party:o.customer||'',name:lines26(o).map(l=>l.name).join(', '),amount:n(o.total),data:o.slip||'',slipRef:o.slipRef||'',id:o.id}));
 rows=rows.filter(x=>(!from||x.date>=from)&&(!to||x.date<=to)&&(!src||x.source===src)&&(!q||[x.type,x.source,x.ref,x.party,x.name].join(' ').toLowerCase().includes(q))).sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 window.evRows10826=rows;content.innerHTML=`<div class="card"><h3>📎 หลักฐาน / เอกสารแนบ</h3><p>ค้นหาและดูหลักฐานจากรายการต้นทาง การลบให้ดำเนินการที่ Order / Purchase ต้นทางเพื่อรักษาความถูกต้องของข้อมูล</p><div class="form noPrint"><div><label>ตั้งแต่</label><input id="evf" type="date" value="${from}"></div><div><label>ถึง</label><input id="evt" type="date" value="${to}"></div><div><label>แหล่งข้อมูล</label><select id="evs"><option value="">ทั้งหมด</option>${['Purchase','Farm Shop','Direct Cost'].map(x=>`<option ${src===x?'selected':''}>${x}</option>`).join('')}</select></div><div><label>ค้นหา</label><input id="evq" value="${esc(window.evQ10821||'')}" placeholder="รายการ / คู่ค้า / Order"></div></div><br><button class="btn" onclick="window.evFrom10821=evf.value;window.evTo10821=evt.value;window.evSrc10821=evs.value;window.evQ10821=evq.value;evidence()">🔎 ค้นหา</button> <button class="btn2" onclick="window.evFrom10821=window.evTo10821=window.evSrc10821=window.evQ10821='';evidence()">ล้าง Filter</button></div><div class="card scroll"><table><tr><th>วันที่</th><th>ประเภท</th><th>เลขอ้างอิง</th><th>แหล่งข้อมูล</th><th>รายการ / คู่ค้า</th><th>จำนวนเงิน</th><th>จัดการ</th></tr>${rows.map((x,i)=>`<tr><td>${esc(x.date||'-')}</td><td>${esc(x.type)}</td><td><b>${esc(x.ref)}</b></td><td>${esc(x.source)}</td><td>${esc(x.name||'-')}${x.party?`<br><span class="small">${esc(x.party)}</span>`:''}</td><td>฿${money(x.amount)}</td><td><button class="btn2" onclick="previewEvidenceRowV10826(${i})">👁️</button>${x.source==='Farm Shop'?` <button class="btn2" title="ไปยัง Order" onclick="goOrderV10826('${x.id}')">↗️</button>`:''}</td></tr>`).join('')||'<tr><td colspan="7">ยังไม่มีหลักฐานตามเงื่อนไข</td></tr>'}</table></div>`;
};
window.previewEvidenceRowV10826=async function(i){const x=A(window.evRows10826)[i];if(!x)return;let u=x.data||'';if(!u&&x.slipRef)try{u=await get26(x.slipRef)}catch(e){return alert('เปิดหลักฐานไม่สำเร็จ')}if(!u)return alert('ไม่พบไฟล์หลักฐาน');showEditModal('👁️ ดูหลักฐาน',`<div style="text-align:center"><img src="${u}" alt="หลักฐาน" style="max-width:100%;max-height:70vh;object-fit:contain"></div>`,null);const b=document.getElementById('emSave');if(b)b.style.display='none'};

/* When deleting a test order, remove its separated evidence too. */
const delOrder26=window.deleteTestCustomerOrderV10825;window.deleteTestCustomerOrderV10825=function(oid){const o=A(D.orders).find(x=>x.id===oid),ref=o?.slipRef;const before=A(D.orders).length,r=delOrder26.apply(this,arguments);if(ref&&A(D.orders).length<before)del26(ref);return r};
})();
