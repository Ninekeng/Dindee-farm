/* DinDee Farm V10.8.14 — rebuilt Farm Shop Cart -> Checkout transition */
(function(){
'use strict';
const n=v=>Number(v)||0;
const digits=v=>String(v||'').replace(/\D/g,'');
function cartRows14(){
  if(!Array.isArray(window.cart)) window.cart=[];
  for(let i=window.cart.length-1;i>=0;i--){
    const x=window.cart[i],p=(D.products||[]).find(z=>z.id===x.productId),max=p?Math.max(0,n(p.qty)):0,q=n(x.qty);
    if(!p||q<=0||max<=0){window.cart.splice(i,1);continue;}
    x.qty=Math.min(q,max);
  }
  return window.cart.map(x=>({...x,p:D.products.find(p=>p.id===x.productId)})).filter(x=>x.p&&n(x.qty)>0);
}
function count14(){return cartRows14().reduce((s,x)=>s+n(x.qty),0)}
function catName14(p){return (D.shopCategories||[]).find(c=>c.id===p.categoryId)?.name||p.category||''}
function activity14(p){return /กิจกรรม|workshop|course|คอร์ส/i.test(catName14(p))}
function customer14(phone){const p=digits(phone);return (D.customers||[]).find(c=>digits(c.phone)===p)}
function badge14(){document.querySelectorAll('.cart-count-v10814,.cart-entry-v10814 b').forEach(el=>el.textContent=String(count14()))}
window.pinFieldsV10814=function(){
  const phoneEl=document.getElementById('coPhone'),box=document.getElementById('coPinBox10814');if(!phoneEl||!box)return;
  const p=digits(phoneEl.value),c=customer14(p);
  if(p.length<9){box.innerHTML='<div class="notice">🔐 กรอกเบอร์โทรก่อน ระบบจะแสดงช่อง PIN อัตโนมัติ</div>';return;}
  if(c&&c.pinHash) box.innerHTML=`<div class="pin-title-v10810">🔐 พบลูกค้าเดิม: ${esc(c.name||'ลูกค้า')}</div><label><b>กรอก PIN เดิม 4 หลัก</b></label><input id="coPin89" type="password" inputmode="numeric" maxlength="4" autocomplete="current-password" placeholder="••••"><div class="small">ใช้ PIN เดิม หากจำไม่ได้ให้ติดต่อ Admin เพื่อ Reset PIN</div>`;
  else box.innerHTML=`<div class="pin-title-v10810">🔐 ${c?'บัญชีนี้ยังไม่มี PIN — ตั้ง PIN ครั้งแรก':'ลูกค้าใหม่ — ตั้ง PIN 4 หลัก'}</div><div class="pin-grid-v1089"><div><label><b>ตั้ง PIN 4 หลัก</b></label><input id="coPin89" type="password" inputmode="numeric" maxlength="4" autocomplete="new-password" placeholder="••••"></div><div><label><b>ยืนยัน PIN</b></label><input id="coPinConfirm89" type="password" inputmode="numeric" maxlength="4" autocomplete="new-password" placeholder="••••"></div></div><div class="small">PIN ใช้ติดตาม Order และดูประวัติการซื้อ กรุณาจำ PIN นี้ไว้</div>`;
};
window.openCheckoutV10814=function(){
  const items=cartRows14();if(!items.length){alert('ยังไม่มีสินค้าในตะกร้า');return;}
  const total=items.reduce((s,x)=>s+n(x.qty)*n(x.p.price),0),act=items.some(x=>activity14(x.p)),qr=act?D.farmProfile.activityQr:D.farmProfile.farmQr;
  showEditModal('ยืนยันคำสั่งซื้อ',`<div class="checkoutGrid"><div><h3>ข้อมูลลูกค้า</h3><div class="form oneCol"><div><label>ชื่อ-นามสกุล</label><input id="coName"></div><div><label>เบอร์โทร</label><input id="coPhone" inputmode="tel" oninput="pinFieldsV10814()"></div><div id="coPinBox10814" class="pin-box-v1089"><div class="notice">🔐 กรอกเบอร์โทรก่อน ระบบจะแสดงช่อง PIN อัตโนมัติ</div></div><div><label>วิธีรับสินค้า</label><select id="coDelivery" onchange="deliveryNoteV1043()"><option>รับที่ฟาร์ม</option><option>จัดส่ง - โทรสอบถามก่อน</option></select></div><div id="deliveryWarn" class="notice hidden">🚚 กรุณาโทรสอบถามดินดีฟาร์มเพื่อยืนยันพื้นที่จัดส่งและค่าจัดส่งก่อนชำระเงิน</div><div><label>ที่อยู่ / รายละเอียดการรับ</label><textarea id="coAddress"></textarea></div><div><label>หมายเหตุ</label><textarea id="coNote"></textarea></div></div></div><div class="checkoutSummary"><h3>รายการสินค้า</h3>${items.map(x=>`<div class="sumLine"><span>${esc(x.p.name)} · ${x.qty} ${esc(x.p.unit)} × ฿${money(x.p.price)}</span><b>฿${money(n(x.qty)*n(x.p.price))}</b></div>`).join('')}<div class="checkoutTotal"><span>ยอดชำระ</span><b>฿${money(total)}</b></div><label>วิธีชำระเงิน</label><select id="coPay" onchange="toggleCheckoutPayV104()"><option value="qr">QR Code</option><option value="cash">เงินสดตอนรับสินค้า</option></select><div id="coQrBox" class="qrBox">${qr?`<img src="${qr}"><b>${act?'Activity QR':'Farm QR'}</b>`:'<div class="notice">ยังไม่ได้ตั้งค่า QR ใน Settings</div>'}<label>แนบหลักฐานการชำระเงิน</label><input id="coSlip" type="file" accept="image/*,.pdf"></div><div id="coCashBox" class="notice hidden">ชำระเงินสดตอนรับสินค้า ไม่ต้องแนบสลิป</div></div></div>`,()=>window.submitCheckoutV104(act?'activity':'farm'));
  const save=document.getElementById('emSave');if(save)save.textContent='ยืนยันคำสั่งซื้อ';
  window.pinFieldsV10814();
};
window.changeCartV10814=function(pid,delta){
  const x=window.cart.find(z=>z.productId===pid),p=D.products.find(z=>z.id===pid);if(!x||!p)return;
  const q=Math.min(Math.max(0,n(x.qty)+n(delta)),Math.max(0,n(p.qty)));
  if(q<=0)window.cart.splice(window.cart.indexOf(x),1);else x.qty=q;
  window.openCartV10814();
};
window.openCartV10814=function(){
  const items=cartRows14(),total=items.reduce((s,x)=>s+n(x.qty)*n(x.p.price),0);
  showEditModal('ตะกร้าสินค้า',`<div class="cartList">${items.map(x=>`<div class="cartLine"><div><b>${esc(x.p.name)}</b><small>฿${money(x.p.price)} / ${esc(x.p.unit)} · เหลือ ${x.p.qty}</small></div><div class="qtyStepper"><button type="button" onclick="changeCartV10814('${x.p.id}',-1)">−</button><b>${x.qty}</b><button type="button" onclick="changeCartV10814('${x.p.id}',1)">+</button></div><b>฿${money(n(x.qty)*n(x.p.price))}</b></div>`).join('')||'<p>ยังไม่มีสินค้าในตะกร้า</p>'}</div><div class="checkoutTotal"><span>ยอดรวม</span><b>฿${money(total)}</b></div>`,()=>window.openCheckoutV10814());
  const save=document.getElementById('emSave');if(save){save.textContent=items.length?'ดำเนินการสั่งซื้อ →':'ไม่มีสินค้า';save.disabled=!items.length;}
  badge14();
};
/* Render one direct cart entry; do not depend on older cart handlers. */
const shop14=window.shop;
window.shop=function(){
  const r=shop14.apply(this,arguments),b=document.querySelector('#content .cartButton,#content .cart-entry-v10813');
  if(b){b.classList.remove('cartButton','cart-entry-v10813');b.classList.add('cart-entry-v10814');b.setAttribute('onclick','openCartV10814()');b.innerHTML=`ตะกร้า <b class="cart-count-v10814">${count14()}</b>`;}
  return r;
};
})();
