/* DinDee Farm V10.6.1 - Monthly task-type matrix + detailed print */
(function(){
'use strict';
const pad=n=>String(n).padStart(2,'0');
const monthDays=ym=>{const [y,m]=ym.split('-').map(Number),last=new Date(y,m,0).getDate();return Array.from({length:last},(_,i)=>`${y}-${pad(m)}-${pad(i+1)}`)};
const hname=id=>(D.houses.find(h=>h.id===id)||{}).name||'-';
const activeCycle=(hid,date)=>(D.yearPlans||[]).find(p=>p.houseId===hid&&date>=p.start&&date<=p.end);
const activeTypes=()=> (D.taskTypes||[]).filter(x=>x.active!==false);
const taskState=t=>t.status==='Done'?'done':(['Issue','Problem'].includes(t.status)?'issue':t.status==='Postponed'?'postponed':'planned');
const taskMark=t=>taskState(t)==='done'?'✓':taskState(t)==='issue'?'!':taskState(t)==='postponed'?'↷':'●';
const ownerOptions=()=>`<option value="">-- ยังไม่ระบุ --</option>${(D.responsibles||[]).filter(x=>x.active!==false).map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}`;

window.plan30=function(){
 const ym=window.p30Month||today().slice(0,7), mode=window.p30Mode||'matrix';
 content.innerHTML=`<div class="pageHero monthlyHero"><div><span class="eyebrow">MONTHLY OPERATIONS</span><h2>แผนรายเดือน</h2><p>เลือกประเภทงานและวันที่จากตารางเพื่อสร้างแผนงานได้โดยตรง</p></div>
 <div class="monthlyControls"><input id="p30month" type="month" value="${ym}" onchange="window.p30Month=this.value;plan30()"><div class="heroActions"><button class="btn2 ${mode==='matrix'?'active':''}" onclick="window.p30Mode='matrix';plan30()">ตารางงาน</button><button class="btn2" onclick="printMonthlyV1061()">🖨️ พิมพ์รายละเอียด</button><button class="btn" onclick="taskCenterV1059()">📋 สรุปและจัดการงาน</button></div></div></div>
 <div class="card monthly-help"><b>วิธีใช้:</b> คลิกช่องวันที่ของประเภทงาน → กำหนดรายละเอียด / ผู้รับผิดชอบ / วัตถุดิบ / ปริมาณ / หมายเหตุ → บันทึกงาน
 <span class="monthLegend"><i class="lg planned"></i> มีแผน <i class="lg done"></i> ทำแล้ว <i class="lg issue"></i> มีปัญหา <i class="lg postponed"></i> เลื่อนงาน</span></div>
 <div id="p30area"></div>`;
 drawMonthlyMatrixV1061();
};

window.drawMonthlyMatrixV1061=function(){
 const ym=document.getElementById('p30month')?.value||window.p30Month||today().slice(0,7),dates=monthDays(ym),types=activeTypes(),houses=(D.houses||[]).filter(h=>h.active!==false);
 const head=dates.map(d=>`<th>${+d.slice(8)}</th>`).join('');
 p30area.innerHTML=`<div class="card monthly-matrix-wrap"><table class="monthly-matrix"><thead><tr><th class="sticky-name">โรงเรือน / ประเภทงาน</th>${head}</tr></thead><tbody>
 ${houses.map(h=>`<tr class="house-row"><td colspan="${dates.length+1}">🏡 <b>${esc(h.name)}</b></td></tr>${types.map(tp=>`<tr><td class="sticky-name tasktype-name">↳ ${esc(tp.name)}</td>${dates.map(d=>{
  const tasks=(D.tasks||[]).filter(t=>t.houseId===h.id&&t.date===d&&(t.typeId===tp.id||(!t.typeId&&t.type===tp.name)));
  return `<td class="matrix-cell ${tasks.length?'has-task':''}" onclick="monthlyCellV1061('${h.id}','${tp.id}','${d}')">${tasks.map(t=>`<span class="matrix-mark ${taskState(t)}" title="${esc(t.action||tp.name)}">${taskMark(t)}</span>`).join('')||'<span class="matrix-empty">＋</span>'}</td>`}).join('')}</tr>`).join('')}`).join('')||`<tr><td colspan="${dates.length+1}">ยังไม่มีโรงเรือนหรือประเภทงานที่เปิดใช้งาน</td></tr>`}
 </tbody></table></div>`;
};

window.monthlyCellV1061=function(hid,typeId,date){
 const tp=D.taskTypes.find(x=>x.id===typeId),existing=(D.tasks||[]).filter(t=>t.houseId===hid&&t.date===date&&(t.typeId===typeId||(!t.typeId&&t.type===tp?.name)));
 if(existing.length){
   const rows=existing.map(t=>`<div class="existing-task"><div><b>${esc(t.action||tp.name)}</b><small>${esc(t.status||'Pending')}</small></div><div><button class="btn2" onclick="closeEditModal();editTask('${t.id}')">✏️ แก้ไข</button> <button class="btn2 dangerBtn" onclick="closeEditModal();deleteTaskSafeV1059('${t.id}')">🗑️ ลบ</button></div></div>`).join('');
   showEditModal(`📅 ${date} • ${hname(hid)}`,`${rows}<hr><button class="btn" type="button" onclick="closeEditModal();newMonthlyTaskV1061('${hid}','${typeId}','${date}')">＋ เพิ่มงานอีก</button>`,()=>closeEditModal());return;
 }
 newMonthlyTaskV1061(hid,typeId,date);
};

window.newMonthlyTaskV1061=function(hid,typeId,date){
 const tp=D.taskTypes.find(x=>x.id===typeId),cycle=activeCycle(hid,date);
 const stocks=(D.stock||[]).filter(s=>s.active!==false&&!s.archived&&(+s.qty||0)>0);
 showEditModal(`＋ วางแผนงาน • ${date}`,`<div class="form">
 <div><label>โรงเรือน</label><input value="${esc(hname(hid))}" disabled></div><div><label>ประเภทงาน</label><input value="${esc(tp?.name||'-')}" disabled></div>
 <div class="span2"><label>รายละเอียดงาน</label><input id="m61action" value="${esc(tp?.name||'')}"></div>
 <div><label>ผู้รับผิดชอบ</label><select id="m61owner">${ownerOptions()}</select></div><div><label>Crop Cycle</label><input value="${esc(cycle?.crop||'งานทั่วไป')}" disabled></div>
 <div><label>วัตถุดิบ / Lot</label><select id="m61stock"><option value="">-- ไม่กำหนด --</option>${stocks.map(s=>`<option value="${s.id}">${esc(s.name)} • Lot ${esc(s.lot||'-')} • คงเหลือ ${+s.qty||0} ${esc(s.unit||'')}</option>`).join('')}</select></div>
 <div><label>ปริมาณที่วางแผนใช้</label><input id="m61qty" type="number" min="0" step=".01" value="0"></div>
 <div class="span2"><label>หมายเหตุ</label><textarea id="m61note" rows="2"></textarea></div></div>`,()=>{
   const action=document.getElementById('m61action').value.trim();if(!action)return alert('กรุณากรอกรายละเอียดงาน');
   const sid=document.getElementById('m61stock').value,s=D.stock.find(x=>x.id===sid),qty=+document.getElementById('m61qty').value||0;
   const t={id:id(),cycleId:cycle?.id||'',date,houseId:hid,typeId,type:tp?.name||'',action,ownerId:document.getElementById('m61owner').value,owner:'',knowledgeId:'',note:document.getElementById('m61note').value.trim(),status:'Pending',actualDate:'',actualRemark:'',actualPhoto:'',plannedStockId:sid,plannedMaterial:s?.name||'',plannedLot:s?.lot||'',plannedQty:qty,plannedUnit:s?.unit||''};
   D.tasks.push(t);sv('tasks');logAudit('CREATE','Task',t.id,`${hname(hid)} • ${date} • ${t.type}`);closeEditModal();plan30();
 });
};

window.printMonthlyV1061=function(){
 const ym=document.getElementById('p30month')?.value||window.p30Month||today().slice(0,7);
 const tasks=(D.tasks||[]).filter(t=>(t.date||'').startsWith(ym)).sort((a,b)=>(a.houseId+a.date).localeCompare(b.houseId+b.date));
 const houses=(D.houses||[]).filter(h=>tasks.some(t=>t.houseId===h.id));
 const mat=t=>{
   const actual=(D.usages||[]).filter(u=>u.taskId===t.id);
   if(actual.length)return actual.map(u=>`${esc(u.item||'-')} • Lot ${esc(u.lot||'-')} • ${+u.qty||0} ${esc(u.unit||'')}`).join('<br>');
   return t.plannedMaterial?`${esc(t.plannedMaterial)} • Lot ${esc(t.plannedLot||'-')} • ${+t.plannedQty||0} ${esc(t.plannedUnit||'')}`:'-';
 };
 const html=`<!doctype html><html><head><meta charset="utf-8"><title>แผนรายเดือน ${ym}</title><style>
 @page{size:A4 landscape;margin:9mm}body{font-family:Arial,"Noto Sans Thai",sans-serif;color:#18362d;font-size:10px}h1{margin:0 0 4px}h2{background:#edf6f1;padding:7px;margin:14px 0 6px;page-break-after:avoid}table{width:100%;border-collapse:collapse;margin-bottom:10px}th,td{border:1px solid #cfdcd6;padding:5px;vertical-align:top}th{background:#f2f6f4}.note{max-width:180px}.house{page-break-inside:avoid}.meta{color:#667a72;margin-bottom:10px}</style></head><body>
 <h1>DinDee Farm Organic Chonburi — แผนรายเดือน</h1><div class="meta">เดือน ${esc(ym)} • พิมพ์ ${new Date().toLocaleString('th-TH')}</div>
 ${houses.map(h=>`<section class="house"><h2>🏡 ${esc(h.name)}</h2><table><tr><th>วันที่</th><th>ประเภทงาน</th><th>รายละเอียดงาน</th><th>วัตถุดิบ / Lot</th><th>ปริมาณ</th><th>ผู้รับผิดชอบ</th><th>หมายเหตุ</th><th>สถานะ</th></tr>
 ${tasks.filter(t=>t.houseId===h.id).map(t=>{const actual=(D.usages||[]).filter(u=>u.taskId===t.id),qty=actual.length?actual.map(u=>`${+u.qty||0} ${esc(u.unit||'')}`).join('<br>'):(t.plannedMaterial?`${+t.plannedQty||0} ${esc(t.plannedUnit||'')}`:'-');const owner=t.owner||((D.responsibles||[]).find(x=>x.id===t.ownerId)||{}).name||'-';return `<tr><td>${esc(t.date||'-')}</td><td>${esc(t.type||'-')}</td><td>${esc(t.action||'-')}</td><td>${mat(t)}</td><td>${qty}</td><td>${esc(owner)}</td><td class="note">${esc(t.actualRemark||t.note||'-')}</td><td>${esc(t.status==='Done'?'ทำแล้ว':t.status==='Problem'||t.status==='Issue'?'มีปัญหา':t.status==='Postponed'?'เลื่อนงาน':'รอดำเนินการ')}</td></tr>`}).join('')||'<tr><td colspan="8">ไม่มีงาน</td></tr>'}</table></section>`).join('')||'<p>ยังไม่มีงานในเดือนนี้</p>'}
 </body></html>`;
 const w=window.open('','_blank');if(!w)return alert('Browser บล็อกหน้าต่างพิมพ์ กรุณาอนุญาต Pop-up');
 w.document.write(html);w.document.close();w.focus();setTimeout(()=>w.print(),250);
};
})();
