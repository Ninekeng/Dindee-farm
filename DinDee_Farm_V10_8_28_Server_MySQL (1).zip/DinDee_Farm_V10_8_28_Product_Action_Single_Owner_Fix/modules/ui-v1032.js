'use strict';
(function(){
 const PAGE_NAMES={
  dashboard:'ภาพรวมฟาร์ม', today:'งานวันนี้', alerts:'การแจ้งเตือน',
  year:'แผนการผลิตประจำปี', plan30:'แผนรายเดือน', cycles:'รอบการผลิต',
  harvest:'บันทึกผลผลิต', houses:'โรงเรือนและพื้นที่', knowledge:'องค์ความรู้',
  stock:'คลังสินค้า (Stock)', purchase:'ซื้อวัตถุดิบ', usage:'เบิกใช้วัตถุดิบ',
  shopadmin:'จัดการร้านค้าฟาร์ม', orders:'คำสั่งซื้อ', customers:'ฐานข้อมูลลูกค้า', salesDocs:'เอกสารขาย',
  shop:'ร้านค้าฟาร์ม', track:'ติดตามคำสั่งซื้อ', live:'กล้องฟาร์ม',
  finance:'รายรับ–รายจ่าย', directcost:'ต้นทุนทางตรง', sponsor:'เงินสนับสนุน',
  reportCenter:'ศูนย์รายงาน', salesReport:'รายงานการขาย',
  houseReport:'รายงานโรงเรือน', auditPage:'ประวัติการเปลี่ยนแปลง',
  evidence:'หลักฐานและเอกสาร',
  settings:'ตั้งค่าระบบ', categoryTags:'หมวดหมู่และแท็ก',
  importExportCenter:'นำเข้า / ส่งออกข้อมูล', exportPage:'สำรอง / กู้คืนข้อมูล',
  users:'ผู้ใช้งานและสิทธิ์'
 };
 const GROUP_NAMES={
  dashboard:'ภาพรวม',today:'ภาพรวม',alerts:'ภาพรวม',
  year:'การผลิต',plan30:'การผลิต',cycles:'การผลิต',harvest:'การผลิต',houses:'การผลิต',knowledge:'การผลิต',
  stock:'คลังสินค้าและจัดซื้อ',purchase:'คลังสินค้าและจัดซื้อ',usage:'คลังสินค้าและจัดซื้อ',
  shopadmin:'การขาย',orders:'การขาย',customers:'การขาย',salesDocs:'การขาย',shop:'การขาย',track:'การขาย',live:'การขาย',
  finance:'การเงิน',directcost:'การเงิน',sponsor:'การเงิน',
  reportCenter:'รายงาน',salesReport:'รายงาน',houseReport:'รายงาน',auditPage:'รายงาน',evidence:'รายงาน',
  settings:'ระบบ',categoryTags:'ระบบ',importExportCenter:'ระบบ',exportPage:'ระบบ',users:'ระบบ'
 };
 window.DinDeePageNames=PAGE_NAMES;

 function standardizeNavigation(){
   document.querySelectorAll('#menu .nav').forEach(btn=>{
     const m=(btn.getAttribute('onclick')||'').match(/go\('([^']+)'\)/);
     if(m && PAGE_NAMES[m[1]]) btn.textContent=PAGE_NAMES[m[1]];
   });
   document.querySelectorAll('.vsub h3').forEach(h=>{
     const g=GROUP_NAMES[window.page]||'DinDee Farm';
     h.textContent=g;
   });
 }
 function decoratePage(){
   const name=PAGE_NAMES[window.page]||'DinDee Farm';
   const group=GROUP_NAMES[window.page]||'ระบบฟาร์ม';
   const t=document.getElementById('title');
   if(t) t.textContent=name;
   document.title=name+' | DinDee Farm';
   standardizeNavigation();

   const top=document.querySelector('.top');
   if(top){
     const left=top.firstElementChild;
     if(left){
       let bc=left.querySelector('.pro-breadcrumb');
       if(!bc){bc=document.createElement('div');bc.className='pro-breadcrumb';left.insertBefore(bc,left.firstChild)}
       bc.textContent=`DinDee Farm  /  ${group}`;
       let sub=left.querySelector('.small');
       if(sub) sub.textContent='Smart Farm Management System';
     }
     const right=top.lastElementChild;
     if(right && !right.classList.contains('top-actions')) right.classList.add('top-actions');
   }

   const main=document.getElementById('content');
   if(main){
     main.querySelectorAll('table').forEach(x=>x.classList.add('pro-table'));
     main.querySelectorAll('.card').forEach(x=>x.classList.add('pro-card'));
   }
 }
 const oldRender=window.render;
 window.render=function(){
   oldRender();
   decoratePage();
 };
 window.addEventListener('load',()=>decoratePage());
})();