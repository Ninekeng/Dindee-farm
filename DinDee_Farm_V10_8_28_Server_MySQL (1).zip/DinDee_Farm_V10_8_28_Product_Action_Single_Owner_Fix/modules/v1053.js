/* DinDee Farm V10.5.3 - Delete buttons inside Edit dialogs */
(function(){
'use strict';
function admin(){
  // app.js declares `me` with top-level `let`; it is not window.me.
  try{return typeof me!=='undefined' && !!me && me.role==='Admin'}catch(e){return false}
}
function addDeleteButton(label, handler){
  if(!admin()) return;
  const actions=document.querySelector('#editModal .modalactions');
  if(!actions) return;
  actions.querySelectorAll('.v1053-modal-delete').forEach(x=>x.remove());
  const b=document.createElement('button');
  b.type='button'; b.className='btn2 dangerBtn v1053-modal-delete';
  b.textContent=label||'🗑️ ลบ';
  b.onclick=function(){ handler(); };
  actions.insertBefore(b, actions.firstElementChild);
}
function clearDeleteButton(){document.querySelectorAll('#editModal .v1053-modal-delete').forEach(x=>x.remove())}

// Always clear a previous record's delete action whenever a generic edit dialog opens.
const baseShow=window.showEditModal;
window.showEditModal=function(title,html,onSave){
  baseShow(title,html,onSave); clearDeleteButton();
};

function wrapEdit(name, deleter){
  const old=window[name]; if(typeof old!=='function') return;
  window[name]=function(recordId){
    const r=old.apply(this,arguments);
    if(recordId && admin()) addDeleteButton('🗑️ ลบ',function(){
      closeEditModal();
      if(typeof window[deleter]==='function') window[deleter](recordId);
      else alert('ไม่พบฟังก์ชันลบ '+deleter);
    });
    return r;
  };
}

// Crop Cycle / รอบการผลิต
wrapEdit('editPlan','deletePlan');
// Stock: cover every edit entry point used by old/new screens
wrapEdit('editStock','deleteStockV1052');
wrapEdit('editStockV101','deleteStockV1052');
wrapEdit('editStockV1043','deleteStockV1052');
// House / Area
wrapEdit('editHouseV101','deleteHouseV1051');
// Farm Shop
wrapEdit('editProduct','deleteProductV1052');
// Sales document (new document has no id, so no delete button)
wrapEdit('editSalesDoc','deleteSalesDocV1051');
// Sponsor Fund
wrapEdit('editFund','deleteFundV1051');

// Defensive UI pass: keep list-page actions visible too.
function addRowDelete(editPrefix, deleteFn, cls){
 document.querySelectorAll('#content button[onclick^="'+editPrefix+'"]').forEach(function(b){
   const td=b.closest('td'); if(!td||td.querySelector('.'+cls)) return;
   const m=(b.getAttribute('onclick')||'').match(/\('([^']+)'\)/); if(!m)return;
   const d=document.createElement('button'); d.className='btn2 dangerBtn '+cls; d.textContent='🗑️ ลบ';
   d.setAttribute('onclick',deleteFn+"('"+m[1]+"')"); td.append(' ',d);
 });
}
const oldRender=window.render;
window.render=function(){
 const r=oldRender.apply(this,arguments);
 setTimeout(function(){
   if(!admin())return;
   addRowDelete('editPlan(', 'deletePlan','v1053-row-cycle');
   addRowDelete('editStockV1043(', 'deleteStockV1052','v1053-row-stock');
   addRowDelete('editStockV101(', 'deleteStockV1052','v1053-row-stock');
   addRowDelete('editHouseV101(', 'deleteHouseV1051','v1053-row-house');
   addRowDelete('editProduct(', 'deleteProductV1052','v1053-row-product');
   addRowDelete('editSalesDoc(', 'deleteSalesDocV1051','v1053-row-sales');
   addRowDelete('editFund(', 'deleteFundV1051','v1053-row-fund');
 },0);
 return r;
};
})();
