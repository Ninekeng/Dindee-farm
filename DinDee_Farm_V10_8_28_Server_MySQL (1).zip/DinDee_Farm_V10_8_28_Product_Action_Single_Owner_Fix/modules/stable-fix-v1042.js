'use strict';
(function(){
  /* V10.4.2 Stable Fix: keep old data/route names, repair only verified regressions. */
  const activeShopCats=()=>D.shopCategories.filter(x=>x.active!==false).sort((a,b)=>(a.sort||0)-(b.sort||0));
  const categoryOptions=selected=>activeShopCats().map(c=>`<option value="${c.id}" ${c.id===selected?'selected':''}>${esc(c.name)}</option>`).join('');

  function normalizeProductCategory(p){
    if(p.categoryId && D.shopCategories.some(c=>c.id===p.categoryId)) return p.categoryId;
    const old=(p.category||'').trim().toLowerCase();
    let c=D.shopCategories.find(x=>(x.name||'').trim().toLowerCase()===old);
    if(!c && old){
      c={id:'cat-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,5),name:p.category.trim(),active:true,sort:D.shopCategories.length+1};
      D.shopCategories.push(c); sv('shopCategories');
    }
    if(!c)c=D.shopCategories.find(x=>x.id==='cat-other')||activeShopCats()[0];
    if(c){p.categoryId=c.id;p.category=c.name;sv('products');return c.id}
    return '';
  }
  D.products.forEach(normalizeProductCategory);

  /* Repair: Today -> Done button was calling missing doneTask(). */
  window.doneTask=function(taskId){
    const t=D.tasks.find(x=>x.id===taskId); if(!t)return alert('ไม่พบงานนี้');
    showEditModal('บันทึกผลการทำงาน',`<div class="form">
      <div><label>สถานะ</label><select id="dtStatus"><option value="Done">✓ เสร็จแล้ว</option><option value="Issue">⚠ พบปัญหา</option><option value="Postponed">↪ เลื่อนงาน</option></select></div>
      <div><label>วันที่ทำจริง / วันที่บันทึก</label><input id="dtDate" type="date" value="${today()}"></div>
      <div><label>ผู้ปฏิบัติงาน</label><select id="dtOwner">${responsibleOptions(t.ownerId||'')}</select></div>
      <div><label>เลื่อนไปวันที่ (ใช้เมื่อเลือก “เลื่อนงาน”)</label><input id="dtNext" type="date" value="${t.date||today()}"></div>
      <div class="span2"><label>รายละเอียด / ผลการทำงาน</label><textarea id="dtRemark" rows="3" placeholder="บันทึกสิ่งที่ทำจริง หรือปัญหาที่พบ">${esc(t.actualRemark||'')}</textarea></div>
      <div class="span2"><label>รูปหลักฐาน (ไม่บังคับ)</label><input id="dtPhoto" type="file" accept="image/*"></div>
    </div>`,()=>{
      const status=dtStatus.value, save=(photo)=>{
        t.ownerId=dtOwner.value||t.ownerId||'';
        t.actualDate=dtDate.value||today();
        t.actualRemark=dtRemark.value.trim();
        if(photo)t.actualPhoto=photo;
        if(status==='Done')t.status='Done';
        else if(status==='Issue')t.status='Issue';
        else { if(!dtNext.value)return alert('กรุณาเลือกวันที่ใหม่'); t.status='Pending'; t.date=dtNext.value; t.postponedAt=t.actualDate; }
        sv('tasks');logAudit('UPDATE','Task',t.id,`${t.action} → ${status}`);closeEditModal();todayPage();
      };
      const f=dtPhoto.files?.[0]; if(f)fileData(f,save); else save('');
    });
  };

  /* Repair: product edit category must use the same master as customer shop. */
  window.editProduct=function(productId){
    const p=D.products.find(x=>x.id===productId); if(!p)return alert('ไม่พบสินค้า');
    const selected=normalizeProductCategory(p);
    showEditModal('แก้ไขสินค้า',`<div class="form">
      <div><label>ชื่อสินค้า</label><input id="epn" value="${esc(p.name||'')}"></div>
      <div><label>SKU</label><input id="epsku" value="${esc(p.sku||'')}"></div>
      <div><label>หมวดหมู่สินค้า</label><select id="epcat">${categoryOptions(selected)}</select><div class="small">ใช้ Master เดียวกับหมวดหมู่ที่ลูกค้าเห็นในร้านค้า</div></div>
      <div><label>ราคา</label><input id="epp" type="number" min="0" step=".01" value="${+p.price||0}"></div>
      <div><label>จำนวนพร้อมขาย</label><input id="epq" type="number" min="0" step=".01" value="${+p.qty||0}"></div>
      <div><label>หน่วย</label><select id="epu">${unitOptions(p.unit||'')}</select></div>
      <div><label>สถานะ</label><select id="eps"><option ${p.status==='พร้อมขาย'?'selected':''}>พร้อมขาย</option><option ${p.status==='เปิดจองล่วงหน้า'?'selected':''}>เปิดจองล่วงหน้า</option><option ${p.status==='ปิดขาย'?'selected':''}>ปิดขาย</option></select></div>
      <div><label>เปลี่ยนรูปสินค้า</label><input id="epimg" type="file" accept="image/*"><div class="small">ไม่เลือกรูป = ใช้รูปเดิม</div></div>
    </div>`,()=>{
      if(!epn.value.trim())return alert('กรุณากรอกชื่อสินค้า');
      const c=D.shopCategories.find(x=>x.id===epcat.value); if(!c)return alert('กรุณาเลือกหมวดหมู่');
      const commit=img=>{p.name=epn.value.trim();p.sku=epsku.value.trim();p.categoryId=c.id;p.category=c.name;p.price=+epp.value||0;p.qty=+epq.value||0;p.unit=epu.value;p.status=eps.value;if(img)p.img=img;sv('products');logAudit('EDIT','Farm Shop',p.id,p.name);closeEditModal();shopadmin()};
      const f=epimg.files?.[0];if(f)fileData(f,commit);else commit('');
    });
  };

  window.manageShopCats=function(){
    const rows=D.shopCategories.slice().sort((a,b)=>(a.sort||0)-(b.sort||0));
    showEditModal('หมวดหมู่สินค้า',`<div class="helpbox">หมวดหมู่นี้เป็น Master ชุดเดียวกันทั้งหน้า Admin และร้านค้าที่ลูกค้าเห็น</div><div class="taskList">${rows.map(c=>`<div class="taskLine"><b>${esc(c.name)}</b><span><button type="button" class="btn2" onclick="toggleShopCatV1042('${c.id}')">${c.active!==false?'ปิดใช้งาน':'เปิดใช้งาน'}</button></span></div>`).join('')}</div><div class="form"><div class="span2"><label>เพิ่มหมวดใหม่</label><input id="newShopCat" placeholder="ชื่อหมวดหมู่"></div></div>`,()=>{let n=newShopCat.value.trim();if(n){if(D.shopCategories.some(c=>(c.name||'').trim().toLowerCase()===n.toLowerCase()))return alert('มีหมวดหมู่นี้อยู่แล้ว');D.shopCategories.push({id:'cat-'+Date.now().toString(36),name:n,active:true,sort:D.shopCategories.length+1});sv('shopCategories')}closeEditModal();shopadmin()});
  };
  window.toggleShopCatV1042=function(catId){const c=D.shopCategories.find(x=>x.id===catId);if(!c)return;c.active=c.active===false?true:false;sv('shopCategories');closeEditModal();manageShopCats()};
})();
