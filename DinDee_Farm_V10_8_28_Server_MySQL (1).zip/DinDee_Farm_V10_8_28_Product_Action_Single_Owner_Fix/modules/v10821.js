/* DinDee Farm V10.8.21 — Flow 5 Reports integration */
(function(){
'use strict';
const arr=x=>Array.isArray(x)?x:[];
const date10=v=>String(v||'').slice(0,10);
const orderPaid=o=>!!(o&&(o.cashReceived||arr(D.income).some(x=>x.source==='Farm Shop'&&x.refId===o.id)||['Confirmed','Preparing','Packed','Shipping','Completed'].includes(o.status)));
function seqRef(prefix,list,id){let n=Math.max(0,arr(list).findIndex(x=>x.id===id))+1;return prefix+'-'+String(n||1).padStart(4,'0')}
window.friendlyRefV10821=function(source,refId,row){
 if(source==='Farm Shop'){let o=arr(D.orders).find(x=>x.id===refId);return o?.no?`Order ${o.no}`:'Order'}
 if(source==='Purchase')return seqRef('PUR',D.purchases,refId);
 if(source==='Manual'||source==='Import')return seqRef(row?.type==='income'?'INC':'EXP',row?.type==='income'?D.income:D.expenses,row?.id);
 return refId?String(refId).slice(0,12):'-';
};
function orderLines(o){let ls=arr(o.items);if(ls.length)return ls.map(i=>{let p=arr(D.products).find(x=>x.id===i.productId);return {name:i.name||p?.name||'-',qty:+i.qty||0,price:+(i.price??p?.price)||0,productId:i.productId}});let p=arr(D.products).find(x=>x.id===o.productId);return o.productId?[{name:p?.name||'-',qty:+o.qty||1,price:+(o.price??p?.price)||0,productId:o.productId}]:[]}
function group(pairs){return Object.entries(pairs.reduce((a,[k,v])=>{k=k||'ไม่ระบุ';a[k]=(a[k]||0)+(+v||0);return a},{})).sort((a,b)=>b[1]-a[1])}
window.salesReport=function(){
 let S=window.srS||today().slice(0,7)+'-01',E=window.srE||today();
 let orders=arr(D.orders).filter(o=>{let d=date10(o.paidDate||o.date||o.created);return d>=S&&d<=E&&o.status!=='Cancelled'});
 let paidOrders=orders.filter(orderPaid),total=paidOrders.reduce((a,o)=>a+(+o.total||0),0),allTotal=orders.reduce((a,o)=>a+(+o.total||0),0),due=Math.max(0,allTotal-total);
 let products=group(paidOrders.flatMap(o=>orderLines(o).map(l=>[l.name,l.qty*l.price]))),staff=group(paidOrders.map(o=>[o.cashReceivedBy||o.salesperson||'ไม่ระบุ',o.total])),customers=group(paidOrders.map(o=>[o.customer||'ไม่ระบุ',o.total]));
 let docs=arr(D.salesDocs).filter(x=>date10(x.date)>=S&&date10(x.date)<=E&&x.status!=='Cancelled'&&['Billing','Invoice'].includes(x.type));
 content.innerHTML=`<div class="card"><h2>📊 รายงานการขาย</h2><p>เชื่อมข้อมูลจาก Farm Shop / Order โดยตรง รายการขายที่ชำระหรือยืนยันแล้วจะถูกรวมในยอดขาย</p><div class="form noPrint"><div><label>ตั้งแต่</label><input id="srs" type="date" value="${S}"></div><div><label>ถึง</label><input id="sre" type="date" value="${E}"></div></div><br><button class="btn noPrint" onclick="window.srS=srs.value;window.srE=sre.value;salesReport()">🔎 แสดงผล</button> <button class="btn2 noPrint" onclick="printCurrent()">🖨️ Print</button></div>
 <div class="kpiRow"><div class="kpiBox">ยอดขายที่รับรู้แล้ว<b>฿${money(total)}</b></div><div class="kpiBox">Orders ชำระ/ยืนยัน<b>${paidOrders.length}</b></div><div class="kpiBox">ยอด Order ที่ยังไม่รับรู้<b>฿${money(due)}</b></div><div class="kpiBox">Orders ทั้งหมด<b>${orders.length}</b></div></div>
 ${reportGroup('ยอดขายตามสินค้า',products)}${reportGroup('ยอดขายตามพนักงาน',staff)}${reportGroup('ยอดขายตามลูกค้า',customers)}
 <div class="card"><h3>🧾 รายการ Order ที่เชื่อมกับรายงาน</h3><div class="scroll"><table><tr><th>วันที่</th><th>เลขอ้างอิง</th><th>ลูกค้า</th><th>สินค้า</th><th>ยอด</th><th>สถานะ</th></tr>${orders.map(o=>`<tr><td>${esc(date10(o.paidDate||o.date||o.created)||'-')}</td><td><b>${esc(o.no||'-')}</b></td><td>${esc(o.customer||'-')}</td><td>${orderLines(o).map(l=>`${esc(l.name)} × ${l.qty}`).join('<br>')||'-'}</td><td>฿${money(o.total)}</td><td>${esc(o.status||'-')}</td></tr>`).join('')||'<tr><td colspan="6">ไม่มีข้อมูล</td></tr>'}</table></div></div>
 <div class="card"><h3>ใบวางบิล / การเรียกเก็บเงิน</h3><div class="scroll"><table><tr><th>เลขที่</th><th>ลูกค้า</th><th>ครบกำหนด</th><th>ยอด</th><th>สถานะ</th></tr>${docs.map(x=>`<tr><td>${esc(x.no||'-')}</td><td>${esc(x.customer||'-')}</td><td>${esc(x.due||'-')}</td><td>฿${money(x.total)}</td><td>${esc(x.status||'-')}</td></tr>`).join('')||'<tr><td colspan="5">ไม่มีใบวางบิล/ใบแจ้งหนี้ในช่วงนี้</td></tr>'}</table></div></div>`;
};

/* Evidence Center: one searchable view over existing attachments, no duplicate accounting records. */
window.evidence=function(){
 let q=String(window.evQ10821||'').toLowerCase(),src=window.evSrc10821||'',from=window.evFrom10821||'',to=window.evTo10821||'';
 let rows=[];
 arr(D.purchases).filter(x=>x.evidence).forEach(x=>rows.push({date:x.date,type:'ใบเสร็จ/หลักฐานซื้อ',source:'Purchase',ref:friendlyRefV10821('Purchase',x.id),party:x.supplier||'',name:x.item||'',amount:+x.total||0,data:x.evidence,external:x.externalDocNo||''}));
 arr(D.costs).filter(x=>x.evidence).forEach(x=>rows.push({date:x.date,type:'หลักฐานต้นทุน',source:'Direct Cost',ref:seqRef('COST',D.costs,x.id),party:'',name:x.name||'',amount:+x.amount||+x.cost||0,data:x.evidence,external:x.externalDocNo||''}));
 arr(D.orders).filter(x=>x.slip).forEach(o=>rows.push({date:date10(o.paidDate||o.date||o.created),type:'สลิปชำระเงิน',source:'Farm Shop',ref:o.no||'Order',party:o.customer||'',name:orderLines(o).map(l=>l.name).join(', '),amount:+o.total||0,data:o.slip,external:o.externalDocNo||''}));
 rows=rows.filter(x=>(!from||x.date>=from)&&(!to||x.date<=to)&&(!src||x.source===src)&&(!q||[x.type,x.source,x.ref,x.party,x.name,x.external].join(' ').toLowerCase().includes(q))).sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 content.innerHTML=`<div class="card"><h3>📎 หลักฐาน / เอกสารแนบ</h3><p>ศูนย์ค้นหาใบเสร็จ สลิป และหลักฐานที่แนบจากรายการต้นทาง โดยไม่สร้างรายการบัญชีซ้ำ</p><div class="form noPrint"><div><label>ตั้งแต่</label><input id="evf" type="date" value="${from}"></div><div><label>ถึง</label><input id="evt" type="date" value="${to}"></div><div><label>แหล่งข้อมูล</label><select id="evs"><option value="">ทั้งหมด</option>${['Purchase','Farm Shop','Direct Cost'].map(x=>`<option ${src===x?'selected':''}>${x}</option>`).join('')}</select></div><div><label>ค้นหา</label><input id="evq" value="${esc(window.evQ10821||'')}" placeholder="รายการ / คู่ค้า / Order / เลขเอกสาร"></div></div><br><button class="btn" onclick="window.evFrom10821=evf.value;window.evTo10821=evt.value;window.evSrc10821=evs.value;window.evQ10821=evq.value;evidence()">🔎 ค้นหา</button> <button class="btn2" onclick="window.evFrom10821=window.evTo10821=window.evSrc10821=window.evQ10821='';evidence()">ล้าง Filter</button></div>
 <div class="card scroll"><table><tr><th>วันที่</th><th>ประเภท</th><th>เลขอ้างอิง</th><th>แหล่งข้อมูล</th><th>รายการ / คู่ค้า</th><th>จำนวนเงิน</th><th>ไฟล์</th></tr>${rows.map(x=>`<tr><td>${esc(x.date||'-')}</td><td>${esc(x.type)}</td><td><b>${esc(x.ref)}</b>${x.external?`<br><span class="small">เอกสาร: ${esc(x.external)}</span>`:''}</td><td>${esc(x.source)}</td><td>${esc(x.name||'-')}${x.party?`<br><span class="small">${esc(x.party)}</span>`:''}</td><td>฿${money(x.amount)}</td><td><button class="btn2" onclick="previewEvidenceV10821('${encodeURIComponent(x.data)}')">👁️ Preview</button></td></tr>`).join('')||'<tr><td colspan="7">ยังไม่มีหลักฐานตามเงื่อนไข</td></tr>'}</table></div>`;
};
window.previewEvidenceV10821=function(encoded){let u=decodeURIComponent(encoded||'');showEditModal('👁️ ดูหลักฐาน',`<div style="text-align:center"><img src="${u}" alt="หลักฐาน" style="max-width:100%;max-height:70vh;object-fit:contain"><div style="margin-top:12px"><a class="btn2" href="${u}" target="_blank">เปิดไฟล์ต้นฉบับ</a></div></div>`,null)};

/* Improve house report linkage only from explicit source links; never invent/manual duplicate revenue. */
const oldHouse=window.houseReport;
window.houseReport=function(){oldHouse();let first=document.querySelector('#content .card h2');if(first){let p=document.createElement('p');p.className='small';p.innerHTML='รายได้เชื่อมจากรายการ Income ที่ระบุ <b>Cycle/โรงเรือน</b> และต้นทุนเชื่อมจาก Stock Usage ของ Cycle/โรงเรือนโดยอัตโนมัติ หากยังเป็น ฿0 แปลว่ารายการขาย/ต้นทุนต้นทางยังไม่มีการผูกกับ Cycle หรือโรงเรือน — ไม่ต้องกรอกยอดซ้ำในรายงาน';first.parentNode.appendChild(p)}};
})();
