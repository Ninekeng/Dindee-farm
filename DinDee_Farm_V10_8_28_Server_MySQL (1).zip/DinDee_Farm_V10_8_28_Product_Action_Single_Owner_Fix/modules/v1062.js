/* DinDee Farm V10.6.2 - Monthly date headers + Customer History */
(function(){
'use strict';
const pad=n=>String(n).padStart(2,'0');
const days=ym=>{const [y,m]=ym.split('-').map(Number),last=new Date(y,m,0).getDate();return Array.from({length:last},(_,i)=>`${y}-${pad(m)}-${pad(i+1)}`)};
const hn=id=>(D.houses.find(h=>h.id===id)||{}).name||'-';
const tstate=t=>t.status==='Done'?'done':(['Issue','Problem'].includes(t.status)?'issue':t.status==='Postponed'?'postponed':'planned');
const tmark=t=>tstate(t)==='done'?'✓':tstate(t)==='issue'?'!':tstate(t)==='postponed'?'↷':'●';

/* Monthly matrix: repeat day header for every greenhouse and keep top header sticky. */
const draw61=window.drawMonthlyMatrixV1061;
window.drawMonthlyMatrixV1061=function(){
 const ym=document.getElementById('p30month')?.value||window.p30Month||today().slice(0,7),ds=days(ym),types=(D.taskTypes||[]).filter(x=>x.active!==false),houses=(D.houses||[]).filter(h=>h.active!==false);
 const [yy,mm]=ym.split('-').map(Number),monthLabel=new Intl.DateTimeFormat('th-TH',{month:'long',year:'numeric'}).format(new Date(yy,mm-1,1));
 const dayHeads=()=>ds.map(d=>{const dt=new Date(d+'T00:00:00'),wd=['อา','จ','อ','พ','พฤ','ศ','ส'][dt.getDay()];return `<th class="day-head"><small>${wd}</small><b>${+d.slice(8)}</b></th>`}).join('');
 p30area.innerHTML=`<div class="card monthly-matrix-card">
 <div class="monthly-scroll-hint"><b>📅 ${esc(monthLabel)}</b><span>↔ เลื่อนแถบด้านล่างเพื่อดูวันที่ทั้งเดือน</span></div>
 <div class="monthly-matrix-wrap"><table class="monthly-matrix"><thead class="month-sticky-head"><tr><th class="sticky-name">โรงเรือน / ประเภทงาน</th>${dayHeads()}</tr></thead><tbody>
 ${houses.map(h=>`<tr class="house-row"><td colspan="${ds.length+1}"><span class="house-month-title">🏡 <b>${esc(h.name)}</b><strong>📅 ${esc(monthLabel)}</strong></span></td></tr>
 <tr class="house-day-row"><th class="sticky-name">วันที่</th>${dayHeads()}</tr>
 ${types.map(tp=>`<tr><td class="sticky-name tasktype-name">↳ ${esc(tp.name)}</td>${ds.map(d=>{const ts=(D.tasks||[]).filter(t=>t.houseId===h.id&&t.date===d&&(t.typeId===tp.id||(!t.typeId&&t.type===tp.name)));return `<td class="matrix-cell ${ts.length?'has-task':''}" onclick="monthlyCellV1061('${h.id}','${tp.id}','${d}')">${ts.map(t=>`<span class="matrix-mark ${tstate(t)}" title="${esc(t.action||tp.name)}">${tmark(t)}</span>`).join('')||'<span class="matrix-empty">＋</span>'}</td>`}).join('')}</tr>`).join('')}`).join('')||`<tr><td colspan="${ds.length+1}">ยังไม่มีโรงเรือนหรือประเภทงานที่เปิดใช้งาน</td></tr>`}
 </tbody></table></div></div>`;
};

/* Customer master is already D.customers. Normalize old orders into it non-destructively. */
function syncCustomersV1062(){
 D.customers=D.customers||[];let changed=false;
 (D.orders||[]).forEach(o=>{
  const phone=String(o.phone||'').replace(/\D/g,'');if(!phone&&!o.customer)return;
  let c=(o.customerId&&D.customers.find(x=>x.id===o.customerId))||(phone&&D.customers.find(x=>String(x.phone||'').replace(/\D/g,'')===phone));
  if(!c){c={id:id(),phone,name:o.customer||'',address:o.address||'',note:o.note||'',created:o.created||today(),active:true};D.customers.push(c);changed=true}
  else {if(!c.name&&o.customer){c.name=o.customer;changed=true}if(!c.address&&o.address){c.address=o.address;changed=true}}
  if(!o.customerId){o.customerId=c.id;changed=true}
 });
 if(changed){sv('customers');sv('orders')}
}
window.customerHistoryV1062=function(){
 syncCustomersV1062();
 const q=(window.customerQ1062||'').toLowerCase(),rows=D.customers.filter(c=>!q||[c.name,c.phone,c.address,c.note].join(' ').toLowerCase().includes(q));
 const stats=c=>{const os=D.orders.filter(o=>o.customerId===c.id||(!o.customerId&&String(o.phone||'').replace(/\D/g,'')===String(c.phone||'').replace(/\D/g,''))),valid=os.filter(o=>o.status!=='Rejected');return {os,count:valid.length,total:valid.reduce((a,o)=>a+(+o.total||0),0),last:valid.slice().sort((a,b)=>String(b.created||'').localeCompare(String(a.created||'')))[0]}};
 content.innerHTML=`<div class="pageHero"><div><span class="eyebrow">CUSTOMER HISTORY</span><h2>👥 ประวัติลูกค้า</h2><p>ข้อมูลลูกค้าและประวัติการซื้อจากคำสั่งซื้อทั้งหมด</p></div><div class="heroActions"><button class="btn2" onclick="orders()">← คำสั่งซื้อ</button><button class="btn" onclick="editCustomerV1062('')">＋ เพิ่มลูกค้า</button></div></div>
 <div class="customer-kpis"><div class="metric">ลูกค้าทั้งหมด<b>${D.customers.length}</b></div><div class="metric">ลูกค้าที่ใช้งาน<b>${D.customers.filter(x=>x.active!==false).length}</b></div><div class="metric">Order ทั้งหมด<b>${D.orders.length}</b></div></div>
 <div class="card customer-tools"><input placeholder="🔎 ค้นหาชื่อ / เบอร์โทร / ที่อยู่" value="${esc(window.customerQ1062||'')}" oninput="window.customerQ1062=this.value;customerHistoryV1062()"><span class="pill">${rows.length} ลูกค้า</span></div>
 <div class="card"><div class="tableWrap"><table class="customer-table"><tr><th>ลูกค้า</th><th>เบอร์โทร</th><th>จำนวนครั้ง</th><th>ยอดซื้อรวม</th><th>ซื้อล่าสุด</th><th>ที่อยู่ / หมายเหตุ</th><th>จัดการ</th></tr>
 ${rows.map(c=>{const s=stats(c);return `<tr><td><b>${esc(c.name||'-')}</b>${c.active===false?'<div class="muted">ปิดใช้งาน</div>':''}</td><td>${esc(c.phone||'-')}</td><td>${s.count}</td><td>฿${money(s.total)}</td><td>${esc(s.last?.created||'-')}</td><td><div class="customer-meta">${esc(c.address||'-')}</div>${c.note?`<div class="muted">${esc(c.note)}</div>`:''}</td><td class="action-cell"><button class="btn2" onclick="viewCustomerV1062('${c.id}')">👁️ ดู</button><button class="btn2" onclick="editCustomerV1062('${c.id}')">✏️ แก้ไข</button><button class="btn2 dangerBtn" onclick="deleteCustomerV1062('${c.id}')">🗑️ ลบ</button></td></tr>`}).join('')||'<tr><td colspan="7">ยังไม่มีข้อมูลลูกค้า</td></tr>'}</table></div></div>`;
};
window.viewCustomerV1062=function(cid){
 const c=D.customers.find(x=>x.id===cid);if(!c)return;
 const os=D.orders.filter(o=>o.customerId===cid||(!o.customerId&&String(o.phone||'').replace(/\D/g,'')===String(c.phone||'').replace(/\D/g,''))).slice().reverse();
 showEditModal(`👤 ${esc(c.name||'ลูกค้า')}`,`<div class="customer-detail"><div class="customer-summary"><div><small>โทรศัพท์</small><b>${esc(c.phone||'-')}</b></div><div><small>จำนวน Order</small><b>${os.length}</b></div><div><small>ยอดรวม</small><b>฿${money(os.filter(o=>o.status!=='Rejected').reduce((a,o)=>a+(+o.total||0),0))}</b></div></div><p><b>ที่อยู่:</b> ${esc(c.address||'-')}</p><p><b>หมายเหตุ:</b> ${esc(c.note||'-')}</p>
 <h3>ประวัติการซื้อ</h3><div class="tableWrap"><table><tr><th>Order</th><th>วันที่</th><th>สินค้า</th><th>ยอด</th><th>สถานะ</th></tr>${os.map(o=>`<tr><td>${esc(o.no||'-')}</td><td>${esc(o.created||'-')}</td><td>${(o.items||[]).map(i=>`${esc(i.name||'-')} × ${+i.qty||0}`).join('<br>')||'-'}</td><td>฿${money(o.total)}</td><td>${esc(o.status||'-')}</td></tr>`).join('')||'<tr><td colspan="5">ยังไม่มีประวัติการซื้อ</td></tr>'}</table></div></div>`,()=>closeEditModal());
};
window.editCustomerV1062=function(cid){
 const c=D.customers.find(x=>x.id===cid)||{id:'',name:'',phone:'',address:'',note:'',active:true};
 showEditModal(c.id?'✏️ แก้ไขลูกค้า':'＋ เพิ่มลูกค้า',`<div class="form"><div><label>ชื่อ-นามสกุล</label><input id="cu62name" value="${esc(c.name)}"></div><div><label>เบอร์โทร</label><input id="cu62phone" value="${esc(c.phone)}"></div><div class="span2"><label>ที่อยู่ / ข้อมูลจัดส่ง</label><textarea id="cu62addr">${esc(c.address)}</textarea></div><div class="span2"><label>หมายเหตุ</label><textarea id="cu62note">${esc(c.note)}</textarea></div><div><label>สถานะ</label><select id="cu62active"><option value="1" ${c.active!==false?'selected':''}>ใช้งาน</option><option value="0" ${c.active===false?'selected':''}>ปิดใช้งาน</option></select></div></div>`,()=>{
  const name=cu62name.value.trim(),phone=cu62phone.value.replace(/\D/g,'');if(!name||phone.length<9)return alert('กรุณากรอกชื่อและเบอร์โทรให้ถูกต้อง');
  const dup=D.customers.find(x=>x.id!==c.id&&String(x.phone||'').replace(/\D/g,'')===phone);if(dup)return alert(`เบอร์โทรนี้มีในระบบแล้ว: ${dup.name}`);
  if(c.id)Object.assign(c,{name,phone,address:cu62addr.value.trim(),note:cu62note.value.trim(),active:cu62active.value==='1'});
  else D.customers.push({id:id(),name,phone,address:cu62addr.value.trim(),note:cu62note.value.trim(),active:cu62active.value==='1',created:today()});
  sv('customers');logAudit(c.id?'EDIT':'CREATE','Customer',c.id||phone,name);closeEditModal();customerHistoryV1062();
 });
};
window.deleteCustomerV1062=function(cid){
 const c=D.customers.find(x=>x.id===cid);if(!c)return;const os=D.orders.filter(o=>o.customerId===cid);
 if(os.length){if(!confirm(`ลูกค้า “${c.name}” มีประวัติ Order ${os.length} รายการ\nเพื่อรักษาประวัติการขาย ระบบจะปิดใช้งานแทนการลบถาวร\n\nยืนยันหรือไม่?`))return;c.active=false;sv('customers');logAudit('DEACTIVATE','Customer',cid,c.name);customerHistoryV1062();return}
 if(!confirm(`ยืนยันลบลูกค้า “${c.name}” ?`))return;D.customers=D.customers.filter(x=>x.id!==cid);sv('customers');logAudit('DELETE','Customer',cid,c.name);customerHistoryV1062();
};

/* Keep customer master updated at checkout: old checkout already creates by phone; enrich address/note afterwards. */
const submit62=window.submitCheckoutV104;
window.submitCheckoutV104=function(qrType){
 const phone=document.getElementById('coPhone')?.value.replace(/\D/g,'')||'',name=document.getElementById('coName')?.value.trim()||'',address=document.getElementById('coAddress')?.value.trim()||'',note=document.getElementById('coNote')?.value.trim()||'';
 const before=new Set((D.orders||[]).map(o=>o.id));const r=submit62.apply(this,arguments);
 setTimeout(()=>{let c=D.customers.find(x=>String(x.phone||'').replace(/\D/g,'')===phone);if(c){c.name=name||c.name;c.address=address||c.address;c.note=note||c.note;c.active=c.active!==false;sv('customers')}let o=(D.orders||[]).find(x=>!before.has(x.id));if(o&&c&&!o.customerId){o.customerId=c.id;sv('orders')}},0);return r;
};

/* Add Customer History button to Order Management without replacing order workflow. */
const orders62=window.orders;
window.orders=function(){const r=orders62.apply(this,arguments);const hero=content.querySelector('.pageHero');if(hero&&!hero.querySelector('.customer-history-btn'))hero.insertAdjacentHTML('beforeend','<button class="btn customer-history-btn" onclick="customerHistoryV1062()">👥 ประวัติลูกค้า</button>');return r};
})();
