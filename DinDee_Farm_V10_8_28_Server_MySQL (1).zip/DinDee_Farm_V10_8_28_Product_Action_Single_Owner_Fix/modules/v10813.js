/* DinDee Farm V10.8.13 — direct Farm Shop cart flow (no delegated/capture click patch) */
(function(){
'use strict';
function items13(){
  const c=Array.isArray(window.cart)?window.cart:(window.cart=[]);
  for(let i=c.length-1;i>=0;i--){
    const x=c[i],p=D.products.find(z=>z.id===x.productId),q=Number(x.qty)||0,max=p?Math.max(0,Number(p.qty)||0):0;
    if(!p||q<=0||max<=0){c.splice(i,1);continue;}
    x.qty=Math.min(q,max);
  }
  return c.map(x=>({...x,p:D.products.find(p=>p.id===x.productId)})).filter(x=>x.p&&Number(x.qty)>0);
}
function count13(){return items13().reduce((s,x)=>s+(Number(x.qty)||0),0);}
function badge13(){document.querySelectorAll('.cart-count-v10813').forEach(x=>x.textContent=String(count13()));}
window.changeCartV10813=function(pid,delta){
  const c=window.cart||[],x=c.find(z=>z.productId===pid),p=D.products.find(z=>z.id===pid);if(!x||!p)return;
  const q=Math.min(Math.max(0,(Number(x.qty)||0)+(Number(delta)||0)),Math.max(0,Number(p.qty)||0));
  if(q<=0)c.splice(c.indexOf(x),1);else x.qty=q;
  window.openCartV10813();
};
window.openCartV10813=function(){
  const items=items13(),total=items.reduce((s,x)=>s+(Number(x.qty)||0)*(Number(x.p.price)||0),0);
  showEditModal('ตะกร้าสินค้า',`<div class="cartList">${items.map(x=>`<div class="cartLine"><div><b>${esc(x.p.name)}</b><small>฿${money(x.p.price)} / ${esc(x.p.unit)} · เหลือ ${x.p.qty}</small></div><div class="qtyStepper"><button type="button" onclick="changeCartV10813('${x.p.id}',-1)">−</button><b>${x.qty}</b><button type="button" onclick="changeCartV10813('${x.p.id}',1)">+</button></div><b>฿${money(x.qty*x.p.price)}</b></div>`).join('')||'<p>ยังไม่มีสินค้าในตะกร้า</p>'}</div><div class="checkoutTotal"><span>ยอดรวม</span><b>฿${money(total)}</b></div>`,function(){
    if(!items13().length){alert('ยังไม่มีสินค้าในตะกร้า');return;}
    closeEditModal();
    window.openCheckoutV1043();
  });
  const b=document.getElementById('emSave');if(b){b.textContent=items.length?'ดำเนินการสั่งซื้อ →':'ไม่มีสินค้า';b.disabled=!items.length;}
  badge13();
};
/* v10812 used a capture listener on .cartButton. Remove that class from the rendered
   button and give the button one direct, deterministic handler instead. */
const shop13=window.shop;
window.shop=function(){
  const r=shop13.apply(this,arguments),old=document.querySelector('#content .cartButton');
  if(old){
    old.classList.remove('cartButton');old.classList.add('cart-entry-v10813');
    old.setAttribute('onclick','openCartV10813()');
    old.innerHTML=`ตะกร้า <b class="cart-count-v10813">${count13()}</b>`;
  }
  return r;
};
})();
