/* DinDee Farm V10.8.0 — Work History Material Edit */
(function(){
'use strict';
const n=x=>Number(x)||0;
function availableLots(current){
 return (D.stock||[]).filter(s=>s.active!==false && (n(s.qty)>0 || s.id===current)).sort((a,b)=>(a.expiryDate||'9999').localeCompare(b.expiryDate||'9999'));
}
function usageLine(u){return `${esc(u.item||'-')} · Lot ${esc(u.lot||'-')} · ${n(u.qty)} ${esc(u.unit||'')}`}
window.editWorkMaterialsV1080=function(taskId){
 const t=D.tasks.find(x=>x.id===taskId);if(!t)return alert('ไม่พบงาน');
 const usages=(D.usages||[]).filter(u=>u.taskId===taskId);
 const rows=usages.map(u=>`<div class="taskLine"><div><b>${usageLine(u)}</b><small>${esc(u.note||'')}</small></div><button class="btn2 purchase-icon-btn" title="แก้ไขวัตถุดิบ" onclick="editWorkUsageV1080('${u.id}','${taskId}')">✏️</button></div>`).join('');
 showEditModal('🧪 วัตถุดิบที่ใช้จริง',`<div class="helpbox"><b>${esc(t.action||'งาน')}</b><br>แก้รายการที่ใช้จริง หรือเพิ่มวัตถุดิบย้อนหลัง ระบบจะปรับ Stock ให้สัมพันธ์กับประวัติงาน</div>
 <div class="taskList">${rows||'<div class="muted">งานนี้ยังไม่มีวัตถุดิบที่ใช้จริง</div>'}</div>
 <button type="button" class="btn2" onclick="addWorkUsageV1080('${taskId}')">＋ เพิ่มวัตถุดิบ</button>`,()=>closeEditModal());
};
window.editWorkUsageV1080=function(uid,taskId){
 const u=D.usages.find(x=>x.id===uid);if(!u)return;
 const lots=availableLots(u.stockId);
 showEditModal('✏️ แก้ไขวัตถุดิบที่ใช้จริง',`<div class="form">
 <div class="span2"><label>วัตถุดิบ / Lot</label><select id="v80stock">${lots.map(s=>`<option value="${s.id}" ${s.id===u.stockId?'selected':''}>${esc(s.name)} | Lot ${esc(s.lot||'-')} | คงเหลือ ${n(s.qty)} ${esc(s.unit||'')}</option>`).join('')}</select></div>
 <div><label>จำนวน</label><input id="v80qty" type="number" min="0.01" step=".01" value="${n(u.qty)}"></div>
 <div><label>วันที่ใช้</label><input id="v80date" type="date" value="${esc(u.date||today())}"></div>
 <div class="span2"><label>หมายเหตุ</label><input id="v80note" value="${esc(u.note||'')}"></div></div>
 <div class="helpbox">ถ้าเปลี่ยน Lot หรือจำนวน ระบบจะคืน Stock เดิมก่อน แล้วหักจาก Stock ใหม่ให้อัตโนมัติ</div>`,()=>{
   const oldStock=D.stock.find(s=>s.id===u.stockId),newStock=D.stock.find(s=>s.id===v80stock.value),q=n(v80qty.value);
   if(!newStock||q<=0)return alert('กรุณาเลือกวัตถุดิบและจำนวน');
   const available=n(newStock.qty)+(oldStock&&oldStock.id===newStock.id?n(u.qty):0);
   if(q>available)return alert(`Stock Lot นี้มีใช้ได้ ${available} ${newStock.unit||''}`);
   if(oldStock)oldStock.qty=n(oldStock.qty)+n(u.qty);
   newStock.qty=n(newStock.qty)-q;
   Object.assign(u,{stockId:newStock.id,item:newStock.name,lot:newStock.lot||'',qty:q,unit:newStock.unit||'',date:v80date.value||today(),houseId:tHouse(taskId),note:v80note.value});
   sv('stock');sv('usages');logAudit('EDIT','Work Material',u.id,`${u.item} Lot ${u.lot||'-'} ${q} ${u.unit||''}`);closeEditModal();workHistoryV1056();
 });
};
function tHouse(taskId){return (D.tasks.find(x=>x.id===taskId)||{}).houseId||''}
window.addWorkUsageV1080=function(taskId){
 const t=D.tasks.find(x=>x.id===taskId),lots=availableLots('');if(!t)return;
 if(!lots.length)return alert('ไม่มี Stock ที่สามารถเบิกได้');
 showEditModal('＋ เพิ่มวัตถุดิบที่ใช้จริง',`<div class="form">
 <div class="span2"><label>วัตถุดิบ / Lot</label><select id="v80astock">${lots.map(s=>`<option value="${s.id}">${esc(s.name)} | Lot ${esc(s.lot||'-')} | คงเหลือ ${n(s.qty)} ${esc(s.unit||'')}</option>`).join('')}</select></div>
 <div><label>จำนวน</label><input id="v80aqty" type="number" min="0.01" step=".01"></div>
 <div><label>วันที่ใช้</label><input id="v80adate" type="date" value="${esc(t.actualDate||t.date||today())}"></div>
 <div class="span2"><label>หมายเหตุ</label><input id="v80anote"></div></div>`,()=>{
   const s=D.stock.find(x=>x.id===v80astock.value),q=n(v80aqty.value);if(!s||q<=0)return alert('กรุณาเลือกวัตถุดิบและจำนวน');if(q>n(s.qty))return alert(`Stock Lot นี้เหลือ ${s.qty} ${s.unit||''}`);
   s.qty=n(s.qty)-q;const u={id:id(),date:v80adate.value||today(),taskId,houseId:t.houseId||'',stockId:s.id,item:s.name,lot:s.lot||'',qty:q,unit:s.unit||'',note:v80anote.value};
   D.usages.push(u);sv('stock');sv('usages');logAudit('CREATE','Work Material',u.id,`${u.item} Lot ${u.lot||'-'} ${q} ${u.unit||''}`);closeEditModal();workHistoryV1056();
 });
};
/* Extend the existing work-history table after its normal renderer runs. */
const oldFilter=window.filterWorkHistoryV1056;
window.filterWorkHistoryV1056=function(){
 oldFilter();
 const area=document.getElementById('whArea');if(!area)return;
 const table=area.querySelector('table');if(!table)return;
 const heads=table.querySelectorAll('tr:first-child th');const matHead=[...heads].find(x=>x.textContent.trim()==='วัตถุดิบ');if(matHead)matHead.textContent='วัตถุดิบ / Lot';
 const data=window._whData1056||[];let f=document.getElementById('whFrom')?.value||'',to=document.getElementById('whTo')?.value||'',h=document.getElementById('whHouse')?.value||'',c=document.getElementById('whCycle')?.value||'',st=document.getElementById('whStatus')?.value||'',q=(document.getElementById('whQ')?.value||'').toLowerCase();
 let a=data.filter(t=>{const d=t.actualDate||t.date||'',ownerText=t.owner||((D.responsibles||[]).find(x=>x.id===t.ownerId)||{}).name||'',house=(D.houses.find(x=>x.id===t.houseId)||{}).name||'',cycle=(D.yearPlans.find(x=>x.id===t.cycleId)||{}).crop||'',hay=[t.action,t.actualRemark,t.note,ownerText,house,cycle].join(' ').toLowerCase();return(!f||d>=f)&&(!to||d<=to)&&(!h||t.houseId===h)&&(!c||t.cycleId===c)&&(!st||t.status===st)&&(!q||hay.includes(q))});
 [...table.querySelectorAll('tr')].slice(1).forEach((tr,i)=>{const t=a[i];if(!t)return;const cells=tr.children;if(cells[6]){const us=(D.usages||[]).filter(x=>x.taskId===t.id);cells[6].innerHTML=`${us.map(usageLine).join('<br>')||'-'}<div class="noPrint"><button class="btn2 purchase-icon-btn" title="แก้ไขวัตถุดิบ" onclick="editWorkMaterialsV1080('${t.id}')">🧪✏️</button></div>`}});
};
})();
