/* DinDee Farm V10.6.0 - Annual Gantt action guard */
(function(){
'use strict';
function cleanAnnualDeleteV1060(){
 const annual=content?.querySelector?.('.annualCard');
 if(!annual)return;
 [...annual.querySelectorAll('button')].forEach(b=>{
   const oc=b.getAttribute('onclick')||'',tx=(b.textContent||'').trim();
   if(oc.includes('deletePlan')||tx.includes('ลบ'))b.remove();
 });
}
const render1060=window.render;
window.render=function(){const r=render1060.apply(this,arguments);cleanAnnualDeleteV1060();setTimeout(cleanAnnualDeleteV1060,0);return r};
const year1060=window.year;
window.year=function(){const r=year1060.apply(this,arguments);cleanAnnualDeleteV1060();setTimeout(cleanAnnualDeleteV1060,0);return r};
})();
