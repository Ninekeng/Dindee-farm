'use strict';
/* DinDee Farm V10.4.5 — Deep Farm Analytics + Knowledge CRUD.
   Uses existing data stores only; no storage keys or routes are renamed. */
(function(){
  const num=v=>+v||0;
  const inPeriod=(x,S,E)=>(x.date||x.actualDate||x.createdDate||'')>=S&&(x.date||x.actualDate||x.createdDate||'')<=E;
  const realExpenses=()=>D.expenses.filter(e=>e.source!=='Purchase');
  const expenses=(S,E)=>[...realExpenses(),...D.purchases.map(x=>({...x,amount:x.total||0})),...D.costs].filter(x=>inPeriod(x,S,E));
  const fmtPct=(a,b)=>b?((a-b)/b*100):null;
  const cycleOf=x=>D.yearPlans.find(p=>p.id===x.cycleId);
  const houseName=id=>D.houses.find(h=>h.id===id)?.name||'-';
  const orderDate=o=>o.date||o.completedDate||o.createdDate||'';

  function houseRows(S,E){
    return D.houses.filter(h=>h.active!==false).map(h=>{
      const cycles=D.yearPlans.filter(p=>p.houseId===h.id), ids=cycles.map(p=>p.id);
      const uses=D.usages.filter(x=>inPeriod(x,S,E)&&(x.houseId===h.id||ids.includes(x.cycleId)));
      const direct=D.costs.filter(x=>inPeriod(x,S,E)&&(x.houseId===h.id||ids.includes(x.cycleId)));
      const cost=uses.reduce((a,x)=>a+num(x.cost??x.amount),0)+direct.reduce((a,x)=>a+num(x.amount),0);
      const harvest=D.harvests.filter(x=>inPeriod(x,S,E)&&(x.houseId===h.id||ids.includes(x.cycleId)));
      const qty=harvest.reduce((a,x)=>a+num(x.qty),0), waste=harvest.reduce((a,x)=>a+num(x.waste),0);
      const income=D.income.filter(x=>inPeriod(x,S,E)&&(x.houseId===h.id||ids.includes(x.cycleId))).reduce((a,x)=>a+num(x.amount??x.total),0);
      const tasks=D.tasks.filter(t=>(t.houseId===h.id||ids.includes(t.cycleId))&&(t.date||'')>=S&&(t.date||'')<=E), done=tasks.filter(t=>t.status==='Done').length;
      return {h,cycles,cost,qty,waste,income,profit:income-cost,tasks:tasks.length,done,completion:tasks.length?done/tasks.length*100:0};
    });
  }
  function cropRows(S,E){
    return D.yearPlans.filter(p=>p.end>=S&&p.start<=E).map(p=>{
      const uses=D.usages.filter(x=>x.cycleId===p.id&&inPeriod(x,S,E));
      const cost=uses.reduce((a,x)=>a+num(x.cost??x.amount),0)+D.costs.filter(x=>x.cycleId===p.id&&inPeriod(x,S,E)).reduce((a,x)=>a+num(x.amount),0);
      const hs=D.harvests.filter(x=>x.cycleId===p.id&&inPeriod(x,S,E)),qty=hs.reduce((a,x)=>a+num(x.qty),0),waste=hs.reduce((a,x)=>a+num(x.waste),0);
      const income=D.income.filter(x=>x.cycleId===p.id&&inPeriod(x,S,E)).reduce((a,x)=>a+num(x.amount??x.total),0);
      return {p,cost,qty,waste,income,profit:income-cost};
    });
  }
  function stockRows(){
    return D.stock.map(s=>{let days=s.expiryDate?Math.ceil((new Date(s.expiryDate)-new Date(today()))/86400000):null;return {...s,days};});
  }
  function activityRows(S,E){
    const products=D.products.filter(p=>{let c=(p.category||'').toLowerCase();return c.includes('คอร์ส')||c.includes('กิจกรรม')||c.includes('workshop')});
    return products.map(p=>{let orders=D.orders.filter(o=>o.productId===p.id&&['Confirmed','Preparing','Packed','Shipping','Completed'].includes(o.status)&&(!orderDate(o)||inPeriod({date:orderDate(o)},S,E)));let revenue=orders.reduce((a,o)=>a+num(o.total),0),participants=orders.reduce((a,o)=>a+num(o.qty),0);let kind=(p.category||'').includes('คอร์ส')?'คอร์ส':'กิจกรรม / Workshop';return {p,kind,revenue,participants,orders:orders.length};});
  }
  function sponsorRows(){return D.funds.map(f=>{let used=D.purchases.filter(p=>p.fundId===f.id).reduce((a,x)=>a+num(x.total),0)+realExpenses().filter(e=>e.fundId===f.id).reduce((a,x)=>a+num(x.amount),0);return {f,used,balance:num(f.amount)-used};});}

  window.showHouseAnalyticsV1045=function(hid){let S=window.dashS||today().slice(0,7)+'-01',E=window.dashE||today(),r=houseRows(S,E).find(x=>x.h.id===hid);if(!r)return;let ids=r.cycles.map(x=>x.id),uses=D.usages.filter(x=>x.houseId===hid||ids.includes(x.cycleId)),tasks=D.tasks.filter(x=>x.houseId===hid||ids.includes(x.cycleId));showEditModal(`🏡 วิเคราะห์ ${r.h.name}`,`<div class="analyticsKpi"><span>รายได้ <b>฿${money(r.income)}</b></span><span>ต้นทุน <b>฿${money(r.cost)}</b></span><span>กำไร <b>฿${money(r.profit)}</b></span><span>งานตามแผน <b>${r.completion.toFixed(0)}%</b></span></div><h4>รอบการผลิต</h4>${r.cycles.map(p=>`<p><b>${esc(p.crop)}</b> ${p.start} → ${p.end}</p>`).join('')||'ไม่มีข้อมูล'}<h4>วัตถุดิบที่ใช้</h4>${uses.slice(-12).reverse().map(u=>`<p>${u.date||'-'} · ${esc(u.item||'-')} · Lot ${esc(u.lot||'-')} · ${num(u.qty)} ${esc(u.unit||'')}</p>`).join('')||'ไม่มีข้อมูล'}<h4>งานล่าสุด</h4>${tasks.slice(-12).reverse().map(t=>`<p>${t.actualDate||t.date||'-'} · ${esc(t.action||'-')} · ${esc(t.status||'Pending')}</p>`).join('')||'ไม่มีข้อมูล'}`,()=>closeEditModal())};

  window.farmAnalyticsV1045=function(){
    let S=window.dashS||today().slice(0,7)+'-01',E=window.dashE||today(),houses=houseRows(S,E),crops=cropRows(S,E),stocks=stockRows(),acts=activityRows(S,E),funds=sponsorRows();
    let low=stocks.filter(s=>num(s.qty)>0&&num(s.qty)<=num(s.minStock)),expired=stocks.filter(s=>s.days!=null&&s.days<0&&num(s.qty)>0),near=stocks.filter(s=>s.days!=null&&s.days>=0&&s.days<=30&&num(s.qty)>0);
    let prevEnd=new Date(S+'T00:00:00');prevEnd.setDate(prevEnd.getDate()-1);let days=Math.max(1,Math.round((new Date(E)-new Date(S))/86400000)+1),prevStart=new Date(prevEnd);prevStart.setDate(prevStart.getDate()-days+1),PS=prevStart.toISOString().slice(0,10),PE=prevEnd.toISOString().slice(0,10);
    let inc=D.income.filter(x=>inPeriod(x,S,E)).reduce((a,x)=>a+num(x.amount),0),exp=expenses(S,E).reduce((a,x)=>a+num(x.amount??x.total),0),pinc=D.income.filter(x=>inPeriod(x,PS,PE)).reduce((a,x)=>a+num(x.amount),0),pexp=expenses(PS,PE).reduce((a,x)=>a+num(x.amount??x.total),0),ip=fmtPct(inc,pinc),ep=fmtPct(exp,pexp);
    let warnings=[];if(low.length)warnings.push(`Stock ต่ำกว่า Minimum ${low.length} รายการ`);if(near.length)warnings.push(`วัตถุดิบใกล้หมดอายุ 30 วัน ${near.length} Lot`);if(expired.length)warnings.push(`วัตถุดิบหมดอายุ ${expired.length} Lot`);let late=D.tasks.filter(t=>t.status!=='Done'&&t.date<today()).length;if(late)warnings.push(`มีงานเลยกำหนด ${late} งาน`);
    content.innerHTML=`<div class="pageHero"><div><button class="btn2" onclick="go('dashboard')">← ภาพรวมฟาร์ม</button><h2>🧠 Farm Analytics</h2><p>วิเคราะห์การเงิน การผลิต โรงเรือน Stock กิจกรรม และ Sponsor จากข้อมูลจริงในระบบ</p></div></div>
    <div class="grid4"><div class="metric">รายรับช่วงนี้<b>฿${money(inc)}</b><small>${ip==null?'ยังไม่มีฐานเทียบ':`${ip>=0?'▲':'▼'} ${Math.abs(ip).toFixed(1)}% จากช่วงก่อน`}</small></div><div class="metric">รายจ่ายช่วงนี้<b>฿${money(exp)}</b><small>${ep==null?'ยังไม่มีฐานเทียบ':`${ep>=0?'▲':'▼'} ${Math.abs(ep).toFixed(1)}% จากช่วงก่อน`}</small></div><div class="metric">ผลต่าง<b>฿${money(inc-exp)}</b></div><div class="metric">สิ่งที่ควรตรวจสอบ<b>${warnings.length}</b></div></div>
    <div class="card"><h3>⚠️ สิ่งที่ควรตรวจสอบ</h3>${warnings.map(x=>`<div class="insightItem">${esc(x)}</div>`).join('')||'<div class="emptyState">ยังไม่พบรายการผิดปกติจากข้อมูลที่มี</div>'}</div>
    <div class="card"><h3>🏡 เปรียบเทียบประสิทธิภาพแต่ละโรงเรือน</h3><div class="tableWrap"><table><tr><th>โรงเรือน</th><th>พืช/รอบ</th><th>ต้นทุน</th><th>ผลผลิต</th><th>รายได้</th><th>กำไร</th><th>งานตามแผน</th><th></th></tr>${houses.map(r=>`<tr><td><b>${esc(r.h.name)}</b></td><td>${[...new Set(r.cycles.map(x=>x.crop))].map(esc).join(', ')||'-'}</td><td>฿${money(r.cost)}</td><td>${r.qty.toFixed(2)}</td><td>฿${money(r.income)}</td><td class="${r.profit>=0?'positive':'negative'}">฿${money(r.profit)}</td><td>${r.completion.toFixed(0)}%</td><td><button class="btn2" onclick="showHouseAnalyticsV1045('${r.h.id}')">ดูรายละเอียด</button></td></tr>`).join('')||'<tr><td colspan="8">ไม่มีข้อมูลโรงเรือน</td></tr>'}</table></div></div>
    <div class="card"><h3>🌱 กำไรตามพืช / Crop Cycle</h3><div class="tableWrap"><table><tr><th>โรงเรือน</th><th>พืช</th><th>รอบผลิต</th><th>ต้นทุน</th><th>ผลผลิต</th><th>Waste</th><th>รายได้</th><th>กำไร</th></tr>${crops.map(r=>`<tr><td>${esc(houseName(r.p.houseId))}</td><td><b>${esc(r.p.crop)}</b></td><td>${r.p.start} → ${r.p.end}</td><td>฿${money(r.cost)}</td><td>${r.qty.toFixed(2)}</td><td>${r.waste.toFixed(2)}</td><td>฿${money(r.income)}</td><td class="${r.profit>=0?'positive':'negative'}">฿${money(r.profit)}</td></tr>`).join('')||'<tr><td colspan="8">ยังไม่มีข้อมูลรอบการผลิตในช่วงนี้</td></tr>'}</table></div></div>
    <div class="grid2"><div class="card"><h3>📦 Stock Analysis</h3><p>ต่ำกว่า Minimum <b>${low.length}</b> · ใกล้หมดอายุ <b>${near.length}</b> · หมดอายุ <b>${expired.length}</b></p><div class="tableWrap"><table><tr><th>รายการ</th><th>Lot</th><th>คงเหลือ</th><th>สถานะ</th></tr>${[...expired,...near,...low].filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i).slice(0,15).map(s=>`<tr><td>${esc(s.name)}</td><td>${esc(s.lot||'-')}</td><td>${num(s.qty)} ${esc(s.unit||'')}</td><td>${s.days!=null&&s.days<0?'🔴 หมดอายุ':s.days!=null&&s.days<=30?'🟠 ใกล้หมดอายุ':'🟡 Stock ต่ำ'}</td></tr>`).join('')||'<tr><td colspan="4">Stock ปกติ</td></tr>'}</table></div></div><div class="card"><h3>💵 Sponsor Analysis</h3>${funds.map(r=>`<div class="fundAna"><b>${esc(r.f.project||'-')}</b><span>ได้รับ ฿${money(r.f.amount)} · ใช้ ฿${money(r.used)} · คงเหลือ ฿${money(r.balance)}</span><progress max="${Math.max(1,num(r.f.amount))}" value="${Math.min(num(r.f.amount),r.used)}"></progress></div>`).join('')||'<div class="emptyState">ยังไม่มี Sponsor Fund</div>'}</div></div>
    <div class="card"><h3>🎓 คอร์ส / กิจกรรม / Workshop</h3><div class="tableWrap"><table><tr><th>ประเภท</th><th>รายการ</th><th>Order</th><th>ผู้เข้าร่วม/จำนวน</th><th>รายได้</th></tr>${acts.map(r=>`<tr><td>${esc(r.kind)}</td><td>${esc(r.p.name)}</td><td>${r.orders}</td><td>${r.participants}</td><td>฿${money(r.revenue)}</td></tr>`).join('')||'<tr><td colspan="5">ยังไม่มีข้อมูลการขายคอร์ส/กิจกรรม</td></tr>'}</table></div><p class="muted">ต้นทุน/กำไรของคอร์สจะแม่นยำเมื่อรายการต้นทุนถูกผูกกับคอร์สหรือกิจกรรมนั้นโดยตรง</p></div>`;
  };

  // Add a clear entry point from the existing Dashboard without replacing its existing cards/charts.
  const previousDashboard=window.dashboard;
  window.dashboard=function(){previousDashboard();if(me.role==='Staff')return;let a=content.querySelector('.analyticsV1044 .sectionTitle');if(a&&!a.querySelector('.analyticsOpenV1045'))a.insertAdjacentHTML('beforeend','<button class="btn analyticsOpenV1045" onclick="farmAnalyticsV1045()">เปิดวิเคราะห์เชิงลึก →</button>')};

  function categoryOptions(sel){return ['สูตรปุ๋ย','ชีวภัณฑ์/ป้องกันแมลง','คู่มือปลูก','SOP','เครื่องมือ'].map(x=>`<option ${x===sel?'selected':''}>${x}</option>`).join('')}
  window.knowledge=function(){content.innerHTML=`${me.role==='Admin'?`<div class="card"><div class="sectionTitle"><div><h3>📚 สูตร / คู่มือ / SOP</h3><span class="muted">เพิ่มและจัดการองค์ความรู้มาตรฐานของฟาร์ม</span></div><button class="btn" onclick="openKnowledgeEditorV1045()">+ เพิ่มสูตร / คู่มือ</button></div></div>`:''}<div class="card"><h3>คลังความรู้</h3><div class="tableWrap"><table><tr><th>ชื่อ</th><th>ประเภท</th><th>Version</th><th>อัปเดต</th><th>ไฟล์</th><th>จัดการ</th></tr>${D.knowledge.map(k=>`<tr><td><b>${esc(k.title)}</b></td><td>${esc(k.category)}</td><td>${esc(k.version)}</td><td>${k.updated||'-'}</td><td>${(k.files||[]).length}</td><td><button class="btn2" onclick="viewKnowledge('${k.id}')">👁 ดู</button>${me.role==='Admin'?` <button class="btn2" onclick="openKnowledgeEditorV1045('${k.id}')">✏️ แก้ไข</button> <button class="btn2 dangerBtn" onclick="deleteKnowledgeV1045('${k.id}')">🗑️ ลบ</button>`:''}</td></tr>`).join('')||'<tr><td colspan="6">ยังไม่มีสูตร / คู่มือ</td></tr>'}</table></div></div>`};
  window.openKnowledgeEditorV1045=function(kid=''){let k=kid?D.knowledge.find(x=>x.id===kid):null;if(kid&&!k)return;showEditModal(k?'✏️ แก้ไขสูตร / คู่มือ':'➕ เพิ่มสูตร / คู่มือ',`<div class="form"><div class="span2"><label>ชื่อ</label><input id="keTitle" value="${esc(k?.title||'')}"></div><div><label>ประเภท</label><select id="keCat">${categoryOptions(k?.category||'คู่มือปลูก')}</select></div><div><label>Version</label><input id="keVer" value="${esc(k?.version||'1.0')}"></div><div class="span3"><label>รายละเอียด / สูตร / ขั้นตอน</label><textarea id="keDetail" rows="8">${esc(k?.detail||'')}</textarea></div><div class="span3"><label>เพิ่มไฟล์แนบ (รูป/PDF/Word/Excel)</label><input id="keFiles" type="file" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx"></div>${k?.files?.length?`<div class="span3"><label>ไฟล์เดิม</label><div class="attachmentList">${k.files.map((f,i)=>`<label><input type="checkbox" class="keKeep" value="${i}" checked> เก็บ ${esc(f.name)}</label>`).join('')}</div></div>`:''}</div>`,async()=>{if(!keTitle.value.trim())return alert('กรุณาใส่ชื่อสูตร / คู่มือ');let files=k?.files?Array.from(document.querySelectorAll('.keKeep:checked')).map(x=>k.files[+x.value]):[];for(let f of keFiles.files){if(f.size>2.5*1024*1024){alert(f.name+' ใหญ่เกิน 2.5MB');continue}files.push(await filePromise(f))}let data={title:keTitle.value.trim(),category:keCat.value,version:keVer.value.trim()||'1.0',detail:keDetail.value,updated:today(),files};if(k)Object.assign(k,data);else D.knowledge.push({id:id(),...data});try{sv('knowledge');logAudit(k?'EDIT':'CREATE','Knowledge',k?.id||D.knowledge.at(-1).id,data.title);closeEditModal();knowledge()}catch(e){alert('บันทึกไม่สำเร็จ: '+e.message)}})};
  window.deleteKnowledgeV1045=function(kid){let k=D.knowledge.find(x=>x.id===kid);if(!k)return;if(prompt(`ลบ “${k.title}” ?\nพิมพ์ DELETE เพื่อยืนยัน`)!=='DELETE')return;D.knowledge=D.knowledge.filter(x=>x.id!==kid);sv('knowledge');logAudit('DELETE','Knowledge',kid,k.title);knowledge()};
})();
