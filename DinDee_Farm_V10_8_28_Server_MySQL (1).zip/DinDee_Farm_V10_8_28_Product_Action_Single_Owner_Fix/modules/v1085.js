/* DinDee Farm V10.8.5 — Customer PIN Recovery */
(function(){
'use strict';
function phone(x){return String(x||'').replace(/\D/g,'')}
window.resetCustomerPinV1085=function(cid){
 if(me?.role!=='Admin')return alert('เฉพาะ Admin เท่านั้น');
 const c=D.customers.find(x=>x.id===cid);if(!c)return;
 showEditModal(`🔑 Reset PIN — ${esc(c.name||'ลูกค้า')}`,`<div class="helpbox">ระบบจะตั้ง PIN ใหม่แทน PIN เดิม และจะไม่แสดง PIN เดิม</div><div class="form">
 <div><label>เบอร์โทร</label><input value="${esc(c.phone||'')}" disabled></div>
 <div><label>PIN ใหม่ 4 หลัก</label><input id="v85pin1" type="password" inputmode="numeric" maxlength="4" autocomplete="new-password"></div>
 <div><label>ยืนยัน PIN ใหม่</label><input id="v85pin2" type="password" inputmode="numeric" maxlength="4" autocomplete="new-password"></div>
 </div>`,()=>{
  const a=v85pin1.value,b=v85pin2.value;if(!/^\d{4}$/.test(a))return alert('PIN ต้องเป็นตัวเลข 4 หลัก');if(a!==b)return alert('PIN ยืนยันไม่ตรงกัน');
  c.pinHash=hash(a);c.pinResetAt=new Date().toISOString();c.pinResetBy=me?.name||me?.username||'Admin';sv('customers');
  logAudit('RESET PIN','Customer',c.id,`Customer ${c.name||c.id}; PIN value not logged`);closeEditModal();customerHistoryV1062();alert('Reset PIN เรียบร้อย');
 });
};
window.customerRecoveryHelpV1085=function(){
 showEditModal('ลืมเบอร์โทรหรือ PIN',`<div class="helpbox"><b>กรณีจำเบอร์โทรได้ แต่ลืม PIN</b><br>แจ้งชื่อและเบอร์โทรกับเจ้าหน้าที่ดินดีฟาร์ม เพื่อให้ Admin ตรวจสอบและ Reset PIN ใหม่</div>
 <div class="helpbox"><b>กรณีลืมทั้งเบอร์โทรและ PIN</b><br>แจ้งชื่อหรือข้อมูล Order ที่จำได้ เจ้าหน้าที่สามารถค้นหาจากฐานข้อมูลลูกค้าและประวัติการซื้อ หลังตรวจสอบแล้วจึงแก้เบอร์และ Reset PIN</div>
 <p class="small">เพื่อความปลอดภัย ระบบไม่สามารถแสดง PIN เดิมได้</p>`,()=>closeEditModal());
};

/* Decorate Customer Database with compact reset-PIN action without replacing customer history logic. */
const oldCustomer=window.customerHistoryV1062;
window.customerHistoryV1062=function(){
 oldCustomer();
 if(me?.role!=='Admin')return;
 const table=document.querySelector('#content .customer-table');if(!table)return;
 const rows=[...table.querySelectorAll('tr')].slice(1),q=(window.customerQ1062||'').toLowerCase();
 const cs=D.customers.filter(c=>!q||[c.name,c.phone,c.address,c.note].join(' ').toLowerCase().includes(q));
 rows.forEach((tr,i)=>{const c=cs[i],td=tr.lastElementChild;if(!c||!td||td.querySelector('[data-pin-reset]'))return;
   td.querySelectorAll('button').forEach(b=>{b.classList.add('purchase-icon-btn');if((b.textContent||'').includes('ดู')){b.innerHTML='👁️';b.title='ดูประวัติลูกค้า'}else if((b.textContent||'').includes('แก้ไข')){b.innerHTML='✏️';b.title='แก้ไขลูกค้า'}else if((b.textContent||'').includes('ลบ')){b.innerHTML='🗑️';b.title='ลบ/ปิดใช้งานลูกค้า'}});
   const edit=[...td.querySelectorAll('button')].find(b=>b.title==='แก้ไขลูกค้า');
   (edit||td.firstChild)?.insertAdjacentHTML?.('afterend',`<button class="btn2 purchase-icon-btn" data-pin-reset title="Reset PIN" onclick="resetCustomerPinV1085('${c.id}')">🔑</button>`);
 });
};

/* Customer Order lookup: visible recovery path. */
const oldTrack=window.track;
window.track=function(){
 oldTrack();
 const card=document.querySelector('#content .card');if(card&&!card.querySelector('.pin-help-v1085'))card.insertAdjacentHTML('beforeend',`<div class="pin-help-v1085"><button class="linkBtn" onclick="customerRecoveryHelpV1085()">ลืมเบอร์โทรหรือ PIN?</button><div class="small">ติดต่อเจ้าหน้าที่ดินดีฟาร์มเพื่อยืนยันข้อมูลและตั้ง PIN ใหม่</div></div>`);
};
})();
