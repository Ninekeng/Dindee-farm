# V10.7.7 — Income Category Dashboard
- Canonical Income Master: Farm Product Sales, Food & Beverage Income, Learning Center Income, Event Income, Support Income, Other Income.
- Dashboard shows all six categories for the selected date range.
- Farm Shop income is classified from product category rather than always Farm Product Sales.
- Course / Workshop -> Learning Center Income / Workshop Income.
- Activity -> Learning Center Income / Activity Income.
- Historical Farm Shop income classification is repaired from linked orders without changing amount/date.
