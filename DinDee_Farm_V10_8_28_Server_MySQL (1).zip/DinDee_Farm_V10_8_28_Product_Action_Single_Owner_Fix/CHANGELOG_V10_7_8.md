# V10.7.8 — Shop Income Mapping & Sales History
- Shop category Master now maps explicitly to the canonical 6 Income Categories and Income Tags.
- Paid Farm Shop orders create/sync Income using category mapping; mixed baskets can create multiple income rows while preserving the order total.
- Dashboard V10.7.7 reads the same D.income rows, so Farm Shop sales flow directly into the 6-category overview.
- Shop Admin adds Sales History.
- Sales History keeps orders and linked income visible with compact Edit/Delete icons.
- Editing a paid sale re-syncs linked income; deleting a sale deletes only its linked Farm Shop income rows as well.
- Existing paid Farm Shop orders are reclassified from the new mapping without changing their order total.
