# DinDee Farm V10.5 — Stable Operations & Analytics

- Direct Cost: เพิ่มปุ่มลบ พร้อม Audit และคำเตือนรายการที่มี Source
- Reset Transaction: ล้าง Direct Cost ด้วย แต่ไม่ล้าง Master Data
- Farm Shop: ปิดหมวดเก่า `คอร์ส/กิจกรรม`; คง `คอร์ส` และ `กิจกรรม / Workshop` แยกกัน พร้อม flag รายการเก่าให้ Admin ตรวจ
- House 360°: รอบผลิต งาน/ประวัติ วัตถุดิบ ผลผลิต ต้นทุน และต้นทุนต่อหน่วย
- Analytics: เป้าหมาย vs ผลผลิตจริง, Achievement %, Cost/unit และ Drill-down รอบผลิต
- Stock Analytics: มูลค่า Stock, Minimum, Expiry, Slow/Dead Stock
- Sponsor Drill-down: รายการใช้เงินและยอดคงเหลือ
- Alert Center: เพิ่ม Stock ต่ำ/หมดอายุ/ใกล้หมดอายุ และ Sponsor ใกล้หมด
- Global Search: Stock/Lot, Product/SKU, Order, Purchase, Crop Cycle, Knowledge
- Mobile Staff Mode: งานวันนี้และบันทึกผลแบบปุ่มใหญ่
- Security: ไม่คืน Reset Admin หน้า Login
- Staff privacy: ซ่อนรายได้/ต้นทุน/กำไรจากรายงานโรงเรือนสำหรับ Staff
- Backup/Restore: เพิ่ม metadata + validation + preview ก่อน Restore
- Purchase: Auto-save draft และป้องกันการกดบันทึกซ้ำช่วงสั้น
- House QR: ป้าย QR/รหัสโรงเรือน พร้อมพิมพ์ (QR ออนไลน์มี fallback เป็นรหัสโรงเรือน)
