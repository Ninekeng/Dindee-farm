# DinDee Farm V10.8.18
- Dashboard 6-month chart now focuses on รายรับ / รายจ่าย / กำไรสุทธิ (Net).
- Net is calculated as operating income minus cash expense for each month.
- Negative Net is rendered below the zero line so losses remain visually clear.
- Sponsor is removed from the operating-performance chart and remains in the separate Sponsor summary/fund views.
- Direct Cost remains analytical and is not double-counted as cash expense.
