# V10.8.9 — Flow 3 Customer UX & Access Fixes

- Customer checkout: explicit 4-digit PIN flow. Existing customers enter the existing PIN; new/legacy customers set and confirm a PIN.
- Customer permission: block navigation to internal farm pages and hide the internal notification bell for Customer role.
- Order tracking: clear current-step progress display with completed/current/upcoming states.
- Separate Customer Purchase History menu while preserving Customer Database and Live Farm/Camera.
- Farm Analytics dashboard entry uses a reliable direct opener.
- Existing Farm Camera / Live Farm menu is preserved.
