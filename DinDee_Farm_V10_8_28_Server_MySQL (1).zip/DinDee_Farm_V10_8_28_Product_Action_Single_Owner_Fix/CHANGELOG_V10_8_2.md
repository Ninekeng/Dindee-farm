# V10.8.2 — Shop Category Delete
- Added compact 🗑️ delete icon to Shop Category + Income Mapping.
- Category cannot be deleted while products/services still reference it; user must move products or deactivate category first.
- Deleting an unused category removes its mapping only and does not delete historical Orders or Income.
- Delete action is audited and requires confirmation.
