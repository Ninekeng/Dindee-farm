# V10.8.25 — Continuous UI Actions Fix
- Checkout now uses a guarded single-submit path and shows an explicit success state after an Order is saved.
- Prevents double submit while the order/slip is being committed.
- Checkout post-save UI errors no longer cause users to unknowingly resubmit the same order.
- Test-order deletion uses delegated events and in-place array mutation so multiple rows can be deleted continuously without leaving/re-entering the page.
- Preserves V10.8.24 product action icons and all prior functions.
