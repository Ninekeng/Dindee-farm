# DinDee Farm V10.5.2
- Fixed Farm Analytics deep-analysis button with visible error handling.
- Added visible Safe Delete actions to Crop Cycle, Stock, House/Area, Farm Shop, Sales Documents and Sponsor Fund.
- Stock with history archives instead of hard delete.
- Farm Shop delete now detects modern order line-items too.
- Usage Lot recommendation: FEFO when expiry exists; FIFO when no expiry exists.
- Restored Purchase Import/Export directly on Purchase page after later page overrides had hidden the older UI.
- Purchase CSV template/export includes production, manufacture/ready and expiry dates; import has Preview and duplicate checks.
