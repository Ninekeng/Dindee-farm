# V10.6.3 — Notification Reliability Fix
- Rebuilt notification calculation defensively so one malformed record cannot stop all alerts.
- Alerts cover due/overdue tasks, new/payment-submitted orders, out-of-stock, low stock, expiring/expired lots, and low Sponsor balance.
- Fixed badge refresh and sidebar alert count.
- Notification badge refreshes after render, every 30 seconds while logged in, and when the browser regains focus.
- Notification Center now labels Task, Order, Stock, and Sponsor correctly.
