# V10.8.22 — Farm Shop Source & Cost Linkage

- Farm Shop products now support four sources: Farm Harvest, Purchased Stock/Lot, Processed/Food, Other.
- Farm Harvest products link to Crop Cycle/House and enforce unallocated harvested quantity.
- Purchased products link to Stock/Lot and estimate unit cost from Purchase history.
- Processed/Other products support manual unit cost without creating duplicate cash expenses.
- Recognized Order lines snapshot source and unit cost/COGS for reporting.
- House Report revenue derives from paid Farm Shop lines linked to House/Cycle.
- Product profitability uses recognized sales and source cost snapshots.
- Existing products remain compatible as source=Other until edited.
