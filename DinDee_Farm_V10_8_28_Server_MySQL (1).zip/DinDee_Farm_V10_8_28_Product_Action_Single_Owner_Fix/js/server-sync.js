'use strict';
/*
 DinDee server-sync — ต้องโหลดก่อน js/app.js (และหลัง api/bootstrap.js)
 ทำให้ localStorage ของแอปเดิม (คีย์ dindee_v7_*) ซิงก์กับ MySQL ผ่านเซิร์ฟเวอร์ โดยไม่ต้องแก้โค้ดโมดูลเดิม
 - ตอนเริ่ม: เติม localStorage จากข้อมูลบนเซิร์ฟเวอร์ (server คือต้นฉบับ)
 - ตอนแอปเรียก setItem/removeItem: ส่งขึ้นเซิร์ฟเวอร์อัตโนมัติ (debounce)
 - ถ้าไม่มี window.__DINDEE__ (เปิดไฟล์ตรง ๆ) จะทำงานแบบ localStorage เดิม
*/
(function () {
  const B = window.__DINDEE__;
  if (!B) return;

  const PFX = 'dindee_v7_', LOCAL_ONLY = /draft|fingerprint/i, TIER_KEY = 'dindee_cache_tier';
  const PUBLIC_REPLACE = ['products', 'appSettings', 'units', 'shopCategories', 'farmProfile'];
  const ls = window.localStorage;
  const nSet = Storage.prototype.setItem, nGet = Storage.prototype.getItem, nRem = Storage.prototype.removeItem;
  const synced = k => typeof k === 'string' && k.startsWith(PFX) && !LOCAL_ONLY.test(k.slice(PFX.length));
  const nameOf = k => k.slice(PFX.length);
  const mem = new Map(); /* ค่าที่ใหญ่เกินโควตา localStorage (~5MB) จะเก็บในหน่วยความจำแทน แต่ยังซิงก์ขึ้น server */

  function safeSet(k, v) { try { nSet.call(ls, k, v); mem.delete(k); } catch (e) { mem.set(k, v); try { nRem.call(ls, k); } catch (_) {} } }
  const localKeys = () => Object.keys(ls).filter(synced);

  /* ---------- hydrate จากเซิร์ฟเวอร์ ---------- */
  const prevTier = nGet.call(ls, TIER_KEY);
  if (B.tier === 'full') {
    localKeys().forEach(k => { if (!(nameOf(k) in B.state)) nRem.call(ls, k); });
    Object.keys(B.state).forEach(n => safeSet(PFX + n, B.state[n]));
  } else {
    if (prevTier === 'full') localKeys().forEach(k => nRem.call(ls, k)); /* เครื่องเคยใช้โดยพนักงาน: ล้างแคชก่อนให้ลูกค้า */
    localKeys().forEach(k => { const n = nameOf(k); if (n !== 'orders' && n !== 'customers' && !PUBLIC_REPLACE.includes(n)) nRem.call(ls, k); });
    PUBLIC_REPLACE.forEach(n => { if (n in B.state) safeSet(PFX + n, B.state[n]); else nRem.call(ls, PFX + n); });
    if (B.state.orders) {
      let loc = []; try { loc = JSON.parse(nGet.call(ls, PFX + 'orders') || '[]'); } catch (_) {}
      const have = new Set(loc.map(o => o.id));
      safeSet(PFX + 'orders', JSON.stringify(loc.concat(JSON.parse(B.state.orders).filter(o => !have.has(o.id)))));
    }
  }
  try { nSet.call(ls, TIER_KEY, B.tier); } catch (_) {}

  const vers = Object.assign({}, B.vers);
  const readLocal = k => (mem.has(k) ? mem.get(k) : nGet.call(ls, k));

  /* ---------- สถานะ/แจ้งเตือน ---------- */
  let bar;
  function ui() {
    if (bar) return bar;
    bar = document.createElement('div');
    bar.id = 'ddSyncBar';
    bar.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:99999;max-width:340px;font:13px/1.4 system-ui,sans-serif;background:#1f3d2a;color:#fff;padding:8px 12px;border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,.25);display:none';
    document.body.appendChild(bar);
    return bar;
  }
  function show(html, bg) { const b = ui(); b.style.background = bg || '#1f3d2a'; b.innerHTML = html; b.style.display = 'block'; }
  function hide() { if (bar) bar.style.display = 'none'; }
  const btn = (label, id) => `<button data-sync="${id}" style="margin:6px 6px 0 0;padding:4px 10px;border:0;border-radius:6px;cursor:pointer">${label}</button>`;

  /* ---------- ส่งข้อมูลขึ้นเซิร์ฟเวอร์ ----------
     ผู้ใช้ทีมงาน (tier=full): รวมทุกการบันทึกที่เกิดใกล้กันเป็น "ชุดเดียว" ส่ง /api/commit → server บันทึกใน transaction เดียว
       (เช่น ซื้อของ → stock + purchases + expenses สำเร็จพร้อมกันหรือไม่สำเร็จเลย ไม่มีข้อมูลขาดครึ่งทาง)
     ลูกค้าทั่วไป (tier=public): ส่งทีละชุดแบบ merge ตามเดิม */
  const dirty = new Set(), conflicts = new Map();
  let timer = null, firstDirtyAt = 0, inflight = null, failures = 0, fatal = null, forceNext = false;
  const DEBOUNCE = 400, MAXWAIT = 3000;
  const busy = () => dirty.size + (inflight ? inflight.length : 0);

  function refreshStatus() {
    if (fatal || conflicts.size) return;
    if (failures && busy()) show('⚠️ บันทึกขึ้นเซิร์ฟเวอร์ไม่สำเร็จ จะลองใหม่อัตโนมัติ…', '#8a5a1f');
    else if (busy()) show('⏳ กำลังบันทึกขึ้นเซิร์ฟเวอร์…');
    else hide();
  }
  async function call(method, url, body) {
    const r = await fetch(url, { method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    let j = {}; try { j = await r.json(); } catch (_) {}
    return { status: r.status, body: j };
  }
  function schedule(name, delay) {
    if (B.readOnly) return;
    dirty.add(name);
    if (!firstDirtyAt) firstDirtyAt = Date.now();
    if (conflicts.size) { refreshStatus(); return; } /* รอผู้ใช้เลือกวิธีแก้ก่อน */
    clearTimeout(timer);
    const wait = delay != null ? delay : Math.max(0, Math.min(DEBOUNCE, firstDirtyAt + MAXWAIT - Date.now()));
    timer = setTimeout(flushBatch, wait);
    refreshStatus();
  }
  function retryLater() {
    failures = Math.min(failures + 1, 6);
    clearTimeout(timer); timer = setTimeout(flushBatch, Math.min(30000, 1500 * failures * failures));
  }
  async function flushBatch() {
    clearTimeout(timer); timer = null;
    if (inflight) { timer = setTimeout(flushBatch, 300); return; }
    if (!dirty.size || fatal || conflicts.size) { refreshStatus(); return; }
    const names = [...dirty]; dirty.clear(); firstDirtyAt = 0;
    inflight = names; refreshStatus();
    const force = forceNext; forceNext = false;
    try {
      if (B.tier !== 'full') { await flushPublic(names); failures = 0; return; }
      const writes = names.map(n => {
        const raw = readLocal(PFX + n);
        return raw === null ? { key: n, del: true } : { key: n, value: raw, base: vers[n] == null ? null : vers[n], force };
      });
      const r = await call('POST', 'api/commit', { writes });
      if (r.status === 200) { Object.assign(vers, r.body.vers || {}); names.forEach(n => { if (!(n in (r.body.vers || {}))) delete vers[n]; }); failures = 0; }
      else if (r.status === 409) {
        /* ไม่มีอะไรถูกบันทึกเลย (atomic) — เก็บทุกชุดไว้รอตัดสินใจ */
        names.forEach(n => { conflicts.set(n, 0); dirty.add(n); }); /* ยังไม่ได้บันทึก: เก็บไว้ให้ปุ่ม "บันทึกทับ" ส่งซ้ำทั้งชุด */
        (r.body.conflicts || []).forEach(c => conflicts.set(c.key, c.ver));
        showConflict(r.body.conflicts || []);
      } else if (r.status === 401 || r.status === 403 || r.status === 400) {
        names.forEach(n => dirty.add(n));
        fatal = r.status === 401 ? 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่' : r.status === 403 ? 'บัญชีนี้ไม่มีสิทธิ์บันทึกข้อมูลชุดนี้' : (r.body.error || 'ข้อมูลไม่ถูกต้อง');
        show('⚠️ ' + fatal + '<br>(ยังไม่มีอะไรถูกบันทึกในชุดนี้) ' + btn('โหลดหน้าใหม่', 'reload'), '#8a2a1f');
      } else throw new Error('HTTP ' + r.status);
    } catch (e) {
      names.forEach(n => dirty.add(n)); if (!firstDirtyAt) firstDirtyAt = Date.now();
      retryLater();
    } finally {
      inflight = null;
      if (!fatal && !conflicts.size && !timer && dirty.size && failures === 0) timer = setTimeout(flushBatch, 50);
      if (!fatal) refreshStatus();
    }
  }
  async function flushPublic(names) {
    for (const name of names) {
      const raw = readLocal(PFX + name);
      if (raw === null) continue; /* ลูกค้าทั่วไปลบข้อมูลบน server ไม่ได้ */
      try { await call('PUT', 'api/kv/' + name, { value: raw, force: false }); } catch (_) { /* ลูกค้า: ข้ามเงียบ ๆ */ }
    }
  }
  function flushAll() { if (dirty.size) { clearTimeout(timer); flushBatch(); } }

  function showConflict(list) {
    const names = (list && list.length ? list.map(c => c.key) : [...conflicts.keys()]).join(', ');
    show(`⚠️ ข้อมูล <b>${names}</b> ถูกแก้จากเครื่อง/แท็บอื่นไปก่อนแล้ว — <b>ยังไม่มีอะไรในชุดนี้ถูกบันทึก</b><br>${btn('โหลดข้อมูลล่าสุด (ทิ้งที่ยังไม่บันทึก)', 'reload')}${btn('บันทึกทับของเซิร์ฟเวอร์', 'force')}`, '#8a2a1f');
  }
  document.addEventListener('click', e => {
    const t = e.target.closest && e.target.closest('[data-sync]'); if (!t) return;
    const a = t.getAttribute('data-sync');
    if (a === 'reload') location.reload();
    if (a === 'force') { conflicts.clear(); forceNext = true; hide(); flushBatch(); }
  });

  /* ---------- ดักการเขียน localStorage ของแอปเดิม ---------- */
  Storage.prototype.setItem = function (k, v) {
    if (this === ls && synced(k)) { safeSet(k, String(v)); schedule(nameOf(k)); return; }
    return nSet.apply(this, arguments);
  };
  Storage.prototype.removeItem = function (k) {
    if (this === ls && synced(k)) { mem.delete(k); nRem.call(ls, k); schedule(nameOf(k)); return; }
    return nRem.apply(this, arguments);
  };
  Storage.prototype.getItem = function (k) {
    if (this === ls && synced(k) && mem.has(k)) return mem.get(k);
    return nGet.apply(this, arguments);
  };

  /* ---------- เตือนก่อนปิดหน้า / ส่งทันทีเมื่อออกจากแท็บ / เช็คข้อมูลใหม่จากเครื่องอื่น ---------- */
  window.addEventListener('beforeunload', e => { if (busy() || conflicts.size) { e.preventDefault(); e.returnValue = ''; } });
  document.addEventListener('visibilitychange', () => { if (document.hidden) flushAll(); else checkRemote(); });
  async function checkRemote() {
    if (B.tier !== 'full' || fatal || busy() || conflicts.size) return;
    try {
      const r = await call('GET', 'api/versions');
      if (r.status !== 200) return;
      const changed = Object.keys(r.body.vers || {}).filter(k => (vers[k] || 0) < r.body.vers[k]);
      if (changed.length) show('🔄 มีข้อมูลอัปเดตจากเครื่องอื่น<br>' + btn('โหลดข้อมูลใหม่', 'reload'), '#1f5d8a');
    } catch (_) {}
  }
  if (B.tier === 'full') setInterval(checkRemote, 45000);

  window.DinDeeSync = { flushAll, versions: vers, pending: busy };
})();
