'use strict';
/*
V10 Architecture Contract
1. UI pages render only UI.
2. Data mutations belong in services.
3. Storage access goes through repository functions.
4. Every mutation writes Audit.
5. Never delete an existing route/function without a migration.
6. IDs, not display names, connect House/Cycle/Product/Fund.
7. A failing module must not crash navigation.
*/
window.DinDee = window.DinDee || {modules:{},services:{}};
