'use strict';
/*
 DinDee server-session — โหลดหลังโมดูลทั้งหมด
 เปลี่ยน login/logout/reset ให้ใช้เซิร์ฟเวอร์ (เดิมตรวจรหัสผ่านใน browser ซึ่งไม่ปลอดภัยเมื่อขึ้นเซิร์ฟเวอร์จริง)
*/
(function () {
  const B = window.__DINDEE__;
  if (!B) return;
  const jsonPost = (url, body) => fetch(url, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });

  window.doLogin = async function () {
    const u = lu.value.trim(), p = lp.value;
    if (!u || !p) { err.textContent = 'กรอก Username/Password'; return; }
    err.textContent = 'กำลังตรวจสอบ…';
    try {
      const r = await jsonPost('api/login', { user: u, pass: p });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) { err.textContent = j.error || 'ข้อมูลไม่ถูกต้อง'; return; }
      location.reload();
    } catch (e) { err.textContent = 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้'; }
  };

  window.logout = async function () {
    try { if (window.DinDeeSync) window.DinDeeSync.flushAll(); await new Promise(r => setTimeout(r, 600)); await jsonPost('api/logout'); } catch (e) {}
    location.reload();
  };

  window.resetAdminLogin = function () {
    alert('ระบบนี้ใช้การเข้าสู่ระบบฝั่งเซิร์ฟเวอร์\nหากลืมรหัส Admin ให้รันบนเซิร์ฟเวอร์:\nnode scripts/reset-admin.js "รหัสใหม่"');
  };

  window.factoryReset = async function () {
    if (!(B.session && B.session.role === 'Admin')) return alert('เฉพาะ Admin เท่านั้น');
    if (prompt('พิมพ์ RESET เพื่อยืนยันการล้างข้อมูลทั้งหมด (ลบข้อมูลบนเซิร์ฟเวอร์ถาวร)') !== 'RESET') return;
    const r = await jsonPost('api/reset', { confirm: 'RESET' });
    if (!r.ok) return alert('ล้างข้อมูลไม่สำเร็จ');
    Object.keys(localStorage).filter(k => k.startsWith('dindee_v7_')).forEach(k => Storage.prototype.removeItem.call(localStorage, k));
    location.reload();
  };

  /* ผู้ใช้ที่มี session อยู่แล้ว: เข้าแอปอัตโนมัติ */
  const s = B.session;
  try { first.classList.add('hidden'); } catch (e) {}
  if (s) {
    me = (D.users || []).find(x => x.id === s.id) || { id: s.id, user: s.user, role: s.role };
    login.classList.add('hidden');
    app.classList.remove('hidden');
    who.textContent = me.user + ' • ' + me.role;
    page = me.role === 'Customer' ? 'shop' : me.role === 'Sponsor Viewer' ? 'sponsor' : 'dashboard';
    render();
  }
})();
