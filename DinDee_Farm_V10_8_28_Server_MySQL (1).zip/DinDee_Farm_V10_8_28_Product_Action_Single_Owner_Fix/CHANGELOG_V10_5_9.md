# V10.5.9 — Task Management Center
- Added one centralized page for all pending/completed/problem/postponed tasks.
- KPI counters and filters for date, greenhouse, crop cycle, responsible person, status, and text.
- Per-task View, Edit, Record Result, and Admin Safe Delete actions.
- Safe Delete returns linked material usage to the original Stock/Lot before removing the task.
- Added entry button from Monthly Plan while preserving Calendar/Timeline behavior.
