'use strict';
/* ใช้เมื่อลืมรหัส Admin:  node scripts/reset-admin.js "รหัสใหม่"   (อ่านค่า MYSQL_* จาก environment เหมือน server) */
const crypto = require('crypto');
const { createDb } = require('../server/db');
const { hashPasswordSync } = require('../server/auth');

(async () => {
  const pw = process.argv[2];
  if (!pw || pw.length < 6) { console.error('ใช้: node scripts/reset-admin.js "รหัสผ่านใหม่ (อย่างน้อย 6 ตัว)"'); process.exit(1); }
  const db = createDb(); await db.init();
  const cur = await db.get('users');
  let users = []; try { users = JSON.parse(cur ? cur.v : '[]'); } catch (_) {}
  let a = users.find(x => x.user === 'admin');
  if (!a) { a = { id: Date.now().toString(36) + crypto.randomBytes(3).toString('hex'), user: 'admin' }; users.push(a); }
  a.role = 'Admin'; a.pass = hashPasswordSync(pw); delete a.plainPass;
  await db.put('users', JSON.stringify(users), null, 'cli', true);
  console.log('ตั้งรหัส admin ใหม่เรียบร้อย');
  await db.close();
})().catch(e => { console.error(e); process.exit(1); });
