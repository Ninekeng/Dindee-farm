'use strict';
/*
 สร้างชุดตั้งค่าสำหรับฟาร์มใหม่ (แยกฐานข้อมูล/พอร์ต/ชื่อ จากฟาร์มอื่นโดยสิ้นเชิง)
 ใช้:  node scripts/new-farm.js <slug> "<ชื่อไทย>" "<English name>" [port]
 ตัวอย่าง: node scripts/new-farm.js greengarden "สวนเขียวขจี" "Green Garden Farm" 3001
*/
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const [slug, nameTh, nameEn, portArg] = process.argv.slice(2);
const ROOT = path.resolve(__dirname, '..');
const die = m => { console.error('ผิดพลาด: ' + m); process.exit(1); };

if (!slug || !nameTh || !nameEn) die('ใช้: node scripts/new-farm.js <slug> "<ชื่อไทย>" "<English name>" [port]');
if (!/^[a-z0-9][a-z0-9-]{1,30}$/.test(slug)) die('slug ใช้ได้เฉพาะ a-z 0-9 และ - (2-31 ตัว)');
for (const [k, v] of [['ชื่อไทย', nameTh], ['English name', nameEn]]) if (!/^[^\\'"`$<>&{}\r\n]{1,80}$/.test(v)) die(`${k} ห้ามมี \\ ' " \` $ < > & { } และต้องยาว 1-80 ตัวอักษร`);

const dir = path.join(ROOT, 'farms', slug);
if (fs.existsSync(dir)) die(`มี farms/${slug} อยู่แล้ว (ไม่เขียนทับ)`);

/* เลือกพอร์ตว่างถัดไปจากฟาร์มที่มีอยู่ */
const used = new Set();
if (fs.existsSync(path.join(ROOT, 'farms'))) for (const d of fs.readdirSync(path.join(ROOT, 'farms'))) {
  try { const m = /^PORT=(\d+)/m.exec(fs.readFileSync(path.join(ROOT, 'farms', d, '.env'), 'utf8')); if (m) used.add(+m[1]); } catch (_) {}
}
let port = portArg ? +portArg : 3001; if (!portArg) while (used.has(port)) port++;
if (!(port > 1023 && port < 65536)) die('port ไม่ถูกต้อง'); if (used.has(port)) die('พอร์ต ' + port + ' ถูกใช้โดยฟาร์มอื่นแล้ว');

const rnd = n => crypto.randomBytes(n).toString('base64url');
const adminPw = rnd(9);
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, 'farm.json'), JSON.stringify({ nameTh, nameEn, logoEmoji: '🌿', logoFile: '' }, null, 2) + '\n');
fs.writeFileSync(path.join(dir, '.env'), [
  `PORT=${port}`,
  `FARM_CONFIG_DIR=./farms/${slug}`,
  `MYSQL_DATABASE=dindee`, `MYSQL_USER=dindee`,
  `MYSQL_PASSWORD=${rnd(18)}`, `MYSQL_ROOT_PASSWORD=${rnd(18)}`,
  `ADMIN_PASSWORD=${adminPw}`,
  `COOKIE_SECURE=0`, `TRUST_PROXY=0`, '',
].join('\n'), { mode: 0o600 });

console.log(`สร้างฟาร์ม "${nameTh}" แล้วที่ farms/${slug}/
  พอร์ต: ${port}    admin รหัสเริ่มต้น: ${adminPw}   (ใช้ครั้งแรกเท่านั้น เข้าแล้วเปลี่ยนทันที และลบบรรทัด ADMIN_PASSWORD ออกจาก farms/${slug}/.env)

เริ่มระบบ:
  docker compose -p dindee-${slug} --env-file farms/${slug}/.env up -d --build
หยุด:
  docker compose -p dindee-${slug} down
ใส่โลโก้: วางไฟล์ไว้ใน farms/${slug}/ แล้วแก้ farm.json ให้ "logoFile": "logo.png" จากนั้นสั่ง
  docker compose -p dindee-${slug} --env-file farms/${slug}/.env restart app`);
