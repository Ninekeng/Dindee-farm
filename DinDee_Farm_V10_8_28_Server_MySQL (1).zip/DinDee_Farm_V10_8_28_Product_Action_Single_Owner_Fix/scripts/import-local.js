'use strict';
/*
 นำข้อมูลเดิมจาก localStorage ของ browser (ระบบเวอร์ชันเก่าที่ไม่มี server) เข้า MySQL
 1) เปิดระบบเดิมใน browser เครื่องเดิมที่มีข้อมูล กด F12 > Console แล้ววาง:
      copy(JSON.stringify(Object.fromEntries(Object.keys(localStorage).filter(k=>k.startsWith('dindee_v7_')).map(k=>[k.slice(10),localStorage[k]]))))
 2) วางลงไฟล์ เช่น old-data.json
 3) รัน:  node scripts/import-local.js old-data.json        (ข้อมูลชุดเดียวกันบน server จะถูกเขียนทับ)
*/
const fs = require('fs');
const { createDb } = require('../server/db');
const { hashPasswordSync } = require('../server/auth');

(async () => {
  const file = process.argv[2];
  if (!file) { console.error('ใช้: node scripts/import-local.js old-data.json'); process.exit(1); }
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  const db = createDb(); await db.init();
  let n = 0;
  for (const [k, v] of Object.entries(raw)) {
    if (!/^[A-Za-z0-9_]{1,100}$/.test(k) || /draft|fingerprint/i.test(k)) continue;
    let s = typeof v === 'string' ? v : JSON.stringify(v);
    if (k === 'users') { /* แปลง plainPass เป็น scrypt และไม่เก็บรหัสตัวจริงลงฐานข้อมูล */
      try { s = JSON.stringify(JSON.parse(s).map(u => { const c = { ...u }; if (c.plainPass) c.pass = hashPasswordSync(c.plainPass); delete c.plainPass; return c; })); } catch (_) {}
    }
    try { JSON.parse(s); } catch (_) { console.log('ข้าม (ไม่ใช่ JSON):', k); continue; }
    await db.put(k, s, null, 'import', true); n++; console.log('นำเข้า', k);
  }
  console.log(`เสร็จ ${n} ชุดข้อมูล`);
  await db.close();
})().catch(e => { console.error(e); process.exit(1); });
