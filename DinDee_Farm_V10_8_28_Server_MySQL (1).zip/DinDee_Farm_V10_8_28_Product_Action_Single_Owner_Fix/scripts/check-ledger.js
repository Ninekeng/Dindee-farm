'use strict';
/* ตรวจว่า Order กับรายรับตรงกันไหม (อ่านอย่างเดียว):  node scripts/check-ledger.js   — ใช้ค่า MYSQL_* เหมือน server */
const { createDb } = require('../server/db');
const { checkLedger } = require('../server/ledger');
(async () => {
  const db = createDb(); await db.init();
  const get = async k => { const r = await db.get(k); try { return r ? JSON.parse(r.v) : []; } catch (_) { return []; } };
  const res = checkLedger({ orders: await get('orders'), income: await get('income') });
  console.log(`ตรวจ ${res.orders} Order / ${res.incomeRows} แถวรายรับ Farm Shop`);
  if (res.ok) console.log('✅ ไม่พบความผิดปกติ');
  else { console.log(`⚠️ พบ ${res.issues.length} รายการ:`); res.issues.forEach(i => console.log(' -', i.type, i.order || i.refId || '', i.message, JSON.stringify({ total: i.total, incomeSum: i.incomeSum }))); }
  await db.close(); process.exit(res.ok ? 0 : 2);
})().catch(e => { console.error(e); process.exit(1); });
