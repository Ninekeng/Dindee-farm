#!/usr/bin/env bash
# สำรองฐานข้อมูล:  ./scripts/backup.sh   (ตั้ง cron เช่น 0 2 * * * /path/scripts/backup.sh)
set -euo pipefail
OUT="${BACKUP_DIR:-./backups}"; mkdir -p "$OUT"
FILE="$OUT/dindee-$(date +%Y%m%d-%H%M%S).sql.gz"
if [ -n "${DOCKER_DB_SERVICE:-}" ]; then
  docker compose exec -T "$DOCKER_DB_SERVICE" sh -c 'mysqldump -u"$MYSQL_USER" -p"$MYSQL_PASSWORD" --single-transaction "$MYSQL_DATABASE"' | gzip > "$FILE"
else
  mysqldump -h"${MYSQL_HOST:-127.0.0.1}" -u"${MYSQL_USER:-dindee}" -p"${MYSQL_PASSWORD:-}" --single-transaction "${MYSQL_DATABASE:-dindee}" | gzip > "$FILE"
fi
find "$OUT" -name 'dindee-*.sql.gz' -mtime +30 -delete
echo "สำรองแล้ว: $FILE"
