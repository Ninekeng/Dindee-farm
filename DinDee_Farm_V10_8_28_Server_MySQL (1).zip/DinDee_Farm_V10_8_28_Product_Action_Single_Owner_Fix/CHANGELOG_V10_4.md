# DinDee Farm V10.4
- Professional interior UI refresh.
- Annual production plan: full-year responsive Gantt from existing Crop Cycle data.
- Monthly plan: full-month Calendar and Timeline without horizontal scrolling; multi-greenhouse A4 landscape printing.
- Purchase traceability: Lot, production start, manufacture/ready date, expiry date; saved to stock lot.
- Sales documents: clearer print action, full farm name, per-line total, Farm/Activity QR display support.
- Farm profile/payment QR settings.
- Farm Shop: scalable categories, search, SKU, 24-item page cap, cart.
- Checkout popup: customer info, order summary, QR or cash, slip required for QR, order creation after validation.
