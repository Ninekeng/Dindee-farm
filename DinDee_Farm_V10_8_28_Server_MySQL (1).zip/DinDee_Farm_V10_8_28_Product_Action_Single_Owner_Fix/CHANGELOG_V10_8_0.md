# V10.8.0 — Work History Material Edit
- Work History now shows actual Material / Lot and a compact material-edit icon.
- Existing task-linked usages can change material Lot, quantity, date and note.
- Changing quantity/Lot returns the old stock quantity first and deducts the new selection, preventing double deduction.
- Materials can be added retrospectively to a completed work-history item.
- Existing work/task edit and delete functions remain unchanged.
