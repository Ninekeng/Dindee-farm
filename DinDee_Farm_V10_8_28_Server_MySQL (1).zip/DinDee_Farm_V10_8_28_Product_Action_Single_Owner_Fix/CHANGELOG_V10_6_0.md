# V10.6.0 — Annual Plan & Settings Layout Fix
- Fixed the root action normalizer so Crop Cycle delete buttons are never injected into Annual Plan/Gantt rows.
- Added a final defensive cleanup after render/year to remove any legacy delete control from the annual Gantt.
- Settings master sections are now stacked vertically, one topic per row.
- Removed internal Settings table horizontal scrolling and allowed each section to use full page width.
