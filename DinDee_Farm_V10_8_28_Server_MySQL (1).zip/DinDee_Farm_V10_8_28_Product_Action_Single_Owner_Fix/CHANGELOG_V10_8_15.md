# DinDee Farm V10.8.15

- Customer Database search now filters the existing table in place, so typing name/phone/address no longer loses focus after each character.
- Customer Purchase History now shows a permanent test-order delete action only for Admin while Test Mode is enabled.
- Deleting a test order requires confirmation, restores ordered product quantity, removes Farm Shop Income linked by refId, preserves the customer master record, and writes an audit entry.
- Purchase History search also filters in place without losing focus.
