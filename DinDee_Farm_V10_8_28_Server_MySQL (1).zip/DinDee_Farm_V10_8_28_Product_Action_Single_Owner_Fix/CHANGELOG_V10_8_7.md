# V10.8.7 — Farm Flow Final Fixes
1. Monthly Plan desktop fits the full month; task-type column is 160px. No global UI/date-format changes.
2. Task status and work result are separated: Pending/Done/Postponed vs Normal/Problem. Problem reveals problem-detail and corrective/follow-up fields. Old Problem/Issue tasks migrate to Done + Problem.
3. Planned material can be selected when creating work without choosing a Lot or deducting Stock. Actual completion selects material + FEFO-sorted Lot + actual quantity and deducts Stock. Work History shows material, Lot, quantity and unit.
4. Stock main page shows only qty > 0. Zero-qty lots remain in Stock/Lot History. Purchase matching now merges only when item/category/unit/lot/expiry all match; differing expiry creates a separate lot row.
