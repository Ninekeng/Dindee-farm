# V10.7.0 — Fix actual Add Production Cycle species selector
- Fixed the actual `+ เพิ่มรอบการผลิต` popup used by Annual Production Plan.
- `พืช/ผลผลิต` now links to active Settings > ชนิดพืช / สัตว์ via a dropdown suggestion list.
- The field remains editable: users can select a Master value or type a new name.
- Custom typed names are not automatically inserted into Master.
- Previous V10.6.9 support in other Crop Cycle forms remains.
