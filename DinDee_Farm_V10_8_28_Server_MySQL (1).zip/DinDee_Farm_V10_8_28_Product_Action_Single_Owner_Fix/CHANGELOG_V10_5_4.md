# V10.5.4 — Delete Button Visibility Fix
- Fixed the root cause from V10.5.3: `me` is a top-level `let`, so `window.me` is undefined.
- The Admin visibility check now reads the global lexical `me` binding safely.
- This restores delete buttons in edit dialogs for Crop Cycle, Stock, House/Area, Farm Shop, Sales Documents, and Sponsor Fund.
