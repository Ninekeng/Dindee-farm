# V10.5.5 — Excel Import / Export
- Added true .xlsx Purchase template, export and import.
- Added preview validation before Purchase import, including duplicate checks.
- Purchase Excel import creates Purchase + Stock + Expense consistently.
- Added multi-sheet Excel workbook export for Purchase, Stock, Crop Cycle, Houses, Farm Shop and Finance.
- CSV remains available as fallback.
- Uses SheetJS 0.20.3 browser build from the official CDN.
