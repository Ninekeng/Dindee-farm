# DinDee Farm — วิธีรันบน Server + MySQL

## สิ่งที่เปลี่ยนจากเดิม
เดิมระบบเก็บข้อมูลใน `localStorage` ของ browser (แต่ละเครื่องมีข้อมูลของตัวเอง) ตอนนี้:

| ส่วน | เดิม | ตอนนี้ |
|---|---|---|
| ที่เก็บข้อมูล | localStorage ในเครื่อง | **MySQL** ผ่าน Node.js server (ทุกเครื่องเห็นข้อมูลเดียวกัน) |
| Login | ตรวจรหัสผ่านใน browser | **ตรวจที่ server** + cookie session (HttpOnly) |
| โค้ดเดิม 62 โมดูล | — | **ไม่ได้แก้** มีไฟล์ใหม่แค่ `js/server-sync.js`, `js/server-session.js` และโฟลเดอร์ `server/` |

ถ้าเปิด `index.html` ตรง ๆ (ไม่ผ่าน server) ระบบจะกลับไปทำงานแบบ localStorage เดิมได้

## วิธีที่ 1: Docker (แนะนำ)
```bash
cp .env.example .env        # แล้วแก้รหัสผ่านใน .env
docker compose up -d --build
docker compose logs app     # ดูรหัส admin ที่สุ่มให้ (ถ้าไม่ได้ตั้ง ADMIN_PASSWORD)
```
เปิด `http://IP-ของเซิร์ฟเวอร์:3000` — เข้าด้วย `admin` + รหัสที่ได้ แล้วเปลี่ยนรหัสในเมนูผู้ใช้ทันที

## วิธีที่ 2: ติดตั้งเอง (Node 18+ และ MySQL 8 / MariaDB 10.5+)
```sql
CREATE DATABASE dindee CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'dindee'@'%' IDENTIFIED BY 'รหัสผ่าน';
GRANT ALL ON dindee.* TO 'dindee'@'%';
```
```bash
npm install --omit=dev
export MYSQL_HOST=127.0.0.1 MYSQL_USER=dindee MYSQL_PASSWORD=รหัสผ่าน MYSQL_DATABASE=dindee ADMIN_PASSWORD=รหัสแอดมิน
npm start
```
ตารางสร้างให้อัตโนมัติ (ดู `server/schema.sql`) รันถาวรด้วย systemd: `deploy/dindee.service.example`

## เปลี่ยนชื่อ/โลโก้ฟาร์ม (ไม่ต้องแก้โค้ด)
แก้ไฟล์ `config/farm.json` แล้ว restart (`docker compose restart app`):
```json
{ "nameTh": "สวนเขียวขจี", "nameEn": "Green Garden Farm", "logoEmoji": "🥬", "logoFile": "" }
```
- ใส่ `fullNameTh`, `fullNameEn`, `shortName` เพิ่มได้ ถ้าไม่ใส่ ระบบตั้งตามชื่อหลักให้
- ใช้รูปโลโก้แทนอีโมจิ: วางไฟล์ (.png .jpg .webp .svg) ไว้ข้าง `farm.json` แล้วตั้ง `"logoFile": "logo.png"`
- ชื่อห้ามมีอักขระ `\ ' " ` $ < > & { }` (ระบบจะแจ้งตอนเริ่มทำงานถ้าผิด)
- ระบบจะแทนชื่อ "ดินดีฟาร์ม"/"DinDee Farm" ทุกจุดที่ส่งให้ browser (หน้า login, เมนู, ข้อความร้านค้า, ใบเสนอราคา/เอกสารขาย) ส่วนชื่อ ที่อยู่ เบอร์โทร และ QR ของฟาร์มยังตั้งในหน้า "ตั้งค่า" ของแอปได้ตามเดิม
- ถ้าไม่แก้ `config/farm.json` ไฟล์ทุกตัวออกไปเหมือนต้นฉบับทุกไบต์ (มีเทสต์ยืนยัน)

## เพิ่มฟาร์มใหม่ (แยกฐานข้อมูลและพอร์ต)
```bash
node scripts/new-farm.js greengarden "สวนเขียวขจี" "Green Garden Farm" 3001
docker compose -p dindee-greengarden --env-file farms/greengarden/.env up -d --build
```
สคริปต์สร้าง `farms/<slug>/` ที่มี `farm.json` และ `.env` (รหัสฐานข้อมูลสุ่ม รหัส admin เริ่มต้นสุ่ม) แต่ละฟาร์มมี MySQL ของตัวเอง ข้อมูลไม่ปนกัน ให้ nginx ชี้โดเมนของแต่ละฟาร์มไปที่พอร์ตของฟาร์มนั้น
อัปเดตโค้ดให้ทุกฟาร์ม: แทนที่ไฟล์โปรแกรมแล้วสั่ง `up -d --build` ซ้ำของแต่ละฟาร์ม (ข้อมูลอยู่ใน volume ไม่หาย) — **สำรองฐานข้อมูลก่อนทุกครั้ง**

## ใช้งานจริงบนอินเทอร์เน็ต — ควรทำ
1. **ใช้ HTTPS** (nginx + certbot ตัวอย่างใน `deploy/nginx.conf.example`) แล้วตั้ง `COOKIE_SECURE=1` และ `TRUST_PROXY=1` ใน `.env`
2. ปิดพอร์ต MySQL (3306) จากภายนอก — compose นี้ไม่ได้เปิดพอร์ตนี้ให้อยู่แล้ว
3. ตั้งสำรองข้อมูลอัตโนมัติ: `scripts/backup.sh` (cron) หรือ Admin ดาวน์โหลด JSON ที่ `/api/backup`

## ย้ายข้อมูลเดิมจาก browser เข้า MySQL
1. เปิดระบบเดิมใน browser เครื่องที่มีข้อมูล → F12 → Console → วางคำสั่งนี้ (ผลถูกคัดลอกไป clipboard):
   ```js
   copy(JSON.stringify(Object.fromEntries(Object.keys(localStorage).filter(k=>k.startsWith('dindee_v7_')).map(k=>[k.slice(10),localStorage[k]]))))
   ```
2. วางลงไฟล์ `old-data.json` แล้วรัน `node scripts/import-local.js old-data.json`
   (Docker: `docker compose cp old-data.json app:/tmp/ && docker compose exec app node scripts/import-local.js /tmp/old-data.json`)
3. ผู้ใช้/รหัสผ่านเดิมจะใช้ได้ตามเดิม

## ลืมรหัส Admin
`node scripts/reset-admin.js "รหัสใหม่"`  (Docker: `docker compose exec app node scripts/reset-admin.js "รหัสใหม่"`)

## ตรวจว่า Order กับรายรับตรงกัน
รายรับของ Farm Shop ลงบัญชีตอน **รับเงินแล้ว** (เงินสดรับแล้ว หรือยืนยันสลิปแล้ว) ตรวจความสอดคล้องได้ด้วย (อ่านอย่างเดียว ไม่แก้ข้อมูล):
```bash
node scripts/check-ledger.js          # Docker: docker compose exec app node scripts/check-ledger.js
```
หรือ Admin เปิด `/api/ledger-check` ระบบจะรายงาน: รับเงินแล้วแต่ไม่มีรายรับ, ยอดรายรับไม่เท่ายอด Order, มีรายรับทั้งที่ยังไม่รับเงิน, รายรับที่ไม่มี Order, เลข Order ซ้ำ แนะนำให้รันหลังย้ายข้อมูลเดิมเข้า MySQL และเป็นระยะ

## ข้อจำกัดที่ควรรู้
- **บันทึกหลายชุดข้อมูลพร้อมกัน (atomic):** flow ที่แก้หลายชุดในครั้งเดียว เช่น ซื้อของ (stock + purchases + expenses) หรือบันทึกการใช้ของ (stock + usages) จะถูกส่งเป็นคำขอเดียวและบันทึกใน MySQL transaction เดียว สำเร็จทั้งหมดหรือไม่เปลี่ยนอะไรเลย ถ้าเน็ตหลุดระบบเก็บไว้แล้วลองส่งใหม่ทั้งชุด
- **แก้ข้อมูลพร้อมกันหลายเครื่อง:** ถ้าสองเครื่องแก้ชุดข้อมูลเดียวกัน เครื่องที่ช้ากว่าจะเห็นแถบเตือนว่า "ยังไม่มีอะไรในชุดนี้ถูกบันทึก" ให้เลือกโหลดข้อมูลล่าสุด หรือบันทึกทับทั้งชุด จะไม่ทับเงียบ ๆ และไม่มีกรณีบันทึกไปครึ่งเดียว เหมาะกับทีมเล็ก
- **ข้อจำกัดของขั้นนี้:** server รับประกันว่าบันทึกครบหรือไม่บันทึกเลย แต่ยังเชื่อตัวเลขที่ browser คำนวณมา (เช่นยอดสต็อก) ยังไม่ได้ตรวจกฎธุรกิจเองฝั่ง server ยกเว้นการสั่งซื้อของลูกค้าที่ server คำนวณราคาและตัดสต็อกเอง (และยังไม่ปฏิเสธออเดอร์ที่เกินสต็อก) ขั้นถัดไปคือย้ายตรรกะของ Checkout, Purchase และ Usage ไปไว้บน server ทีละ flow
- **Farm Shop สำหรับลูกค้าไม่ล็อกอิน:** ลูกค้าเห็นเฉพาะสินค้า/ตั้งค่าร้าน สั่งซื้อได้ โดย server คำนวณราคาและตัดสต็อกเอง แต่ "Order ของฉัน" (เบอร์โทร+PIN) จะดูได้เฉพาะ Order ที่สั่งจาก browser เครื่องนั้น เพราะไม่เปิดข้อมูลลูกค้าทั้งหมดให้คนทั่วไป (ถ้าต้องการติดตามข้ามเครื่อง ต้องเพิ่ม API ค้นหาฝั่ง server)
- **ไฟล์หลักฐาน (Evidence, โมดูล v10826)** เก็บใน IndexedDB ของแต่ละ browser ยังไม่ได้ย้ายขึ้น server
- **รหัสผ่าน:** server เก็บด้วย scrypt (ปลอดภัยกว่า hash เดิมของระบบมาก) ผู้ใช้เดิมเข้าด้วยรหัสเดิมได้ และระบบอัปเกรดให้เองตอนเข้าสู่ระบบสำเร็จ server **ไม่ส่งรหัส/hash ให้ browser** และไม่เก็บ `plainPass` อีกแล้ว ดังนั้นหน้าจัดการผู้ใช้จะแสดงจุด `••••••` แทนรหัสเดิม (ทำได้แค่ตั้งรหัสใหม่ ดูรหัสเก่าไม่ได้) นอกจากนี้จำกัดการลองรหัสผิด 8 ครั้ง/10 นาที ส่วน PIN ลูกค้า (4 หลัก) ยังตรวจแบบเดิมในหน้าเว็บ
- สคริปต์ `xlsx` โหลดจาก CDN (`cdn.sheetjs.com`) — เซิร์ฟเวอร์ที่ผู้ใช้เปิดต้องออกอินเทอร์เน็ตได้ หรือดาวน์โหลดไฟล์มาไว้ใน `js/` แล้วแก้ `index.html`

## ทดสอบ
`npm test` (ทดสอบ API/ซิงก์ด้วย memory driver ไม่ต้องมี MySQL) และชุดทดสอบเดิมใน `tests/` ผ่านทั้งหมด
