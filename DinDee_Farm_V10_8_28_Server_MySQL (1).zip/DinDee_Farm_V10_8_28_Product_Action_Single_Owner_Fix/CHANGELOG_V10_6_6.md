# V10.6.6 — Monthly Plan Scroll & Readability
Base: V10.6.4 (original green visual theme)
- Kept the V10.6.4 interface instead of the V10.6.5 global UI redesign.
- Changed only Monthly Plan presentation.
- Added a clearly visible horizontal scrollbar for the full month.
- Increased date/text readability.
- Repeated the selected Thai month/year inside every greenhouse header.
- Kept the repeated date row for every greenhouse.
- No production, stock, purchase, sales, customer, notification, finance, or save/delete logic changed.
