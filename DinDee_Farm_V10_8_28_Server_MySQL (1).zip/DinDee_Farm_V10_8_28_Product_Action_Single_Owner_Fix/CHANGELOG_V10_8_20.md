# V10.8.20
- Restored Dashboard Income Share donut, Expense Share donut, and Farm Analytics after the V10.8.17 dashboard replacement regression.
- Preserved V10.8.19 full-width stacked Profit and Latest Transactions layout.
- Expense share uses cash expenses only and does not double-count Direct Cost.
- Restored drill-down from donut categories and Farm Analytics detail button.
