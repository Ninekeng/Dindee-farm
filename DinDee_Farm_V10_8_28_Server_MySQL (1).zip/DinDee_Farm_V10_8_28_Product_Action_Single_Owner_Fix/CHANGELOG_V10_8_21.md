# V10.8.21 — Flow 5 Reports Integration
- Sales Report now reads Farm Shop Orders directly; product/customer/staff summaries no longer depend on standalone Sales Documents.
- Order detail table added to Sales Report; billing/invoice section remains sourced from Sales Documents.
- Human-readable references shown for Farm Shop, Purchase and Manual finance rows while internal IDs remain unchanged.
- Evidence Center adds date/source/search filters, readable references, amount/party columns and in-page preview; it reuses existing attachments and creates no duplicate accounting rows.
- House Report explains linkage rules: revenue/cost are automatic only when source records explicitly carry house/cycle links; no manual duplicate entry is introduced.
- Existing Dashboard, finance transaction center, sales documents, reports and other features are preserved.
