# V10.6.8 — Harvest Controls + Dashboard Borders
- Preserved V10.6.7 Harvest Edit/Delete controls for Admin.
- Added clearer borders and subtle shadows to overview KPI/cards so each dashboard block is visually separated.
- No calculation, production, stock, purchase, sales, customer, notification, or finance logic changed.
