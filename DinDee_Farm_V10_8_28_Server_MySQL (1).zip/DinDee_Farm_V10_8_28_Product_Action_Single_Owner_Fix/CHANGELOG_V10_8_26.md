# V10.8.26
- Fix Product Catalog duplicate delete actions; keep one edit and one delete icon.
- Restore Save button on Product edit after checkout-success modal lifecycle.
- Fix Sales Report date parsing for Thai/Buddhist order timestamps and Completed orders.
- Move Farm Shop payment-slip payloads from LocalStorage orders to IndexedDB evidence storage; migrate legacy slips non-destructively.
- Evidence Center adds Preview and Go to Order; deletion remains at source.
- Checkout stores only slipRef in orders to prevent LocalStorage quota growth.
