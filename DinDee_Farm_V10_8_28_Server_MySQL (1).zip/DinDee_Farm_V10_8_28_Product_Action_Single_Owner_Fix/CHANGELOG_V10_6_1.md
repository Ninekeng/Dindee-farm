# V10.6.1 — Monthly Operations Matrix
- Monthly Plan now expands every active greenhouse into all active Task Types.
- Click a Task Type × Date cell to create a task directly.
- New monthly task dialog supports responsible person, active Crop Cycle, planned material/Lot, planned quantity/unit, and note.
- Existing tasks in a cell can be edited or safe-deleted.
- Cell colors/marks show planned, done, problem, and postponed states.
- Monthly Print is A4 landscape and grouped by greenhouse.
- Print includes date, task type, details, material/Lot, quantity/unit, responsible person, note, and status.
- Actual Usage is preferred in print when recorded; otherwise planned material/quantity is shown.
