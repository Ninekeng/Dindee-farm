const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1084.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.4')&&h.includes('modules/v1084.js'));
ok('delete directly rendered',m.includes("onclick=\"deleteShopCatV1082('${c.id}')\"")&&m.includes('🗑️'));
ok('three actions',m.includes('editShopCatMapV1078')&&m.includes('toggleShopCatV1042')&&m.includes('deleteShopCatV1082'));
ok('safe delete implementation retained',fs.readFileSync('modules/v1082.js','utf8').includes('p.categoryId===cid'));
