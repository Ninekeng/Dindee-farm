const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1081.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.1')&&h.includes('modules/v1081.js'));
ok('general usage',m.includes("['General','งานทั่วไป']")&&m.includes("['House','โรงเรือน / พื้นที่ผลิต']"));
ok('return stock',m.includes('returnUsageV1081')&&m.includes("logAudit('RETURN'"));
ok('cancel restore',m.includes('cancelUsageV1081')&&m.includes("u.status='Cancelled'"));
ok('hard delete admin',m.includes("me?.role!=='Admin'")&&m.includes('hardDeleteUsageV1081'));
ok('hard delete restore',m.includes('if(q)restore(u,q);D.usages=D.usages.filter'));
ok('test mode setting',m.includes('allowHardDeleteUsage')&&m.includes('Test Mode'));
ok('edit stock reconciliation',m.includes('effectiveOld')&&m.includes('effectiveNew'));
