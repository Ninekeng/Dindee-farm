const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1078.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',/V10\.7\.[8-9]/.test(h)&&h.includes('modules/v1078.js'));
for(const x of ['Farm Product Sales','Food & Beverage Income','Learning Center Income','Event Income','Support Income','Other Income'])ok('income master '+x,m.includes("'"+x+"'"));
ok('category mapping UI',m.includes('Income Category')&&m.includes('Income Tag')&&m.includes('editShopCatMapV1078'));
ok('paid order income sync',m.includes('syncShopIncomeV1078')&&m.includes("source:'Farm Shop'"));
ok('mixed basket grouping',m.includes("groups[k]??="));
ok('sales history',m.includes('ประวัติการซื้อขายร้านค้า'));
ok('small edit/delete icons',m.includes('purchase-icon-btn')&&m.includes('✏️')&&m.includes('🗑️'));
ok('delete linked income',m.includes("D.income=D.income.filter(x=>!(x.source==='Farm Shop'&&x.refId===oid))"));
