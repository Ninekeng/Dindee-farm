const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1082.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.2')&&h.includes('modules/v1082.js'));
ok('delete icon',m.includes('🗑️')&&m.includes('deleteShopCatV1082'));
ok('protect linked products',m.includes('p.categoryId===cid')&&m.includes('ยังลบหมวด'));
ok('historical orders untouched',!m.includes('D.orders=D.orders.filter'));
ok('historical income untouched',!m.includes('D.income=D.income.filter'));
ok('audit',m.includes("logAudit('DELETE','Shop Category'"));
