const fs=require('fs'),path=require('path'),root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const idx=read('index.html'),v=read('modules/v1052.js');
const tests=[
 ['v1052 loaded',/modules\/v1052\.js/.test(idx)],
 ['version',/V10\.(5|6|7)\./.test(idx)],
 ['analytics action',/openFarmAnalyticsV1052/.test(v)],
 ['cycle delete UI',/deletePlan\('\$\{p\.id\}'\)/.test(v)],
 ['stock safe delete',/deleteStockV1052/.test(v)&&/ARCHIVE','Stock/.test(v)],
 ['house delete UI',/deleteHouseV1051/.test(v)],
 ['shop delete UI',/deleteProductV1052/.test(v)],
 ['sales doc delete UI',/deleteSalesDocV1051/.test(v)],
 ['sponsor delete UI',/deleteFundV1051/.test(v)],
 ['FEFO FIFO',/FEFO/.test(v)&&/FIFO/.test(v)],
 ['purchase import export',/importPurchaseV1052/.test(v)&&/exportPurchasesV1052/.test(v)&&/downloadPurchaseTemplateV1052/.test(v)],
 ['duplicate check',/ข้อมูลซ้ำกับรายการเดิม/.test(v)]
];
let bad=0;for(const [n,ok] of tests){console.log((ok?'PASS ':'FAIL ')+n);if(!ok)bad++}process.exitCode=bad?1:0;
