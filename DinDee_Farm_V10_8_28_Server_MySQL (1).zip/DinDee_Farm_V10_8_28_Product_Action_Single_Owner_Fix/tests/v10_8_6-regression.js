const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1086.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.6')&&h.includes('modules/v1086.js'));
ok('packed immediate',m.includes("o.status='Packed'")&&m.includes('📦 เตรียมสินค้าเสร็จ'));
ok('no forced photo alert',!m.includes('กรุณาถ่าย/แนบรูป'));
ok('optional photo',m.includes('แนบรูป / หมายเหตุ (ไม่บังคับ)')&&m.includes('if(f)fileData(f,done);else done'));
ok('history retained',m.includes("addHist(o,'Packed'"));
ok('old actions retained',m.includes('oldOrderActions(o)'));
