/* ทดสอบตัวตรวจบัญชี:  node tests/ledger-test.js */
process.env.DB_DRIVER = 'memory'; process.env.PORT = '0'; process.env.HOST = '127.0.0.1'; process.env.ADMIN_PASSWORD = 'pw123456';
const { checkLedger } = require('../server/ledger');
const { start } = require('../server/server');
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL:', m); } else console.log('ok  :', m); };
const types = r => r.issues.map(i => i.type).sort().join(',');
const inc = (ref, amount) => ({ id: 'i' + ref + amount, source: 'Farm Shop', refId: ref, amount });

ok(checkLedger({ orders: [], income: [] }).ok, 'empty data is ok');
ok(checkLedger({ orders: [{ id: 'a', no: 'D1', total: 100, status: 'New' }], income: [] }).ok, 'unpaid order without income is ok (income only when money received)');
ok(checkLedger({ orders: [{ id: 'a', no: 'D1', total: 100, cashReceived: true, status: 'Confirmed' }], income: [inc('a', 100)] }).ok, 'cash received + matching income is ok');
ok(checkLedger({ orders: [{ id: 'a', no: 'D1', total: 100, status: 'Confirmed' }], income: [inc('a', 60), inc('a', 40)] }).ok, 'mixed-basket split rows summing to total is ok');
ok(types(checkLedger({ orders: [{ id: 'a', no: 'D1', total: 100, cashReceived: true }], income: [] })) === 'paid_without_income', 'detects paid order with no income (half-written)');
ok(types(checkLedger({ orders: [{ id: 'a', no: 'D1', total: 100, status: 'Completed' }], income: [inc('a', 90)] })) === 'income_total_mismatch', 'detects total mismatch');
ok(types(checkLedger({ orders: [{ id: 'a', no: 'D1', total: 100, status: 'Payment Submitted' }], income: [inc('a', 100)] })) === 'income_without_payment', 'detects income before payment is accepted');
ok(types(checkLedger({ orders: [], income: [inc('ghost', 5)] })) === 'orphan_income', 'detects orphan income');
ok(types(checkLedger({ orders: [{ id: 'a', no: 'D1', total: 1 }, { id: 'b', no: 'D1', total: 1 }], income: [] })) === 'duplicate_order_no', 'detects duplicate order numbers');
ok(checkLedger({ orders: [{ id: 'a', total: 100, cashReceived: true }], income: [{ source: 'Other', refId: 'a', amount: 1 }, inc('a', 100)] }).ok, 'ignores income from other sources');

(async () => {
  const srv = await start(); const base = 'http://127.0.0.1:' + srv.address().port;
  const j = async (method, url, body, cookie) => { const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}) }, body: body ? JSON.stringify(body) : undefined }); return { s: r.status, b: await r.json().catch(() => ({})), c: (r.headers.get('set-cookie') || '').split(';')[0] }; };
  ok((await j('GET', '/api/ledger-check')).s === 403, '/api/ledger-check needs Admin');
  const admin = (await j('POST', '/api/login', { user: 'admin', pass: 'pw123456' })).c;
  ok(JSON.stringify((await j('GET', '/api/ledger-check', null, admin)).b) === '{"ok":true,"orders":0,"incomeRows":0,"issues":[]}', 'endpoint returns report for Admin');
  await j('POST', '/api/commit', { writes: [{ key: 'orders', value: JSON.stringify([{ id: 'a', no: 'D1', total: 100, cashReceived: true }]), base: null }] }, admin);
  const r = (await j('GET', '/api/ledger-check', null, admin)).b;
  ok(!r.ok && r.issues[0].type === 'paid_without_income', 'endpoint reports a half-written order');
  srv.close(); console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})();
