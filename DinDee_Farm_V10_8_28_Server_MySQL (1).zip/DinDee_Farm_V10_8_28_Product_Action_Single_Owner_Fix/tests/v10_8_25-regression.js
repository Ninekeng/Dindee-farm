const fs=require('fs'),assert=require('assert');
const s=fs.readFileSync('modules/v10825.js','utf8'),idx=fs.readFileSync('index.html','utf8');
assert(s.includes('checkoutBusy'));
assert(s.includes('showCheckoutSuccess'));
assert(s.includes('data-delete-test-order-v10825'));
assert(s.includes("D.orders.splice(idx,1)"));
assert(idx.includes('modules/v10825.js'));
console.log('V10.8.25 regression PASS');
