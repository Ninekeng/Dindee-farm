const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const idx=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'modules','v10814.js'),'utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(idx.includes('modules/v10814.js'),'v10814 not loaded');
ok(idx.includes('V10.8.14'),'version title missing');
ok(js.includes('window.openCartV10814'),'direct cart missing');
ok(js.includes('window.openCheckoutV10814'),'direct checkout missing');
ok(js.includes("()=>window.openCheckoutV10814()"),'cart does not transition directly to v10814 checkout');
ok(js.includes('function activity14'),'local activity helper missing');
ok(!js.includes('isActivity('),'must not reference private v1043 isActivity helper');
ok(js.includes('pinFieldsV10814'),'PIN renderer missing');
ok(js.includes("window.submitCheckoutV104(act?'activity':'farm')"),'existing submit/order pipeline not preserved');
ok(js.includes('if(q<=0)window.cart.splice'),'zero quantity removal missing');
console.log('PASS v10.8.14 regression');
