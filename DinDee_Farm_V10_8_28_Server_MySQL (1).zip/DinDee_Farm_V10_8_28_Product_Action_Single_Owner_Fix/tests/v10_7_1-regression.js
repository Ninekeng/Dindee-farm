const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1071.js','utf8'),v=fs.readFileSync('modules/v104.js','utf8'),a=fs.readFileSync('js/app.js','utf8'),c=fs.readFileSync('css/app.css','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.7\.[1-9]/.test(h));
ok('helper loaded last',h.includes('modules/v1071.js'));
ok('asks before master add',m.includes('ยังไม่มีใน Master')&&m.includes('confirm('));
ok('saves species only after yes',m.includes("D.species.push")&&m.includes("sv('species')"));
ok('new production cycle hooked',v.includes('ensureSpeciesMasterV1071(v104c.value)'));
ok('edit crop cycle hooked',a.includes('ensureSpeciesMasterV1071(p.crop)'));
ok('sidebar compact',c.includes('grid-template-columns:245px minmax(0,1fr)'));
