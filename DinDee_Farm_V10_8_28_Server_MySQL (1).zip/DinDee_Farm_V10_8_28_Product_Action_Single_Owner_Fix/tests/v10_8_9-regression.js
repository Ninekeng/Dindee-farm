const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),a=fs.readFileSync('js/app.js','utf8'),m=fs.readFileSync('modules/v1089.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.9')&&h.includes('modules/v1089.js'));
ok('existing customer pin',m.includes('กรอก PIN เดิม 4 หลัก')&&m.includes("c.pinHash!==hash(pin)"));
ok('new customer pin confirm',m.includes('ตั้ง PIN 4 หลัก')&&m.includes('PIN ยืนยันไม่ตรงกัน'));
ok('customer route guard',a.includes("me&&me.role==='Customer'&&!allowed([page,''])")&&a.includes("if(me&&!allowed([p,'']))"));
ok('customer bell hidden',a.includes("bell.style.display=me?.role==='Customer'?'none':''"));
ok('clear order stepper',m.includes('order-stepper-v1089')&&m.includes('สถานะปัจจุบัน'));
ok('customer purchase menu',a.includes("customerPurchases','🧾 ประวัติการซื้อของลูกค้า")&&a.includes("customerPurchases:'customerPurchaseHistoryV1089'"));
ok('camera preserved',a.includes("['live','📹 Live Farm']"));
ok('analytics reliable opener',m.includes('openFarmAnalyticsV1089')&&m.includes('farmAnalyticsV1045'));
