const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),c=fs.readFileSync('css/app.css','utf8'),m=fs.readFileSync('modules/v1067.js','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.(6\.[8-9]|7\.[0-9])/.test(h));
ok('harvest edit retained',m.includes('editHarvestV1067'));
ok('harvest delete retained',m.includes('deleteHarvestV1067'));
ok('dashboard metric border',c.includes('#content .metric')&&c.includes('border:2px solid #b9d3b8'));
ok('dashboard card border',c.includes('.grid4>.card')&&c.includes('border:2px solid #c6d9c3'));
