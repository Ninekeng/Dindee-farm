'use strict';
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const idx=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'modules','v10819.js'),'utf8');
const css=fs.readFileSync(path.join(root,'css','app.css'),'utf8');
let fail=[];
if(!idx.includes('modules/v10819.js')) fail.push('v10819 not loaded');
for(const x of ['กำไรตามสินค้า / ผลผลิต','รายการล่าสุด','dashboard-stack-v10819']) if(!js.includes(x)) fail.push('missing '+x);
if(!css.includes('grid-template-columns:minmax(0,1fr)')) fail.push('stacked single-column CSS missing');
for(const x of ['modules/v10817.js','modules/v10818.js']) if(!idx.includes(x)) fail.push('previous module missing '+x);
if(fail.length){console.error(fail.join('\n'));process.exit(1)}
console.log('V10.8.19 regression PASS');
