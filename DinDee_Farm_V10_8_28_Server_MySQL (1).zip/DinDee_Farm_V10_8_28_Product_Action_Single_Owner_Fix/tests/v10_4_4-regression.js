const fs=require('fs'),path=require('path');const root=path.resolve(__dirname,'..');
const idx=fs.readFileSync(path.join(root,'index.html'),'utf8'),v=fs.readFileSync(path.join(root,'modules/v1044.js'),'utf8');
function ok(c,m){if(!c)throw new Error(m)}
ok(/V10\.4\.[4-9]/.test(idx),'version compatibility');ok(idx.includes('modules/v1044.js'),'module');ok(!idx.includes('>Reset Admin<'),'unsafe login reset button still visible');
ok(v.includes('window.resetAdminLogin=function'),'reset guard missing');ok(v.includes('conic-gradient'),'pie charts missing');ok(v.includes('Farm Analytics'),'analytics missing');
ok(v.includes('window.workHistoryV1044=function'),'work history missing');ok(v.includes('window.editHistoryV1044=function'),'history edit missing');ok(v.includes('window.deleteHistoryV1044=function'),'history delete missing');
ok(v.includes('window.completeTask=function(taskId){return window.doneTask(taskId)}'),'today completion bridge missing');ok(v.includes('reconcileUsage'),'stock reconciliation missing');ok(v.includes("logAudit('EDIT','Task History'")&&v.includes("logAudit('DELETE','Task History'"),'history audit missing');
console.log('V10.4.4 regression PASS');
