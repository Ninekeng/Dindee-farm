const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),c=fs.readFileSync('css/app.css','utf8'),v=fs.readFileSync('modules/v1062.js','utf8'),a=fs.readFileSync('js/app.js','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.(6\.[6-9]|7\.[0-9])/.test(h));
ok('visible horizontal scrollbar',c.includes('overflow-x:scroll!important'));
ok('full month width',c.includes('min-width:1420px!important'));
ok('month per greenhouse',v.includes('house-month-title')&&v.includes('monthLabel'));
ok('Thai month year',v.includes("Intl.DateTimeFormat('th-TH'"));
ok('date row retained',v.includes('house-day-row'));
ok('customer route retained',a.includes("customers:'customerHistoryV1062'"));
ok('notification retained',a.includes("['alerts','🔔 การแจ้งเตือน']"));
