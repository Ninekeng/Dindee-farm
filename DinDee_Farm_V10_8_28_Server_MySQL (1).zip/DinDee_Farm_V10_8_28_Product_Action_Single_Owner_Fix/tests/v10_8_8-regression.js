const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1088.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.8')&&h.includes('modules/v1088.js'));
ok('today material header',m.includes('วัตถุดิบ / Lot / จำนวน'));
ok('task linked usage',m.includes('u.taskId===tid'));
ok('cancel excluded',m.includes("u.status!=='Cancelled'"));
ok('returned qty net',m.includes('n(u.qty)-n(u.returnedQty)'));
ok('same full history button',m.includes('workHistoryV1056()'));
ok('status and result',m.includes('สถานะงาน')&&m.includes('ผลการทำงาน'));
