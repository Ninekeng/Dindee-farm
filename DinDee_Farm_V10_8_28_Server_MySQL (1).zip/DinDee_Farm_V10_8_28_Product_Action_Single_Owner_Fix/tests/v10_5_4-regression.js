const fs=require('fs');
const m=fs.readFileSync('modules/v1053.js','utf8');
const h=fs.readFileSync('index.html','utf8');
function ok(n,c){if(!c){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version label', /V10\.(5|6|7)\./.test(h));
ok('admin uses lexical me', m.includes("typeof me!=='undefined'") && !m.includes("return window.me&&me.role==='Admin'"));
ok('modal delete insert', m.includes("actions.insertBefore(b, actions.firstElementChild)"));
ok('cycle modal delete', m.includes("wrapEdit('editPlan','deletePlan')"));
ok('stock modal delete', m.includes("deleteStockV1052"));
ok('house modal delete', m.includes("deleteHouseV1051"));
ok('shop modal delete', m.includes("deleteProductV1052"));
ok('sales modal delete', m.includes("deleteSalesDocV1051"));
ok('sponsor modal delete', m.includes("deleteFundV1051"));
