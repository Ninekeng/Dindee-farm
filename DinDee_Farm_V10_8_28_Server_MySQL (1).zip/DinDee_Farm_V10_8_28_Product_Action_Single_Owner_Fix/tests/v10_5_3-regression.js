const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
const m=fs.readFileSync(path.join(root,'modules/v1053.js'),'utf8');
const h=fs.readFileSync(path.join(root,'index.html'),'utf8');
const checks=[
 ['v1053 superseded by v1056',!h.includes('modules/v1053.js')&&h.includes('modules/v1056.js')],
 ['modal delete class',m.includes('v1053-modal-delete')],
 ['cycle modal delete',m.includes("wrapEdit('editPlan','deletePlan')")],
 ['stock modal delete',m.includes("wrapEdit('editStockV1043','deleteStockV1052')")],
 ['house modal delete',m.includes("wrapEdit('editHouseV101','deleteHouseV1051')")],
 ['shop modal delete',m.includes("wrapEdit('editProduct','deleteProductV1052')")],
 ['sales modal delete',m.includes("wrapEdit('editSalesDoc','deleteSalesDocV1051')")],
 ['sponsor modal delete',m.includes("wrapEdit('editFund','deleteFundV1051')")],
 ['version label',/V10\.(5|6|7)\./.test(h)]
];
let fail=0;for(const [n,ok] of checks){console.log((ok?'PASS ':'FAIL ')+n);if(!ok)fail++}process.exit(fail?1:0);
