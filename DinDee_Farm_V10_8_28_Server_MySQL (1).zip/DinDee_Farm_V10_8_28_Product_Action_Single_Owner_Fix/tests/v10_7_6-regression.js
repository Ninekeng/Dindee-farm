const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1076.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.7\.[6-9]/.test(h)&&h.includes('modules/v1076.js'));
ok('course workshop category',m.includes("'คอร์ส / Workshop'"));
ok('activity separate category',m.includes("'กิจกรรม'"));
ok('old course migrates',m.includes("n==='คอร์ส'"));
ok('old activity workshop flagged review',m.includes("p.categoryReview=true"));
ok('learning categories preserve activity QR semantics',m.includes('/คอร์ส|workshop|กิจกรรม/i'));
