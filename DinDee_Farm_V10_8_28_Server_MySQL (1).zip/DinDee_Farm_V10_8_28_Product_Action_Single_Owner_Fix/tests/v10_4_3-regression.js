const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..'),idx=fs.readFileSync(path.join(root,'index.html'),'utf8'),v=fs.readFileSync(path.join(root,'modules/v1043.js'),'utf8');
function ok(c,m){if(!c)throw new Error(m)}
ok(/V10\.4\.[3-9]/.test(idx),'version');ok(idx.includes('modules/v1043.js'),'module');
[
 'window.dashboard=function','window.sponsor=function','window.stock=function','window.usage=function',
 'window.shop=function','window.openCartV1043=function','window.openCheckoutV1043=function','window.orders=function',
 'window.houseCenterV1043=function','window.salesDocsPage=function','window.viewSalesDoc=function'
].forEach(x=>ok(v.includes(x),'missing '+x));
ok(v.includes("e.source!=='Purchase'"),'purchase double-count protection');
ok(v.includes("name:'คอร์ส'")&&v.includes("name:'กิจกรรม / Workshop'"),'shop category split');
ok(v.includes('จัดส่ง - โทรสอบถามก่อน'),'delivery warning');
ok(v.includes('ส่งหลักฐานแล้ว — รอตรวจสอบ'),'payment proof status');
ok(v.includes('minStock')&&v.includes('expiryDate'),'stock warning fields');
ok(v.includes(".sort((a,b)=>(a.expiryDate||'9999').localeCompare"),'FEFO');
ok(v.includes('ดินดีฟาร์ม ออร์แกนิก ชลบุรี')&&v.includes('DinDee Farm Organic Chonburi'),'print farm name');
console.log('V10.4.3 regression PASS');
