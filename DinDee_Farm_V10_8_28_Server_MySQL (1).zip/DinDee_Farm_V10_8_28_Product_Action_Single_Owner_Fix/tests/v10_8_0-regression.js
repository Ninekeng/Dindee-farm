const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1080.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.0')&&h.includes('modules/v1080.js'));
ok('history material edit',m.includes('editWorkMaterialsV1080')&&m.includes('วัตถุดิบ / Lot'));
ok('edit usage',m.includes('editWorkUsageV1080')&&m.includes('v80qty'));
ok('add usage',m.includes('addWorkUsageV1080')&&m.includes('D.usages.push'));
ok('stock restore',m.includes('oldStock.qty=n(oldStock.qty)+n(u.qty)'));
ok('stock deduct',m.includes('newStock.qty=n(newStock.qty)-q'));
ok('task linkage',m.includes('taskId'));
ok('small icon',m.includes('purchase-icon-btn'));
