const fs=require('fs');
const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1061.js','utf8'),c=fs.readFileSync('css/app.css','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('v1061 loaded',h.includes('modules/v1061.js'));
ok('all active task types per house',m.includes('activeTypes()')&&m.includes("types.map(tp=>"));
ok('click date/type cell',m.includes('monthlyCellV1061'));
ok('creates D.tasks',m.includes('D.tasks.push(t)'));
ok('links active crop cycle',m.includes('activeCycle(hid,date)'));
ok('planned material qty note',m.includes('plannedStockId')&&m.includes('plannedQty')&&m.includes('m61note'));
ok('edit delete existing task',m.includes("editTask('${t.id}')")&&m.includes("deleteTaskSafeV1059('${t.id}')"));
ok('detailed print',m.includes('printMonthlyV1061'));
ok('print material lot qty note',m.includes('วัตถุดิบ / Lot')&&m.includes('ปริมาณ')&&m.includes('หมายเหตุ'));
ok('actual usage preferred in print',m.includes("D.usages||[]")&&m.includes('u.taskId===t.id'));
ok('a4 landscape',m.includes('@page{size:A4 landscape'));
ok('matrix styling',c.includes('.monthly-matrix')&&c.includes('.matrix-cell'));
