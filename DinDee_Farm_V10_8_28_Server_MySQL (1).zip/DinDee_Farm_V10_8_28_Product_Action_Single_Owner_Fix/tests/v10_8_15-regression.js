const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const idx=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'modules','v10815.js'),'utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(idx.includes('modules/v10815.js'),'v10815 not loaded');
ok(idx.includes('V10.8.15'),'version title missing');
ok(js.includes('input.oninput=function()'),'customer search must filter in place');
ok(js.includes("tr.style.display=hit?'':'none'"),'customer rows are not filtered in place');
ok(js.includes('deleteTestCustomerOrderV10815'),'test order delete missing');
ok(js.includes("me?.role==='Admin'"),'Admin gate missing');
ok(js.includes('allowHardDeleteUsage'),'Test Mode gate missing');
ok(js.includes('restoreOrderProducts10815(o)'),'product restore missing');
ok(js.includes("x.source==='Farm Shop'&&x.refId===oid"),'linked Farm Shop income cleanup missing');
ok(js.includes("logAudit('HARD DELETE'"),'audit missing');
ok(js.includes('ข้อมูลลูกค้าจะไม่ถูกลบ'),'customer preservation confirmation missing');
console.log('PASS v10.8.15 regression');
