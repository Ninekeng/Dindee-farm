const fs=require('fs'),path=require('path');let fail=[];const root=path.join(__dirname,'..');
const m=fs.readFileSync(path.join(root,'modules/v10821.js'),'utf8'),idx=fs.readFileSync(path.join(root,'index.html'),'utf8');
for(const s of ['window.salesReport=function','D.orders','ยอดขายตามสินค้า','ยอดขายตามพนักงาน','ยอดขายตามลูกค้า','window.evidence=function','เลขอ้างอิง','Preview','friendlyRefV10821','window.houseReport=function'])if(!m.includes(s))fail.push('missing '+s);
if(!idx.includes('modules/v10821.js'))fail.push('module not loaded');
if(fail.length){console.error(fail.join('\n'));process.exit(1)} console.log('V10.8.21 regression PASS');
