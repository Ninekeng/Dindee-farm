const fs=require('fs'); let fail=[];
const p=fs.readFileSync('modules/purchase.js','utf8'),m=fs.readFileSync('modules/master-data.js','utf8'),u=fs.readFileSync('modules/ui-v103.js','utf8');
for(const x of ['supplierId','ensureSupplier','supplierMasterList']) if(!(p+m).includes(x)) fail.push('missing '+x);
if(!u.includes('แผนรายเดือน'))fail.push('monthly label missing');
if(u.includes('แผนดูแล 30 วัน'))fail.push('old label remains in modern sidebar');
if(fail.length){console.error(fail.join('\n'));process.exit(1)} console.log('DinDee V10.3.1 regression: PASS');
