const fs=require('fs');
const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1056.js','utf8'),g=fs.readFileSync('modules/v1060.js','utf8'),c=fs.readFileSync('css/app.css','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('v1060 loaded',h.includes('modules/v1060.js'));
ok('normalizer excludes annual plan',m.includes("edit.closest('.annualCard,.annualTrack,.annualRow')"));
ok('final annual delete guard',g.includes('cleanAnnualDeleteV1060')&&g.includes("oc.includes('deletePlan')"));
ok('settings single column',c.includes('.settings-grid{display:flex!important;flex-direction:column!important'));
ok('settings no internal scroll',c.includes('.settings-grid .tableWrap{overflow:visible!important'));
