/* ทดสอบรหัสผ่าน scrypt / อัปเกรด hash เก่า / ไม่รั่ว plainPass:  node tests/auth-test.js */
const fs = require('fs'), os = require('os'), path = require('path');
const file = path.join(os.tmpdir(), 'dd-auth-' + process.pid + '.json');
const { legacyHash, isScrypt } = require('../server/auth');
// ผู้ใช้เดิมแบบ FNV + plainPass (เหมือนข้อมูลที่ย้ายมาจากระบบเก่า)
fs.writeFileSync(file, JSON.stringify({ kv: { users: { ver: 1, v: JSON.stringify([
  { id: 'a1', user: 'admin', pass: legacyHash('oldadmin'), plainPass: 'oldadmin', role: 'Admin' },
  { id: 'a2', user: 'worker', pass: legacyHash('w0rk'), role: 'Staff' } ]) } }, meta: {} }));
process.env.DB_DRIVER = 'memory'; process.env.DATA_FILE = file; process.env.PORT = '0'; process.env.HOST = '127.0.0.1';
const { start } = require('../server/server');
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL:', m); } else console.log('ok  :', m); };

(async () => {
  const srv = await start(); const base = 'http://127.0.0.1:' + srv.address().port;
  const j = async (method, url, body, cookie) => { const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}) }, body: body ? JSON.stringify(body) : undefined }); const t = await r.text(); let b; try { b = JSON.parse(t); } catch (_) { b = t; } return { s: r.status, b, c: (r.headers.get('set-cookie') || '').split(';')[0] }; };
  const stored = () => JSON.parse(JSON.parse(fs.readFileSync(file, 'utf8')).kv.users.v);
  const boot = async c => { const r = await j('GET', '/api/bootstrap.js', null, c); const w = {}; new Function('window', r.b)(w); return w.__DINDEE__; };

  ok(stored().every(u => !isScrypt(u.pass)), 'precondition: legacy hashes in DB');
  const L1 = await j('POST', '/api/login', { user: 'admin', pass: 'oldadmin' });
  ok(L1.s === 200, 'legacy admin can log in');
  let u = stored();
  ok(isScrypt(u.find(x => x.user === 'admin').pass) && !u.find(x => x.user === 'admin').plainPass, 'admin upgraded to scrypt, plainPass removed from DB');
  ok(!isScrypt(u.find(x => x.user === 'worker').pass), 'other users untouched until they log in');
  ok((await j('POST', '/api/login', { user: 'admin', pass: 'oldadmin' })).s === 200, 'login still works after upgrade');
  ok((await j('POST', '/api/login', { user: 'admin', pass: 'OLDADMIN' })).s === 401, 'wrong password still rejected (scrypt)');
  ok((await j('POST', '/api/login', { user: 'worker', pass: 'w0rk' })).s === 200 && isScrypt(stored().find(x => x.user === 'worker').pass), 'legacy staff logs in and is upgraded');
  const admin = L1.c;

  // Admin ไม่ได้รับ hash/plainPass ใน bootstrap
  const b = await boot(admin);
  ok(JSON.parse(b.state.users).every(x => !('pass' in x) && !('plainPass' in x)), 'bootstrap never sends pass/plainPass (even to Admin)');
  ok(!JSON.stringify(b).includes('scrypt$'), 'no hash anywhere in bootstrap');

  // แอปเดิมเพิ่มผู้ใช้ใหม่: ส่ง pass(FNV) + plainPass
  let users = JSON.parse(b.state.users);
  users.push({ id: 'n1', user: 'newbie', pass: legacyHash('pw-new'), plainPass: 'pw-new', role: 'Staff' });
  let r = await j('PUT', '/api/kv/users', { value: JSON.stringify(users), base: b.vers.users }, admin);
  ok(r.s === 200, 'admin adds user via legacy client payload');
  u = stored();
  ok(isScrypt(u.find(x => x.id === 'n1').pass) && !u.find(x => x.id === 'n1').plainPass, 'new user stored as scrypt, no plainPass');
  ok(isScrypt(u.find(x => x.user === 'admin').pass) && u.length === 3, 'existing passwords preserved when client sent none');
  ok((await j('POST', '/api/login', { user: 'newbie', pass: 'pw-new' })).s === 200, 'new user can log in');

  // เปลี่ยนรหัส
  users = JSON.parse((await boot(admin)).state.users); const nb = users.find(x => x.id === 'n1'); nb.plainPass = 'changed-1'; nb.pass = legacyHash('changed-1');
  r = await j('PUT', '/api/kv/users', { value: JSON.stringify(users), base: null, force: true }, admin);
  ok(r.s === 200 && (await j('POST', '/api/login', { user: 'newbie', pass: 'changed-1' })).s === 200 && (await j('POST', '/api/login', { user: 'newbie', pass: 'pw-new' })).s === 401, 'password change via plainPass works; old password rejected');

  // client ตั้ง hash เองโดยไม่ผ่าน plainPass ไม่ได้ (กันเปลี่ยนรหัสคนอื่นแบบแอบ)
  users = JSON.parse((await boot(admin)).state.users); users.find(x => x.id === 'n1').pass = legacyHash('hacked');
  await j('PUT', '/api/kv/users', { value: JSON.stringify(users), base: null, force: true }, admin);
  ok((await j('POST', '/api/login', { user: 'newbie', pass: 'hacked' })).s === 401 && (await j('POST', '/api/login', { user: 'newbie', pass: 'changed-1' })).s === 200, 'client-supplied hash ignored');

  // ผู้ใช้ใหม่ไม่มีรหัส / ไม่มี Admin
  users = JSON.parse((await boot(admin)).state.users); users.push({ id: 'n2', user: 'nopass', role: 'Staff' });
  ok((await j('PUT', '/api/kv/users', { value: JSON.stringify(users), base: null, force: true }, admin)).s === 400, 'user without password rejected');
  users = JSON.parse((await boot(admin)).state.users).map(x => ({ ...x, role: 'Staff' }));
  ok((await j('PUT', '/api/kv/users', { value: JSON.stringify(users), base: null, force: true }, admin)).s === 400, 'cannot demote last Admin');

  // ลบผู้ใช้
  users = JSON.parse((await boot(admin)).state.users).filter(x => x.id !== 'n1');
  ok((await j('PUT', '/api/kv/users', { value: JSON.stringify(users), base: null, force: true }, admin)).s === 200 && !stored().some(x => x.id === 'n1'), 'delete user works');

  // version conflict ของ users
  const bv = await boot(admin);
  ok((await j('PUT', '/api/kv/users', { value: JSON.stringify(JSON.parse(bv.state.users)), base: 1 }, admin)).s === 409, 'stale users write -> 409');

  srv.close(); fs.unlinkSync(file); console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
