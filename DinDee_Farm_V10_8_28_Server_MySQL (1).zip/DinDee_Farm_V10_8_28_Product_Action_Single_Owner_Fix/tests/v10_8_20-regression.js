'use strict';
const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
const idx=fs.readFileSync(path.join(root,'index.html'),'utf8'),js=fs.readFileSync(path.join(root,'modules','v10820.js'),'utf8');
let fail=[];
for(const x of ['modules/v10819.js','modules/v10820.js']) if(!idx.includes(x))fail.push('missing '+x);
for(const x of ['สัดส่วนรายรับ','สัดส่วนรายจ่าย','Farm Analytics','กำไรตามสินค้า / ผลผลิต','cashExpenses','ไม่รวม Direct Cost ซ้ำ'])if(!js.includes(x))fail.push('missing '+x);
if(idx.indexOf('modules/v10820.js')<idx.indexOf('modules/v10819.js'))fail.push('v10820 must load after v10819');
if(fail.length){console.error(fail.join('\n'));process.exit(1)} console.log('V10.8.20 regression PASS');
