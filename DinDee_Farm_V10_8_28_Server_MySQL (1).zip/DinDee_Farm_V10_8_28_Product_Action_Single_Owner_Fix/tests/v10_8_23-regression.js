const fs=require('fs'),vm=require('vm');
const s=fs.readFileSync(__dirname+'/../modules/v10822.js','utf8');
let pass=0,fail=0;
function ok(x,m){if(!x){console.error('FAIL',m);fail++}else{console.log('PASS',m);pass++}}
ok(!s.includes('dataFile(vprodImg,save)'), 'Add Product no longer calls private dataFile helper');
ok(s.includes("let f=vprodImg.files?.[0];if(f)fileData(f,save);else save('')"), 'Add Product handles optional image with global fileData');
ok(s.includes('ราคาขาย (บาท/หน่วย)'), 'Product price label clarifies per-unit price');
ok(s.includes("farm:'🌱 ผลผลิตจากฟาร์ม'"), 'Farm source preserved');
ok(s.includes("purchase:'📦 สินค้าซื้อมาเพื่อขาย'"), 'Purchase source preserved');
ok(s.includes("processed:'🍳 สินค้าแปรรูป / อาหาร'"), 'Processed source preserved');
ok(s.includes("other:'🛍️ สินค้าอื่น ๆ'"), 'Other source preserved');
console.log(`V10.8.23 regression: ${pass} passed, ${fail} failed`); process.exit(fail?1:0);
