const fs=require('fs'),path=require('path'); const root=path.join(__dirname,'..');
const idx=fs.readFileSync(path.join(root,'index.html'),'utf8'), m=fs.readFileSync(path.join(root,'modules/v1045.js'),'utf8');
const req=['modules/v1044.js','modules/v1045.js']; for(const x of req)if(!idx.includes(x))throw Error('missing '+x);
for(const x of ['farmAnalyticsV1045','showHouseAnalyticsV1045','openKnowledgeEditorV1045','deleteKnowledgeV1045','เปรียบเทียบประสิทธิภาพแต่ละโรงเรือน','กำไรตามพืช / Crop Cycle','Stock Analysis','Sponsor Analysis','คอร์ส / กิจกรรม / Workshop'])if(!m.includes(x))throw Error('missing '+x);
if(!m.includes("const previousDashboard=window.dashboard"))throw Error('dashboard compatibility wrapper missing');
console.log('V10.4.5 regression PASS');
