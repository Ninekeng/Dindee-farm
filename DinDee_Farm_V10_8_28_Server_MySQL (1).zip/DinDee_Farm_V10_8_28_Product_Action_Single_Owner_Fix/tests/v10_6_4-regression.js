const fs=require('fs');const a=fs.readFileSync('js/app.js','utf8'),u=fs.readFileSync('modules/ui-v1032.js','utf8'),v=fs.readFileSync('modules/v1062.js','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('customer permanent menu',a.includes("['customers','👥 ฐานข้อมูลลูกค้า']"));
ok('customer core route',a.includes("customers:'customerHistoryV1062'"));
ok('staff customer access',a.includes("'orders','customers','live'"));
ok('standard customer label',u.includes("customers:'ฐานข้อมูลลูกค้า'"));
ok('sales group customer',u.includes("customers:'การขาย'"));
ok('customer page',v.includes('window.customerHistoryV1062=function'));
ok('search edit delete',v.includes('ค้นหาชื่อ / เบอร์โทร / ที่อยู่')&&v.includes('editCustomerV1062')&&v.includes('deleteCustomerV1062'));
ok('purchase history',v.includes('ประวัติการซื้อ'));
