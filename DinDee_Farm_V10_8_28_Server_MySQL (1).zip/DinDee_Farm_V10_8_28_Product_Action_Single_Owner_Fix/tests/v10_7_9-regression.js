const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1079.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',/V10\.(7\.9|8\.0)/.test(h)&&h.includes('modules/v1079.js'));
ok('mapping label',m.includes('หมวดสินค้า &amp; Income Mapping'));
ok('mapping handler preserved',m.includes('const oldShopAdmin=window.shopadmin')&&m.includes('oldShopAdmin()'));
