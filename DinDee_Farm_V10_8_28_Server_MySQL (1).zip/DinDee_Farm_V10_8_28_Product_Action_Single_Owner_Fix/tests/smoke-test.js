const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const js=fs.readFileSync('js/app.js','utf8');
const requiredRoutes=["dashboard", "alerts", "today", "plan30", "usage", "stock", "year", "cycles", "harvest", "houses", "houseReport", "knowledge", "shopadmin", "orders", "shop", "track", "live", "purchase", "directcost", "finance", "sponsor", "settings", "auditPage", "evidence", "users", "exportPage"];
const requiredFunctions=['dashboard','todayPage','plan30','usage','stock','cycles','houseReport','purchase','directcost','finance','sponsor','settings','auditPage','users','exportPage'];
let fail=[];
if(!html.includes('css/app.css')) fail.push('CSS link missing');
if(!html.includes('js/app.js')) fail.push('app.js link missing');
for(const r of requiredRoutes){ if(!js.includes("'"+r+"'") && !js.includes(r+":")) fail.push('route missing: '+r); }
for(const f of requiredFunctions){ if(!new RegExp('function\\s+'+f+'\\s*\\(').test(js)) fail.push('function missing: '+f); }
for(const txt of ['กำไรตามสินค้า / ผลผลิต','รายการล่าสุด','Print Report','Audit / Traceability','Sponsor']) if(!js.includes(txt)) fail.push('feature marker missing: '+txt);
if(fail.length){console.error(fail.join('\n'));process.exit(1)}
console.log('DinDee V10 static smoke test: PASS');
