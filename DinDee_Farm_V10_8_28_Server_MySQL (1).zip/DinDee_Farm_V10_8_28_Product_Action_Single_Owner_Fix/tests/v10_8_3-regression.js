const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1083.js','utf8'),c=fs.readFileSync('css/app.css','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.3')&&h.includes('modules/v1083.js'));
ok('unified popup',m.includes('editWorkHistoryV1083')&&m.includes('วัตถุดิบที่ใช้จริง'));
ok('all work fields',m.includes('v83date')&&m.includes('v83house')&&m.includes('v83cycle')&&m.includes('v83owner')&&m.includes('v83status')&&m.includes('v83remark'));
ok('material management in popup',m.includes('editWorkUsageV1080')&&m.includes('addWorkUsageV1080')&&m.includes('returnUsageV1081'));
ok('material table display only',m.includes("cells[6].innerHTML=taskUsages(t.id).map(stockLabel)"));
ok('compact actions',m.includes('purchase-icon-btn')&&c.includes('.compact-work-actions-v1083'));
