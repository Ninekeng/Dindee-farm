/* ทดสอบ white-label (ชื่อฟาร์ม/โลโก้จาก config):  node tests/brand-test.js */
const fs = require('fs'), os = require('os'), path = require('path'), vm = require('vm');
const { spawn } = require('child_process');
const ROOT = path.resolve(__dirname, '..');
const { loadBrand } = require('../server/brand');
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL:', m); } else console.log('ok  :', m); };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'dd-brand-'));
const writeCfg = (name, o, extra = {}) => { const d = path.join(tmp, name); fs.mkdirSync(d, { recursive: true }); fs.writeFileSync(path.join(d, 'farm.json'), JSON.stringify(o)); Object.entries(extra).forEach(([f, b]) => fs.writeFileSync(path.join(d, f), b)); return d; };
const files = ['index.html', ...fs.readdirSync(path.join(ROOT, 'js')).map(f => 'js/' + f), ...fs.readdirSync(path.join(ROOT, 'modules')).filter(f => f.endsWith('.js')).map(f => 'modules/' + f)];
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const clean = k => { for (const e of Object.keys(process.env)) if (e.startsWith('FARM_')) delete process.env[e]; };

(async () => {
  // 1) default config = identity (ไม่แตะไฟล์ใด ๆ)
  clean(); process.env.FARM_CONFIG_DIR = path.join(ROOT, 'config');
  let b = loadBrand(ROOT);
  ok(b.identity, 'default config is identity');
  ok(files.every(f => b.transform(read(f), f) === read(f)), 'default: every file served byte-identical');

  // 2) custom farm: ทุกไฟล์ต้องไม่เหลือชื่อเดิม และ JS ต้อง parse ได้
  process.env.FARM_CONFIG_DIR = writeCfg('green', { nameTh: 'สวนเขียวขจี', nameEn: 'Green Garden Farm', logoEmoji: '🥬' });
  b = loadBrand(ROOT);
  ok(!b.identity && b.config.shortName === 'Green' && b.config.fullNameTh === 'สวนเขียวขจี' && b.config.fullNameEn === 'Green Garden Farm', 'derived short/full names from nameTh/nameEn');
  let leftovers = [], syntax = [];
  for (const f of files) {
    const t = b.transform(read(f), f);
    if (/ดินดีฟาร์ม|DinDee Farm/.test(t)) leftovers.push(f);
    if (f.endsWith('.js')) { try { new vm.Script(t, { filename: f }); } catch (e) { syntax.push(f + ': ' + e.message); } }
  }
  ok(!leftovers.length, 'no old farm name left in any served file' + (leftovers.length ? ': ' + leftovers.slice(0, 3) : ''));
  ok(!syntax.length, 'every transformed JS still parses' + (syntax.length ? ': ' + syntax[0] : ''));
  const idx = b.transform(read('index.html'), 'index.html');
  ok(idx.includes('<div class="farm-mark">🥬</div>') && idx.includes('<div class="brand">🥬 <span>Green</span></div>'), 'index: logo emoji + short name replaced');
  ok(idx.includes('<title>สวนเขียวขจี V10.8.15</title>') && idx.includes('Green Garden Farm Management'), 'index: title + login text replaced');
  const v104 = b.transform(read('modules/v104.js'), 'modules/v104.js');
  ok(v104.includes("farmName:'สวนเขียวขจี'") && v104.includes("farmNameEn:'Green Garden Farm'"), 'default farmProfile uses new names');
  ok(b.transform(read('js/app.js'), 'js/app.js').includes('Green Garden Farm Shop'), 'shop banner uses new name');

  // 3) ชื่ออีกแบบ (full name แยก) + env override
  process.env.FARM_CONFIG_DIR = writeCfg('full', { nameTh: 'บ้านสวนสุข', nameEn: 'Suan Suk', fullNameTh: 'บ้านสวนสุข ออร์แกนิก สระบุรี', fullNameEn: 'Suan Suk Organic Saraburi', shortName: 'SuanSuk' });
  b = loadBrand(ROOT);
  ok(b.transform(read('modules/v104.js'), 'modules/v104.js').includes("farmName:'บ้านสวนสุข ออร์แกนิก สระบุรี'"), 'full name replaces the long default name (single pass, no double replace)');
  process.env.FARM_NAME_EN = 'Env Farm'; b = loadBrand(ROOT);
  ok(b.config.nameEn === 'Env Farm', 'env var overrides farm.json'); clean();

  // 4) ค่าไม่ปลอดภัยต้องถูกปฏิเสธ
  for (const bad of ["Mae's Farm", 'A"B', 'x<y', 'a`b', 'a$b', 'a\\b', 'a&b', '']) {
    process.env.FARM_CONFIG_DIR = writeCfg('bad', { nameTh: 'ดี', nameEn: bad || 'ok', shortName: bad === '' ? '' : 'ok', logoEmoji: bad === '' ? '' : '🌿' });
    let threw = false; try { loadBrand(ROOT); } catch (_) { threw = true; }
    if (bad) ok(threw, 'rejects unsafe name: ' + JSON.stringify(bad)); 
  }
  process.env.FARM_CONFIG_DIR = writeCfg('badjson', {}); fs.writeFileSync(path.join(process.env.FARM_CONFIG_DIR, 'farm.json'), '{oops');
  let t2 = false; try { loadBrand(ROOT); } catch (e) { t2 = /JSON/.test(e.message); } ok(t2, 'malformed farm.json gives clear error');
  process.env.FARM_CONFIG_DIR = writeCfg('trav', { logoFile: '../../etc/passwd' }); t2 = false; try { loadBrand(ROOT); } catch (_) { t2 = true; } ok(t2, 'logoFile path traversal rejected');

  // 5) end-to-end: เปิด server จริง + โลโก้
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGNgYGD4DwABBAEAX+XDSwAAAABJRU5ErkJggg==', 'base64');
  const dir = writeCfg('e2e', { nameTh: 'ฟาร์มทดสอบ', nameEn: 'Test Farm', logoFile: 'logo.png' }, { 'logo.png': png });
  const port = 3900 + (process.pid % 90);
  const child = spawn(process.execPath, [path.join(ROOT, 'server/server.js')], { env: { ...process.env, DB_DRIVER: 'memory', PORT: String(port), HOST: '127.0.0.1', FARM_CONFIG_DIR: dir, ADMIN_PASSWORD: 'x12345' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = ''; child.stdout.on('data', d => out += d); child.stderr.on('data', d => out += d);
  for (let i = 0; i < 50 && !/พร้อมใช้งาน/.test(out); i++) await new Promise(r => setTimeout(r, 100));
  try {
    ok(/Test Farm พร้อมใช้งาน/.test(out), 'server starts with custom brand');
    const base = 'http://127.0.0.1:' + port;
    const html = await (await fetch(base + '/')).text();
    ok(html.includes('Test Farm') && !html.includes('DinDee Farm') && html.includes('<img src="brand/logo"'), 'served index.html is branded with logo image');
    const js = await (await fetch(base + '/js/app.js')).text();
    ok(!/ดินดีฟาร์ม|DinDee Farm/.test(js), 'served app.js is branded');
    const lg = await fetch(base + '/brand/logo');
    ok(lg.status === 200 && lg.headers.get('content-type') === 'image/png' && Buffer.from(await lg.arrayBuffer()).equals(png), '/brand/logo serves the logo');
    const r1 = await fetch(base + '/js/app.js'); const et = r1.headers.get('etag');
    ok((await fetch(base + '/js/app.js', { headers: { 'if-none-match': et } })).status === 304, 'ETag/304 works with branding');
    const gz = await fetch(base + '/js/app.js', { headers: { 'accept-encoding': 'gzip' } });
    ok(gz.headers.get('content-encoding') === 'gzip' && (await gz.text()).includes('Test Farm'), 'gzip + branding together');
  } finally { child.kill(); }

  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
