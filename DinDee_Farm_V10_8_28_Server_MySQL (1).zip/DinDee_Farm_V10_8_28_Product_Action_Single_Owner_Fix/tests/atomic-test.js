/* ทดสอบการบันทึกหลายชุดแบบ atomic (server /api/commit + ตัวรวมชุดฝั่ง browser):  node tests/atomic-test.js */
process.env.DB_DRIVER = 'memory'; process.env.PORT = '0'; process.env.HOST = '127.0.0.1'; process.env.ADMIN_PASSWORD = 'pw123456';
const vm = require('vm'), fs = require('fs'), path = require('path');
const { start, hash } = require('../server/server');
const SYNC = fs.readFileSync(path.join(__dirname, '../js/server-sync.js'), 'utf8');
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL:', m); } else console.log('ok  :', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const srv = await start(); const base = 'http://127.0.0.1:' + srv.address().port;
  const j = async (method, url, body, cookie) => { const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}) }, body: body ? JSON.stringify(body) : undefined }); const t = await r.text(); let b; try { b = JSON.parse(t); } catch (_) { b = t; } return { s: r.status, b, c: (r.headers.get('set-cookie') || '').split(';')[0] }; };
  const boot = async c => { const r = await j('GET', '/api/bootstrap.js', null, c); const w = {}; new Function('window', r.b)(w); return w.__DINDEE__; };
  const login = async (u, p) => (await j('POST', '/api/login', { user: u, pass: p })).c;
  const admin = await login('admin', 'pw123456');
  const commit = (writes, cookie = admin) => j('POST', '/api/commit', { writes }, cookie);
  const S = (...a) => JSON.stringify(a);

  /* ---------- server ---------- */
  const V0 = (await boot(admin)).vers;                       // stock ถูก seed ไว้แล้วตอนเริ่มระบบ
  let r = await commit([{ key: 'stock', value: S({ id: 's1', qty: 10 }), base: V0.stock }, { key: 'purchases', value: S({ id: 'p1' }), base: null }, { key: 'expenses', value: S({ id: 'e1', amount: 500 }), base: null }]);
  ok(r.s === 200 && r.b.vers.stock === V0.stock + 1 && r.b.vers.purchases === 1 && r.b.vers.expenses === 1, '3 collections committed together (1 existing + 2 new)');
  let st = await boot(admin);
  ok(['stock', 'purchases', 'expenses'].every(k => k in st.state), 'all three visible after commit');

  r = await commit([{ key: 'stock', value: S({ id: 's1', qty: 15 }), base: st.vers.stock }, { key: 'purchases', value: S({ id: 'p1' }, { id: 'p2' }), base: st.vers.purchases }, { key: 'expenses', value: S({ id: 'e1' }, { id: 'e2' }), base: st.vers.expenses }]);
  ok(r.s === 200, 'multi-update with correct bases');

  // atomic: expenses เวอร์ชันเก่า -> ทั้งชุดต้องไม่ถูกบันทึก (stock ต้องไม่ขยับ)
  const before = await boot(admin);
  r = await commit([{ key: 'stock', value: S({ id: 's1', qty: 99 }), base: before.vers.stock }, { key: 'purchases', value: S({ id: 'pX' }), base: before.vers.purchases }, { key: 'expenses', value: S({ id: 'eX' }), base: before.vers.expenses - 1 /* stale */ }]);
  const after = await boot(admin);
  ok(r.s === 409 && r.b.conflicts.length === 1 && r.b.conflicts[0].key === 'expenses', '409 names only the conflicting key');
  ok(after.state.stock === before.state.stock && after.state.purchases === before.state.purchases && after.state.expenses === before.state.expenses && after.vers.stock === before.vers.stock, 'conflict => NOTHING written (no half-saved data)');

  r = await commit([{ key: 'stock', value: S({ id: 's1', qty: 99 }), base: before.vers.stock }, { key: 'expenses', value: S({ id: 'eX' }), base: 0, force: true }]);
  ok(r.s === 200, 'force overrides the stale base');
  r = await commit([{ key: 'stock', value: S(), base: null }]);
  ok(r.s === 409, 'existing key with base=null is a conflict');

  // validation: ชุดเดียวผิดต้องล้มทั้งชุด
  const v0 = (await boot(admin)).vers;
  ok((await commit([{ key: 'stock', value: S(1), base: v0.stock }, { key: 'purchases', value: 'not json', base: v0.purchases }])).s === 400, 'invalid JSON in one write => 400');
  ok((await commit([{ key: 'stock', value: S(1) }, { key: 'stock', value: S(2) }])).s === 400, 'duplicate keys => 400');
  ok((await commit([{ key: 'bad key!', value: S() }])).s === 400, 'bad key => 400');
  ok((await commit([])).s === 400, 'empty writes => 400');
  ok((await commit(Array.from({ length: 41 }, (_, i) => ({ key: 'k' + i, value: S() })))).s === 400, '>40 writes => 400');
  ok(JSON.stringify((await boot(admin)).vers) === JSON.stringify(v0), 'rejected requests changed nothing');

  // ลบ + เขียนใน transaction เดียว
  r = await commit([{ key: 'expenses', del: true }, { key: 'stock', value: S({ id: 's1', qty: 1 }), base: v0.stock }]);
  st = await boot(admin);
  ok(r.s === 200 && !('expenses' in st.state) && JSON.parse(st.state.stock)[0].qty === 1, 'delete + write in one commit');
  ok((await commit([{ key: 'users', del: true }])).s === 400, 'cannot delete users');

  // users ใน batch: plainPass -> scrypt, ล้มทั้งชุดถ้าไม่เหลือ Admin
  let users = JSON.parse(st.state.users); const uv = st.vers.users, sv = st.vers.stock;
  users.push({ id: 'u9', user: 'bob', pass: hash('b0b'), plainPass: 'b0b', role: 'Staff' });
  r = await commit([{ key: 'users', value: JSON.stringify(users), base: uv }, { key: 'stock', value: S({ id: 's1', qty: 7 }), base: sv }]);
  ok(r.s === 200 && (await login('bob', 'b0b')).startsWith('dd_sid='), 'users + stock committed; new user can log in (scrypt)');
  st = await boot(admin);
  const demoted = JSON.parse(st.state.users).map(u => ({ ...u, role: 'Staff' }));
  const sv2 = st.vers.stock;
  r = await commit([{ key: 'stock', value: S({ id: 's1', qty: 555 }), base: sv2 }, { key: 'users', value: JSON.stringify(demoted), base: st.vers.users }]);
  ok(r.s === 400 && (await boot(admin)).vers.stock === sv2, 'users rule violation rolls back the OTHER writes too');

  // สิทธิ์
  const staff = await login('bob', 'b0b');
  ok((await j('POST', '/api/commit', { writes: [{ key: 'stock', value: S() , base: null}] })).s === 401, 'guest cannot commit');
  r = await commit([{ key: 'stock', value: S({ id: 's1', qty: 321 }), base: (await boot(admin)).vers.stock }], staff);
  ok(r.s === 200, 'Staff can commit');
  const pre = await boot(admin);
  ok((await commit([{ key: 'stock', value: S({ qty: 1 }), base: pre.vers.stock }, { key: 'purchases', del: true }], staff)).s === 403, 'Staff batch containing a delete => 403');
  ok((await commit([{ key: 'stock', value: S({ qty: 1 }), base: pre.vers.stock }, { key: 'users', value: '[]', base: 1 }], staff)).s === 403, 'Staff batch containing users => 403');
  ok(JSON.stringify((await boot(admin)).vers) === JSON.stringify(pre.vers), '403 batches changed nothing');
  await j('PUT', '/api/kv/users', { value: JSON.stringify([...JSON.parse((await boot(admin)).state.users), { id: 'u10', user: 'view', plainPass: 'v1ew', role: 'Sponsor Viewer' }]), base: null, force: true }, admin);
  ok((await commit([{ key: 'stock', value: S(), base: 1 }], await login('view', 'v1ew'))).s === 403, 'Sponsor Viewer cannot commit');

  // guest checkout: orders + products เปลี่ยนพร้อมกัน
  await commit([{ key: 'products', value: JSON.stringify([{ id: 'p1', name: 'ผัก', price: 40, qty: 10, unit: 'kg', status: 'พร้อมขาย' }]), base: (await boot(admin)).vers.products ?? null }]);
  const pv = (await boot(admin)).vers;
  r = await j('PUT', '/api/kv/orders', { value: JSON.stringify([{ id: 'g1', no: 'D0001', items: [{ productId: 'p1', qty: 3 }], paymentMethod: 'cash' }]) });
  const a2 = await boot(admin);
  ok(r.b.merged === 1 && a2.vers.orders > (pv.orders || 0) && a2.vers.products === pv.products + 1 && JSON.parse(a2.state.products)[0].qty === 7, 'guest checkout wrote orders AND products together (qty 10->7)');

  /* ---------- browser: ตัวรวมชุด ---------- */
  function makeClient(cookie, bootJs) {
    class Storage { setItem(k, v) { this[k] = String(v); } getItem(k) { return Object.prototype.hasOwnProperty.call(this, k) ? this[k] : null; } removeItem(k) { delete this[k]; } }
    const ls = new Storage(), bar = { style: {}, innerHTML: '' }, calls = [], listeners = {}, ctl = { fail: false };
    const win = { localStorage: ls, Storage, addEventListener() {}, setTimeout, clearTimeout, setInterval: () => 0 }; win.window = win;
    const ctx = vm.createContext({ window: win, Storage, localStorage: ls, setTimeout, clearTimeout, setInterval: () => 0, console, JSON, Object, Map, Set, Promise, String, Math, Array, Date,
      document: { body: { appendChild() {} }, createElement: () => bar, addEventListener(t, f) { (listeners[t] = listeners[t] || []).push(f); }, hidden: false }, location: { reload() { calls.push('RELOAD'); } },
      fetch: (u, o = {}) => { calls.push(u + ' ' + (o.method || 'GET')); if (ctl.fail) return Promise.reject(new Error('offline')); return fetch(base + '/' + u, { ...o, headers: { ...(o.headers || {}), cookie } }); } });
    vm.runInContext(bootJs, ctx); vm.runInContext(SYNC, ctx);
    const click = a => (listeners.click || []).forEach(f => f({ target: { closest: () => ({ getAttribute: () => a }) } }));
    return { ls, win, bar, calls, ctl, click, commits: () => calls.filter(c => c === 'api/commit POST').length };
  }
  const bj = async c => (await j('GET', '/api/bootstrap.js', null, c)).b;

  let c = makeClient(admin, await bj(admin));
  // จำลอง flow ซื้อของ: sv('stock'); sv('purchases'); sv('expenses') ติดกัน -> ต้องเป็นคำขอเดียว
  c.ls.setItem('dindee_v7_stock', S({ id: 's1', qty: 100 }));
  c.ls.setItem('dindee_v7_purchases', S({ id: 'pA' }));
  c.ls.setItem('dindee_v7_expenses', S({ id: 'eA', amount: 1 }));
  await sleep(1100);
  ok(c.commits() === 1, 'three writes in one flow => exactly ONE /api/commit request (got ' + c.commits() + ')');
  const sA = await boot(admin);
  ok(JSON.parse(sA.state.stock)[0].qty === 100 && JSON.parse(sA.state.purchases)[0].id === 'pA' && JSON.parse(sA.state.expenses)[0].id === 'eA', 'all three arrived on server');
  ok(c.win.DinDeeSync.pending() === 0, 'queue empty after commit');

  // อีกเครื่องแก้ expenses ก่อน -> เครื่องนี้ส่ง stock+expenses -> ทั้งคู่ต้องไม่ถูกบันทึก
  const other = makeClient(admin, await bj(admin));
  other.ls.setItem('dindee_v7_expenses', S({ id: 'eA' }, { id: 'eOther' })); await sleep(900);
  const mid = await boot(admin);
  c.ls.setItem('dindee_v7_stock', S({ id: 's1', qty: 42 }));
  c.ls.setItem('dindee_v7_expenses', S({ id: 'eA' }, { id: 'eMine' }));
  await sleep(900);
  const after2 = await boot(admin);
  ok(/ยังไม่มีอะไรในชุดนี้ถูกบันทึก/.test(c.bar.innerHTML), 'conflict banner says nothing in the batch was saved');
  ok(after2.state.stock === mid.state.stock && after2.state.expenses === mid.state.expenses, 'server unchanged: stock NOT saved without its expenses (atomic)');
  c.click('force'); await sleep(900);
  const forced = await boot(admin);
  ok(JSON.parse(forced.state.stock)[0].qty === 42 && JSON.parse(forced.state.expenses).some(x => x.id === 'eMine'), '"force" saves the whole batch together');
  ok(c.win.DinDeeSync.pending() === 0, 'queue drained after force');

  // เครือข่ายล้ม: ไม่ทำข้อมูลหาย เก็บไว้ลองใหม่ทั้งชุดแล้วสำเร็จพร้อมกัน
  const flaky = makeClient(admin, await bj(admin)); flaky.ctl.fail = true;
  const fb = await boot(admin);
  flaky.ls.setItem('dindee_v7_stock', S({ id: 's1', qty: 7 })); flaky.ls.setItem('dindee_v7_purchases', S({ id: 'pNet' }));
  await sleep(900);
  ok(flaky.win.DinDeeSync.pending() === 2 && /ลองใหม่/.test(flaky.bar.innerHTML), 'network down: both writes kept pending, user warned');
  ok((await boot(admin)).state.stock === fb.state.stock, 'network down: server unchanged');
  flaky.ctl.fail = false; await sleep(2200);
  const fa = await boot(admin);
  ok(flaky.win.DinDeeSync.pending() === 0 && JSON.parse(fa.state.stock)[0].qty === 7 && JSON.parse(fa.state.purchases)[0].id === 'pNet', 'network back: retried and BOTH saved together');

  srv.close(); console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
