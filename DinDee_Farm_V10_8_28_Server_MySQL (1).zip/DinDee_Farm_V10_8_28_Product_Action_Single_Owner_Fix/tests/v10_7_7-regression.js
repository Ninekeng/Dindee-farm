const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1077.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',/V10\.7\.[7-9]/.test(h)&&h.includes('modules/v1077.js'));
for(const x of ['Farm Product Sales','Food & Beverage Income','Learning Center Income','Event Income','Support Income','Other Income'])ok('master '+x,m.includes("'"+x+"'"));
ok('dashboard breakdown',m.includes('รายได้แยกตามหมวด'));
ok('workshop mapping',m.includes("['Learning Center Income','Workshop Income']"));
ok('activity mapping',m.includes("['Learning Center Income','Activity Income']"));
ok('farm shop repair',m.includes("x.source!=='Farm Shop'")&&m.includes('x.category=m.category'));
