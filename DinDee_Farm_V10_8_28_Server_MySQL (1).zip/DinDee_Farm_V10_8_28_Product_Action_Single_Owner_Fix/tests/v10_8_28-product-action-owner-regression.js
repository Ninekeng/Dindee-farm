const fs=require('fs'),path=require('path');const root=path.resolve(__dirname,'..');
function read(f){return fs.readFileSync(path.join(root,f),'utf8')} function ok(c,s){if(!c)throw new Error(s)}
const a=read('modules/v1051.js'),b=read('modules/v1052.js'),c=read('modules/v1056.js');
ok(!a.includes('v1051-del-product'),'v1051 must not inject Product delete');
ok(b.includes('v1052-del-product')&&b.includes('deleteProductV1052'),'v1052 must own Product delete');
ok(!c.includes('v1056-del-product'), 'v1056 must not recreate Product delete asynchronously');
console.log('V10.8.28 Product action single-owner regression PASS');
