const fs=require('fs');
const ui=fs.readFileSync('modules/ui-v1032.js','utf8');
const index=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('css/app.css','utf8');
let fail=[];
for(const s of ['แผนรายเดือน','คลังสินค้า (Stock)','ซื้อวัตถุดิบ','รายรับ–รายจ่าย','ศูนย์รายงาน','ตั้งค่าระบบ','ผู้ใช้งานและสิทธิ์']) if(!ui.includes(s)) fail.push('missing standard name '+s);
if(!index.includes('modules/ui-v1032.js')) fail.push('ui-v1032 not loaded');
if(!css.includes('V10.3.2 Professional UI')) fail.push('professional CSS missing');
if(fail.length){console.error(fail.join('\n'));process.exit(1)}
console.log('DinDee V10.3.2 UI/naming regression: PASS');