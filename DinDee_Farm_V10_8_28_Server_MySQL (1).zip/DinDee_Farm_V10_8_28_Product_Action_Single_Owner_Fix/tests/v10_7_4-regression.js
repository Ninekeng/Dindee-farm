const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1072.js','utf8'),c=fs.readFileSync('css/app.css','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.7\.[4-9]/.test(h));
ok('edit Tag is select',m.includes('<label>Tag</label><select id="v72t">'));
ok('edit Category refreshes Tag',m.includes('onchange="v72t.innerHTML=tagOptions(v72c.value)"'));
ok('category stable explicit value',m.includes('<option value="${esc(x)}"'));
ok('compact action icons',m.includes("className='purchase-actions-v1074'")&&m.includes('purchase-icon-btn'));
ok('compact css',c.includes('.purchase-icon-btn')&&c.includes('width:30px'));
