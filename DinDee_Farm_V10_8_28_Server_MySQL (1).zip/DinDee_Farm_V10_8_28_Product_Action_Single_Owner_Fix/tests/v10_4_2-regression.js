const fs=require('fs'), path=require('path');
const root=path.resolve(__dirname,'..');
const idx=fs.readFileSync(path.join(root,'index.html'),'utf8');
const fix=fs.readFileSync(path.join(root,'modules/stable-fix-v1042.js'),'utf8');
const tasks=fs.readFileSync(path.join(root,'modules/tasks.js'),'utf8');
const v104=fs.readFileSync(path.join(root,'modules/v104.js'),'utf8');
function ok(c,m){if(!c)throw new Error(m)}
ok(/V10\.4\.[3-9]/.test(idx),'compatible version label missing');
ok(idx.indexOf('modules/stable-fix-v1042.js')>idx.indexOf('modules/v104.js'),'V10.4.2 stable fix must load after V10.4');
ok(idx.indexOf('modules/v1043.js')>idx.indexOf('modules/stable-fix-v1042.js'),'V10.4.3 must load after V10.4.2');
ok(tasks.includes("onclick=\"doneTask('${t.id}')\""),'today done button missing');
ok(fix.includes('window.doneTask=function'),'doneTask implementation missing');
ok(fix.includes('window.editProduct=function'),'product edit override missing');
ok(fix.includes('id="epcat"'),'product category dropdown missing');
ok(fix.includes('p.categoryId=c.id')&&fix.includes('p.category=c.name'),'category master link missing');
ok(v104.includes("p.categoryId===cat")&&v104.includes('D.shopCategories'),'customer shop category link missing');
console.log('V10.4.2 regression PASS');
