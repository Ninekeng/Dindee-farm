const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1072.js','utf8'),a=fs.readFileSync('js/app.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.7\.[5-9]/.test(h));
ok('TAGS exists as lexical const',a.includes('const TAGS={'));
ok('edit Tag uses shared helper',m.includes('${tagOptions(p.category,p.tag)}'));
ok('category onchange refreshes shared helper',m.includes('v72t.innerHTML=tagOptions(v72c.value)'));
ok('no window TAGS dependency in canonicalizer',m.includes("typeof TAGS!=='undefined'&&TAGS[cat]"));
ok('excel tag validation same master',m.includes("typeof TAGS!=='undefined'&&TAGS[x.Category]"));
