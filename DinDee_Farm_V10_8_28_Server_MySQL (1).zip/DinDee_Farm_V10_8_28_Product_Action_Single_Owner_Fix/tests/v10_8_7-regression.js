const fs=require('fs');
const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1087.js','utf8'),c=fs.readFileSync('css/app.css','utf8'),p=fs.readFileSync('modules/v104.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.7')&&h.includes('modules/v1087.js'));
ok('month 160px',c.includes('width:160px!important')&&c.includes('table-layout:fixed'));
ok('status result split',m.includes('สถานะงาน')&&m.includes('ผลการทำงาน')&&m.includes("resultStatus"));
ok('problem details',m.includes('รายละเอียดปัญหา')&&m.includes('การแก้ไข / ติดตาม'));
ok('old problem migration',m.includes("['Problem','Issue'].includes(t.status)")&&m.includes("t.status='Done'"));
ok('planned material no lot',m.includes('วัตถุดิบที่วางแผนใช้')&&m.includes("plannedStockId:''")&&m.includes("plannedLot:''"));
ok('actual material lot',m.includes('Lot ที่ใช้จริง (FEFO)')&&m.includes('reconcilePrimaryUsage'));
ok('history material',m.includes('วัตถุดิบ / Lot / จำนวน')&&m.includes('matText(t)'));
ok('stock active only',m.includes('const activeLots=')&&m.includes('n(s.qty)>0'));
ok('stock lot history',m.includes('stockHistoryV1087')&&m.includes('ใช้หมดแล้ว'));
ok('purchase expiry identity',p.includes("(z.expiryDate||'')===(x.expiryDate||'')"));
ok('date format untouched',!m.includes('DD/MM/YYYY'));
