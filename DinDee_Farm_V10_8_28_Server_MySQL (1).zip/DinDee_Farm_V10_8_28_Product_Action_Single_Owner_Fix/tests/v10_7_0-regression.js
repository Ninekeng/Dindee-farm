const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),v=fs.readFileSync('modules/v104.js','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.7\.[0-9]/.test(h));
ok('actual production popup patched',v.includes('openNewCycleV104')&&v.includes('v104SpeciesList'));
ok('master linked',v.includes('(D.species||[]).filter(x=>x.active!==false)'));
ok('free typing retained',v.includes('<input id="v104c" list="v104SpeciesList"'));
ok('custom value trimmed',v.includes('crop:v104c.value.trim()'));
ok('no auto master insert',!/openNewCycleV104[\s\S]{0,1800}D\.species\.push/.test(v));
