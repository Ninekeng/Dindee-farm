const fs=require('fs'),path=require('path');const root=path.resolve(__dirname,'..');
const idx=fs.readFileSync(path.join(root,'index.html'),'utf8'),m=fs.readFileSync(path.join(root,'modules/v1051.js'),'utf8');
function ok(c,s){if(!c)throw new Error(s)}
ok(idx.includes('modules/v1051.js'),'v1051 module not loaded');
ok(m.includes('deletePlan=function'),'cycle safe delete missing');
ok(m.includes('deleteHouseV1051'),'house delete missing');
const m52=fs.readFileSync(path.join(root,'modules/v1052.js'),'utf8');
ok(m52.includes('deleteProductV1052')&&m52.includes('v1052-del-product'),'shop safe delete owner missing');
ok(m.includes('deleteSalesDocV1051'),'sales doc delete missing');
ok(m.includes('deleteFundV1051'),'sponsor delete missing');
ok(m.includes("audit('DELETE'")&&m.includes("audit('DEACTIVATE'")&&m.includes("audit('CANCEL'"),'audit actions missing');
console.log('V10.5.1 safe-delete regression PASS');
