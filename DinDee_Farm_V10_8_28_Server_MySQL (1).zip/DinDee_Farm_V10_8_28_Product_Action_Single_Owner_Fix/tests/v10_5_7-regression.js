const fs=require('fs');
const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1057.js','utf8'),c=fs.readFileSync('css/app.css','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('v1057 loaded',h.includes('modules/v1057.js'));
ok('settings edit',m.includes('editMasterV1057'));
ok('settings safe delete',m.includes('deleteMasterV1057')&&m.includes('DEACTIVATE'));
ok('user edit',m.includes('editUserV1057'));
ok('user password',m.includes('changeUserPasswordV1057'));
ok('user role',m.includes('changeUserRoleV1057'));
ok('user delete',m.includes('deleteUserV1057'));
ok('self delete guard',m.includes('ไม่สามารถลบบัญชีที่กำลัง Login อยู่'));
ok('last admin guard',m.includes('Admin อย่างน้อย 1 บัญชี'));
ok('compact stock metadata',c.includes('#content table td b + br + .muted')&&c.includes('font-size:11px'));
ok('settings responsive grid',c.includes('.settings-grid')&&c.includes('@media(max-width:900px)'));
