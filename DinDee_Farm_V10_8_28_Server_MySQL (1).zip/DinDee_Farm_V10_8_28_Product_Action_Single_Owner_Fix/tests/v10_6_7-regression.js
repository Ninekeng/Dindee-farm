const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1067.js','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('loaded',h.includes('modules/v1067.js'));
ok('harvest override',m.includes('window.harvest=function'));
ok('edit action',m.includes('editHarvestV1067'));
ok('delete action',m.includes('deleteHarvestV1067'));
ok('edit saves harvests',m.includes("sv('harvests')"));
ok('audit edit',m.includes("logAudit('EDIT','Harvest'"));
ok('audit delete',m.includes("logAudit('DELETE','Harvest'"));
ok('admin guard',m.includes("me.role!=='Admin'"));
ok('delete confirm',m.includes('ยืนยันลบบันทึกเก็บเกี่ยว'));
