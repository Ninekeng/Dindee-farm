/* ทดสอบ js/server-sync.js กับเซิร์ฟเวอร์จริง (memory driver) ใน vm sandbox:  node tests/client-sync-test.js */
process.env.DB_DRIVER = 'memory'; process.env.PORT = '0'; process.env.HOST = '127.0.0.1'; process.env.ADMIN_PASSWORD = 'pw123456';
const vm = require('vm'), fs = require('fs'), path = require('path');
const { start } = require('../server/server');
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL:', m); } else console.log('ok  :', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const SYNC = fs.readFileSync(path.join(__dirname, '../js/server-sync.js'), 'utf8');

function makeClient(base, cookie, bootstrapJs, preset = {}) {
  class Storage { setItem(k, v) { this[k] = String(v); } getItem(k) { return Object.prototype.hasOwnProperty.call(this, k) ? this[k] : null; } removeItem(k) { delete this[k]; } }
  const ls = new Storage(); Object.entries(preset).forEach(([k, v]) => ls[k] = v);
  const bar = { style: {}, innerHTML: '' }, listeners = {};
  const win = { localStorage: ls, Storage, addEventListener() {}, setTimeout, clearTimeout, setInterval: () => 0 };
  win.window = win;
  const ctx = vm.createContext({
    window: win, Storage, localStorage: ls, setTimeout, clearTimeout, setInterval: () => 0, console, JSON, Object, Map, Set, Promise, String, Math, Array,
    document: { body: { appendChild() {} }, createElement: () => bar, addEventListener() {}, hidden: false },
    location: { reload() {} },
    fetch: (u, o = {}) => fetch(base + '/' + u, { ...o, headers: { ...(o.headers || {}), ...(cookie ? { cookie } : {}) } }),
  });
  vm.runInContext(bootstrapJs, ctx);
  vm.runInContext(SYNC, ctx);
  return { ls, win, bar, ctx };
}

(async () => {
  const srv = await start(); const base = 'http://127.0.0.1:' + srv.address().port;
  const get = async (u, cookie) => (await fetch(base + u, { headers: cookie ? { cookie } : {} })).text();
  const login = async (user, pass) => (await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user, pass }) })).headers.get('set-cookie').split(';')[0];
  const admin = await login('admin', 'pw123456');

  // 1) admin: hydrate + write-through
  let c = makeClient(base, admin, await get('/api/bootstrap.js', admin), { dindee_v7_stale: '[1]', dindee_v7_purchaseDraftV105: '{"x":1}' });
  ok(c.ls.dindee_v7_users && JSON.parse(c.ls.dindee_v7_users)[0].user === 'admin', 'hydrated users into localStorage');
  ok(!('dindee_v7_stale' in c.ls), 'stale local key removed in full tier');
  ok('dindee_v7_purchaseDraftV105' in c.ls, 'device-local draft key preserved');
  c.ls.setItem('dindee_v7_expenses', JSON.stringify([{ id: 'e1', amount: 100 }]));
  c.ls.setItem('dindee_v7_purchaseDraftV105', '{"x":2}');
  await sleep(900);
  let srvState = new Function('window', await get('/api/bootstrap.js', admin) + ';return window.__DINDEE__')({});
  ok(srvState.state.expenses && JSON.parse(srvState.state.expenses)[0].id === 'e1', 'setItem synced to server');
  ok(!('purchaseDraftV105' in srvState.state), 'draft key NOT synced to server');
  ok(c.win.DinDeeSync.pending() === 0, 'queue drained');

  // 2) second write uses version -> ok; concurrent device -> conflict banner
  c.ls.setItem('dindee_v7_expenses', JSON.stringify([{ id: 'e1' }, { id: 'e2' }]));
  await sleep(900);
  const other = makeClient(base, admin, await get('/api/bootstrap.js', admin));
  other.ls.setItem('dindee_v7_expenses', JSON.stringify([{ id: 'e1' }, { id: 'e2' }, { id: 'e3' }]));
  await sleep(900);
  c.ls.setItem('dindee_v7_expenses', JSON.stringify([{ id: 'e1' }, { id: 'e2' }, { id: 'eX' }]));
  await sleep(900);
  ok(/ถูกแก้จากเครื่อง/.test(c.bar.innerHTML), 'stale device sees conflict banner instead of overwriting');
  srvState = new Function('window', await get('/api/bootstrap.js', admin) + ';return window.__DINDEE__')({});
  ok(JSON.parse(srvState.state.expenses).some(x => x.id === 'e3') && !JSON.parse(srvState.state.expenses).some(x => x.id === 'eX'), 'server kept the other device data (no silent loss)');

  // 3) removeItem (factory-reset style) -> DELETE
  other.ls.removeItem('dindee_v7_expenses'); await sleep(900);
  srvState = new Function('window', await get('/api/bootstrap.js', admin) + ';return window.__DINDEE__')({});
  ok(!('expenses' in srvState.state), 'removeItem deletes on server (admin)');

  // 4) guest: public hydrate, own orders kept, server merges
  const guestBoot = await get('/api/bootstrap.js');
  const g = makeClient(base, null, guestBoot, { dindee_v7_orders: JSON.stringify([{ id: 'mine', no: 'D0099', phone: '0811111111' }]), dindee_v7_customers: '[{"id":"c1"}]', dindee_v7_users: '[{"user":"leak"}]' });
  ok(!('dindee_v7_users' in g.ls), 'guest: non-public local keys wiped');
  ok(JSON.parse(g.ls.dindee_v7_customers)[0].id === 'c1', 'guest: own customers kept');
  ok(JSON.parse(g.ls.dindee_v7_orders).some(o => o.id === 'mine'), 'guest: own orders kept');
  g.ls.setItem('dindee_v7_users', '[{"user":"evil"}]'); await sleep(700);
  ok(!/⚠️/.test(g.bar.innerHTML), 'guest 401 on forbidden key is silent');

  // 5) staff cache -> guest on same device is wiped
  const staffBrowser = makeClient(base, admin, await get('/api/bootstrap.js', admin));
  const stash = Object.fromEntries(Object.entries(staffBrowser.ls));
  const g2 = makeClient(base, null, await get('/api/bootstrap.js'), stash);
  ok(!('dindee_v7_users' in g2.ls) && !('dindee_v7_audit' in g2.ls) && !('dindee_v7_orders' in g2.ls && JSON.parse(g2.ls.dindee_v7_orders).some(o => o.phone)), 'guest on previously-staff device: cached private data wiped');

  // 6) no __DINDEE__ => legacy mode untouched
  const legacy = vm.createContext({ window: {}, Storage: class {}, localStorage: {} }); vm.runInContext(SYNC, legacy);
  ok(true, 'script is a no-op without server bootstrap (legacy file:// mode)');

  srv.close(); console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
