
const fs=require('fs');
const mods=['master-data.js','purchase.js','tasks.js','stock-houses.js','sales.js','system-pages.js'];
let all=mods.map(f=>fs.readFileSync('modules/'+f,'utf8')).join('\n'), fail=[];
for(const x of ['window.addPurchase','unitOptions','DinDeeThai','salesItemsBody','window.editTask','window.deleteTask','responsibles','expenseCats','editHouseV101']) if(!all.includes(x))fail.push('missing '+x);
if(!fs.readFileSync('index.html','utf8').includes('modules/purchase.js'))fail.push('purchase module not loaded');
if(fail.length){console.error(fail.join('\n'));process.exit(1)}
console.log('DinDee V10.2 regression: PASS');
