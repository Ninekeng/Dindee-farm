const fs=require('fs'),assert=require('assert');
const idx=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v10813.js','utf8');
assert(idx.includes('modules/v10813.js'));
assert(m.includes("old.classList.remove('cartButton')"));
assert(m.includes("old.setAttribute('onclick','openCartV10813()')"));
assert(m.includes("window.openCheckoutV1043()"));
assert(m.includes("if(q<=0)c.splice"));
assert(m.includes("cart-count-v10813"));
console.log('V10.8.13 regression PASS');
