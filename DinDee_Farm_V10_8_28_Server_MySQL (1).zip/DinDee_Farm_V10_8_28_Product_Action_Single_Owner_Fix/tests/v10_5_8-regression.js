const fs=require('fs');
const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1058.js','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('v1058 loaded',h.includes('modules/v1058.js'));
ok('stock category dropdown',m.includes('<select id="v58cat">')&&m.includes('catOptions'));
ok('stock explicit save fields',m.includes("document.getElementById(id)")&&m.includes("sv('stock')"));
ok('stock purchase-only delete allowed',m.includes('if(usages.length||costs.length)')&&!m.includes('if(usages.length||purchases.length)'));
ok('linked purchase cleanup',m.includes("D.purchases=D.purchases.filter")&&m.includes("x.source==='Purchase'"));
ok('one work history',m.includes('function unifiedHistory()')&&m.includes("x.remove()"));
ok('full history link',m.includes('workHistoryV1056()'));
ok('annual gantt delete cleanup',m.includes("annual.querySelectorAll('button')")&&m.includes("oc.includes('deletePlan')"));
