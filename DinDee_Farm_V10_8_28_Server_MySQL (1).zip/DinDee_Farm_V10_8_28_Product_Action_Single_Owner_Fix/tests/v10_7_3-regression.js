const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),v4=fs.readFileSync('modules/v104.js','utf8'),v43=fs.readFileSync('modules/v1043.js','utf8'),v72=fs.readFileSync('modules/v1072.js','utf8'),x=fs.readFileSync('modules/v1055.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.7\.[3-9]/.test(h));
ok('category explicit stable value',v4.includes('<option value="${esc(x)}">${esc(x)}</option>'));
ok('translated label preserves value',v43.includes("o.getAttribute('value')")&&v43.includes('ptag.innerHTML=tagOptions(e.value)'));
ok('legacy translated category canonicalized',v72.includes("raw.split(' — ')[0].trim()"));
ok('saved legacy purchase categories repaired',v72.includes('repairPurchaseCategoriesV1073'));
ok('xlsx engine diagnostic',x.includes('Excel Engine (SheetJS)'));
ok('xlsx import validator retained',x.includes('validatePurchaseImportV1072(raw)'));
