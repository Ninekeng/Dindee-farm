const fs=require('fs');
const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1062.js','utf8'),c=fs.readFileSync('css/app.css','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('v1062 loaded',h.includes('modules/v1062.js'));
ok('date row per house',m.includes('house-day-row')&&m.includes('${dayHeads()}'));
ok('sticky dates',c.includes('.month-sticky-head{position:sticky'));
ok('customer history page',m.includes('customerHistoryV1062'));
ok('old order migration',m.includes('syncCustomersV1062'));
ok('customer order history',m.includes('ประวัติการซื้อ')&&m.includes('o.customerId===cid'));
ok('customer edit',m.includes('editCustomerV1062'));
ok('duplicate phone guard',m.includes('เบอร์โทรนี้มีในระบบแล้ว'));
ok('safe customer delete',m.includes("logAudit('DEACTIVATE','Customer'"));
ok('checkout enriches customer',m.includes('c.address=address||c.address'));
ok('orders entry button',m.includes('👥 ประวัติลูกค้า'));
