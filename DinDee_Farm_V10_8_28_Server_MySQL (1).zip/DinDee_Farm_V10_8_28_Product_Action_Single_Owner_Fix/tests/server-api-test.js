/* ทดสอบ server (ใช้ memory driver ไม่ต้องมี MySQL):  node tests/server-api-test.js */
process.env.DB_DRIVER = 'memory'; process.env.PORT = '0'; process.env.HOST = '127.0.0.1'; process.env.ADMIN_PASSWORD = 'Admin#2026';
const { start, hash } = require('../server/server');
const assert = require('assert');
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL:', m); } else console.log('ok  :', m); };

(async () => {
  const srv = await start(); const base = 'http://127.0.0.1:' + srv.address().port;
  const j = async (method, url, body, cookie) => {
    const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
    let b; const t = await r.text(); try { b = JSON.parse(t); } catch (_) { b = t; }
    return { s: r.status, b, c: (r.headers.get('set-cookie') || '').split(';')[0] };
  };
  const boot = async cookie => { const r = await j('GET', '/api/bootstrap.js', null, cookie); const w = {}; new Function('window', r.b)(w); return w.__DINDEE__; };

  // static
  ok((await j('GET', '/')).s === 200, 'GET / serves index.html');
  ok((await j('GET', '/js/app.js')).s === 200, 'GET /js/app.js');
  for (const p of ['/server/server.js', '/server/db.js', '/package.json', '/tests/smoke-test.js', '/README.md', '/js/../server/server.js', '/%2e%2e/server/server.js', '/modules/../package.json'])
    ok((await j('GET', p)).s === 404, 'blocked ' + p);

  // anonymous bootstrap
  let b = await boot();
  ok(b.tier === 'public' && !b.session, 'anonymous gets public tier');
  ok(!('users' in b.state) && !('income' in b.state) && !('customers' in b.state), 'anonymous cannot see users/income/customers');

  // login
  ok((await j('POST', '/api/login', { user: 'admin', pass: 'wrong' })).s === 401, 'wrong password -> 401');
  const L = await j('POST', '/api/login', { user: 'admin', pass: 'Admin#2026' });
  ok(L.s === 200 && L.c.startsWith('dd_sid='), 'admin login ok + cookie');
  const admin = L.c;
  ok((await j('POST', '/api/login', { user: 'admin', pass: 'Admin#2026' }, 'dd_sid=bad.bad')).s === 200, 'login ignores bad cookie');
  ok((await j('PUT', '/api/kv/products', { value: '[]', base: 1 }, 'dd_sid=forged.sig')).s === 401, 'forged cookie rejected');

  // full bootstrap + write + version
  b = await boot(admin);
  ok(b.tier === 'full' && b.session.role === 'Admin' && 'users' in b.state, 'admin gets full tier');
  let r = await j('PUT', '/api/kv/products', { value: JSON.stringify([{ id: 'p1', name: 'ผักกาด', price: 50, qty: 10, unit: 'kg', status: 'พร้อมขาย' }]), base: null }, admin);
  ok(r.s === 200 && r.b.ver === 1, 'admin creates products v1');
  const v1 = r.b.ver;
  r = await j('PUT', '/api/kv/products', { value: JSON.stringify([{ id: 'p1', name: 'ผักกาด', price: 50, qty: 10, unit: 'kg', status: 'พร้อมขาย' }]), base: v1 }, admin);
  ok(r.s === 200 && r.b.ver === 2, 'update with right base -> v2');
  r = await j('PUT', '/api/kv/products', { value: '[]', base: v1 }, admin);
  ok(r.s === 409, 'stale base -> 409 conflict');
  r = await j('PUT', '/api/kv/products', { value: JSON.stringify([{ id: 'p1', name: 'ผักกาด', price: 50, qty: 10, unit: 'kg', status: 'พร้อมขาย' }]), base: v1, force: true }, admin);
  ok(r.s === 200 && r.b.ver === 3, 'force overwrite works');
  ok((await j('PUT', '/api/kv/products', { value: 'not json', base: 3 }, admin)).s === 400, 'invalid JSON rejected');
  ok((await j('PUT', '/api/kv/bad key!', { value: '[]' }, admin)).s === 400, 'bad key rejected');

  // public (guest) order: tamper price + qty, stock decrement by server
  const guestOrder = { id: 'o-guest-1', no: 'D0001', customer: 'ลูกค้า', phone: '0800000000', items: [{ productId: 'p1', name: 'HACK', qty: 2, unit: 'x', price: 1 }, { productId: 'nope', qty: 5, price: 1 }], paymentMethod: 'cash', status: 'Paid', total: 2 };
  r = await j('PUT', '/api/kv/orders', { value: JSON.stringify([guestOrder]) });
  ok(r.s === 200 && r.b.merged === 1, 'guest can add an order');
  const A = await boot(admin); const orders = JSON.parse(A.state.orders), prods = JSON.parse(A.state.products);
  ok(orders.length === 1 && orders[0].total === 100 && orders[0].items.length === 1 && orders[0].items[0].price === 50 && orders[0].items[0].name === 'ผักกาด', 'server recomputed price/total, dropped unknown product');
  ok(orders[0].status === 'New', 'guest cannot self-set status');
  ok(prods[0].qty === 8, 'server decremented stock (10-2=8)');
  r = await j('PUT', '/api/kv/orders', { value: JSON.stringify([guestOrder]) });
  ok(r.b.merged === 0 && JSON.parse((await boot(admin)).state.orders).length === 1, 'duplicate order id ignored (idempotent)');
  r = await j('PUT', '/api/kv/orders', { value: JSON.stringify([{ ...guestOrder, id: 'o-guest-2' }]) });
  const nos = JSON.parse((await boot(admin)).state.orders).map(o => o.no);
  ok(new Set(nos).size === 2, 'order-number collision re-numbered: ' + nos.join(','));
  const pub = await boot();
  ok(JSON.parse(pub.state.orders).every(o => Object.keys(o).sort().join() === 'id,no'), 'public sees only order id/no stubs (no PII)');
  ok((await j('PUT', '/api/kv/orders', { value: '[]' })).b.merged === 0 && JSON.parse((await boot(admin)).state.orders).length === 2, 'guest cannot delete orders by sending []');
  ok((await j('PUT', '/api/kv/users', { value: '[]' })).s === 401, 'guest cannot write users');
  ok((await j('PUT', '/api/kv/income', { value: '[]' })).s === 401, 'guest cannot write income');
  ok((await j('PUT', '/api/kv/products', { value: '[]' })).s === 401, 'guest cannot write products');
  ok((await j('GET', '/api/backup')).s === 403, 'guest cannot backup');

  // roles: staff + sponsor
  const users = JSON.parse(A.state.users);
  users.push({ id: 'u2', user: 'staff1', pass: hash('s3cret'), plainPass: 's3cret', role: 'Staff' }, { id: 'u3', user: 'sp', pass: hash('spons'), plainPass: 'spons', role: 'Sponsor Viewer' }, { id: 'u4', user: 'cust', pass: hash('cc'), plainPass: 'cc', role: 'Customer' });
  ok((await j('PUT', '/api/kv/users', { value: JSON.stringify(users), base: A.vers.users }, admin)).s === 200, 'admin edits users');
  ok((await j('PUT', '/api/kv/users', { value: JSON.stringify([{ id: 'x', user: 'a', role: 'Staff', pass: 'z' }]), base: null, force: true }, admin)).s === 400, 'cannot remove all Admins');
  const staff = (await j('POST', '/api/login', { user: 'staff1', pass: 's3cret' })).c;
  const sp = (await j('POST', '/api/login', { user: 'sp', pass: 'spons' })).c;
  const cu = (await j('POST', '/api/login', { user: 'cust', pass: 'cc' })).c;
  const sb = await boot(staff);
  ok(sb.tier === 'full' && !JSON.parse(sb.state.users).some(u => u.pass || u.plainPass), 'staff sees users WITHOUT password hashes');
  ok((await j('PUT', '/api/kv/users', { value: '[]' }, staff)).s === 403, 'staff cannot write users');
  ok((await j('PUT', '/api/kv/stock', { value: '[]', base: sb.vers.stock }, staff)).s === 200, 'staff can write stock');
  ok((await j('PUT', '/api/kv/stock', { value: '[]', base: 1 }, sp)).s === 403, 'sponsor viewer is read-only');
  ok((await boot(sp)).readOnly === true, 'sponsor flagged readOnly');
  ok((await boot(cu)).tier === 'public', 'Customer role gets public tier');
  ok((await j('DELETE', '/api/kv/stock', null, staff)).s === 403, 'staff cannot delete keys');
  ok((await j('DELETE', '/api/kv/users', null, admin)).s === 400, 'cannot delete users key');
  ok((await j('GET', '/api/versions')).s === 401 && (await j('GET', '/api/versions', null, staff)).s === 200, '/api/versions auth');

  // backup + reset re-seeds admin
  const bk = await j('GET', '/api/backup', null, admin);
  ok(bk.s === 200 && bk.b.data.products && bk.b.data.users, 'admin backup JSON');
  ok((await j('POST', '/api/reset', { confirm: 'no' }, admin)).s === 400, 'reset needs RESET');
  ok((await j('POST', '/api/reset', { confirm: 'RESET' }, admin)).s === 200, 'reset ok');
  ok((await j('POST', '/api/login', { user: 'admin', pass: 'Admin#2026' })).s === 200, 'admin re-seeded after reset (no lockout)');

  // rate limit
  let last; for (let i = 0; i < 9; i++) last = await j('POST', '/api/login', { user: 'nobody', pass: 'x' + i });
  ok(last.s === 429, 'login brute-force limited (429)');

  srv.close(); console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
