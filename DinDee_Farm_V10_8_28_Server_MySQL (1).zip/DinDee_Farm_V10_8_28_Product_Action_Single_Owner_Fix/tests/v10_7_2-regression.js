const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1072.js','utf8'),x=fs.readFileSync('modules/v1055.js','utf8'),mo=fs.readFileSync('modules/v1062.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.7\.[2-9]/.test(h)&&h.includes('modules/v1072.js'));
ok('monthly weekday and date',mo.includes("['อา','จ','อ','พ','พฤ','ศ','ส']")&&mo.includes('day-head'));
ok('dashboard purchase KPI',m.includes('purchase-kpi-v1072')&&m.includes('ยอดซื้อวัตถุดิบ'));
ok('purchase edit',m.includes('editPurchaseV1072')&&m.includes("logAudit('EDIT','Purchase'"));
ok('purchase copy',m.includes('copyPurchaseV1072'));
ok('purchase safe delete',m.includes('deletePurchaseV1072')&&m.includes('Lot นี้มีการเบิกใช้แล้ว'));
ok('excel same master validator',m.includes('activeExpenseCats')&&m.includes('validatePurchaseImportV1072'));
ok('xlsx preview uses validator',x.includes('validatePurchaseImportV1072(raw)'));
ok('xlsx duplicate guard retained',x.includes("e.push('ข้อมูลซ้ำ')"));
