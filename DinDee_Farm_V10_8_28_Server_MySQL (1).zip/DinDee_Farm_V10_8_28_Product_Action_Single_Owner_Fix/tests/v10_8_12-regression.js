const fs=require('fs'),assert=require('assert');
const m=fs.readFileSync('modules/v10812.js','utf8'),ui=fs.readFileSync('modules/ui-v103.js','utf8'),app=fs.readFileSync('js/app.js','utf8'),idx=fs.readFileSync('index.html','utf8');
assert(m.includes("closest('.cartButton')"),'cart delegated click handler missing');
assert(m.includes('stopImmediatePropagation'),'stale inline cart handler guard missing');
assert(m.includes('openCartV1043'),'active cart function missing');
const order=["['shopadmin','จัดการร้านค้าฟาร์ม']","['orders','คำสั่งซื้อ']","['salesDocs','เอกสารขาย']","['shop','ร้านค้าฟาร์ม']","['track','ติดตามคำสั่งซื้อ']","['customers','ฐานข้อมูลลูกค้า']","['customerPurchases','ประวัติการซื้อของลูกค้า']","['live','กล้องฟาร์ม']"];
let pos=-1;for(const x of order){const n=ui.indexOf(x);assert(n>pos,'sales menu order wrong: '+x);pos=n}
assert(app.indexOf("['track','🔎 Order ของฉัน']")<app.indexOf("['customers','👥 ฐานข้อมูลลูกค้า']"),'fallback customer menu must follow tracking');
assert(app.indexOf("['customers','👥 ฐานข้อมูลลูกค้า']")<app.indexOf("['customerPurchases','🧾 ประวัติการซื้อของลูกค้า']"),'purchase history must follow customer database');
assert(app.includes("['live','📹 Live Farm']"),'Farm Camera menu must remain');
assert(idx.indexOf('modules/v10812.js')>idx.indexOf('modules/v10811.js'),'v10812 must load last');
assert(idx.includes('<title>ดินดีฟาร์ม V10.8.12</title>'),'version title missing');
console.log('V10.8.12 regression PASS');
