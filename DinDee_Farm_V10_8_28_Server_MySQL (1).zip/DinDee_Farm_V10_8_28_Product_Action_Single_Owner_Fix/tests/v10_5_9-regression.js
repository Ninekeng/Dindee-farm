const fs=require('fs');
const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1059.js','utf8'),c=fs.readFileSync('css/app.css','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('v1059 loaded',h.includes('modules/v1059.js'));
ok('task center',m.includes('taskCenterV1059'));
ok('all status KPIs',m.includes('งานทั้งหมด')&&m.includes('รอดำเนินการ')&&m.includes('ทำแล้ว')&&m.includes('มีปัญหา')&&m.includes('เลื่อนงาน'));
ok('filters',m.includes('tcFrom')&&m.includes('tcHouse')&&m.includes('tcCycle')&&m.includes('tcOwner')&&m.includes('tcStatus'));
ok('view edit done delete',m.includes('viewTaskV1059')&&m.includes("editTask('${t.id}')")&&m.includes("doneTask('${t.id}')")&&m.includes('deleteTaskSafeV1059'));
ok('safe stock return',m.includes("s.qty=(+s.qty||0)+(+u.qty||0)")&&m.includes("sv('stock')"));
ok('monthly plan entry',m.includes('📋 สรุปและจัดการงาน'));
ok('responsive ui',c.includes('.task-kpis')&&c.includes('.task-center-table'));
