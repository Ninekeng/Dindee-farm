const fs=require('fs'),path=require('path');const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'js/app.js'),'utf8'),v=fs.readFileSync(path.join(root,'modules/v105.js'),'utf8'),idx=fs.readFileSync(path.join(root,'index.html'),'utf8');
const checks=[
 ['v105 loaded',idx.includes('modules/v105.js')],
 ['direct cost delete',v.includes('deleteCostV105')&&v.includes("D.costs=D.costs.filter" )],
 ['reset clears costs',v.includes("'harvests','costs'" )],
 ['legacy category disabled',v.includes("c.active=false")&&v.includes('categoryReview=true')],
 ['house 360',v.includes('house360V105')&&v.includes('ต้นทุน/หน่วย')],
 ['cycle drilldown',v.includes('openCycleDrillV105')],
 ['stock analytics',v.includes('stockAnalyticsV105')&&v.includes('Slow/Dead Stock')],
 ['sponsor drilldown',v.includes('sponsorDrillV105')],
 ['enhanced alerts',v.includes("kind:'stock'")&&v.includes("kind:'sponsor'")],
 ['global search',v.includes('openGlobalSearchV105')&&v.includes('runGlobalSearchV105')],
 ['mobile staff',v.includes('mobileStaffV105')],
 ['target vs actual',v.includes('เป้าหมาย vs ผลผลิตจริง')],
 ['staff finance privacy',v.includes("me?.role==='Staff'")],
 ['backup validation',v.includes('ตรวจสอบ Restore Backup')&&v.includes("version:'10.5'")],
 ['purchase duplicate protection',v.includes('lastPurchaseFingerprintV105')&&v.includes('purchaseDraftV105')],
 ['house QR',v.includes('houseQrV105')&&v.includes('DINDEE-HOUSE-')],
 ['no login reset restored',!v.includes("u.pass=hash('1234')")]
];let bad=checks.filter(x=>!x[1]);checks.forEach(x=>console.log((x[1]?'PASS ':'FAIL ')+x[0]));if(bad.length)process.exit(1);
