const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1085.js','utf8');
function ok(n,v){if(!v){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version/load',h.includes('V10.8.5')&&h.includes('modules/v1085.js'));
ok('admin reset',m.includes("me?.role!=='Admin'")&&m.includes('resetCustomerPinV1085'));
ok('4 digit validation',m.includes('/^\\d{4}$/'));
ok('hash only',m.includes('c.pinHash=hash(a)'));
ok('audit no pin value',m.includes("logAudit('RESET PIN'")&&m.includes('PIN value not logged'));
ok('customer reset icon',m.includes('🔑')&&m.includes('data-pin-reset'));
ok('forgot help',m.includes('ลืมเบอร์โทรหรือ PIN?')&&m.includes('customerRecoveryHelpV1085'));
ok('compact actions',m.includes('purchase-icon-btn'));
