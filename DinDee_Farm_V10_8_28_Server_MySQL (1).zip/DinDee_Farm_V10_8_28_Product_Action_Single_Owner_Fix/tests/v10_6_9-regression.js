const fs=require('fs');const h=fs.readFileSync('index.html','utf8'),a=fs.readFileSync('js/app.js','utf8'),t=fs.readFileSync('modules/tasks.js','utf8');
function ok(n,x){if(!x){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('version',/V10\.(6\.9|7\.[0-9])/.test(h));
ok('new cycle species datalist',t.includes('speciesListCycle')&&t.includes('(D.species||[]).filter'));
ok('new cycle remains free text',t.includes('<input id="yc" list="speciesListCycle"'));
ok('edit species datalist',a.includes('speciesListEdit')&&a.includes('<input id="epcrop" list="speciesListEdit"'));
ok('custom name trimmed on add',a.includes('crop:yc.value.trim()'));
ok('custom name trimmed on edit',a.includes('p.crop=epcrop.value.trim()'));
ok('does not auto push species',!t.includes('D.species.push') && !/addYear[\s\S]{0,800}D\.species\.push/.test(a));
