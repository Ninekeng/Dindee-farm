const fs=require('fs');
const h=fs.readFileSync('index.html','utf8'),m=fs.readFileSync('modules/v1056.js','utf8');
function ok(n,c){if(!c){console.error('FAIL',n);process.exitCode=1}else console.log('PASS',n)}
ok('v1056 loaded',h.includes('modules/v1056.js'));
ok('legacy UI injectors not loaded',!h.includes('modules/v1053.js')&&!h.includes('modules/v1054.js'));
ok('single action normalizer',m.includes('function normalizeActions()'));
ok('removes duplicate delete',m.includes("tx.includes('ลบ')"));
ok('work history exists',m.includes('window.workHistoryV1056'));
ok('history uses existing tasks',m.includes("D.tasks||[]"));
ok('history filters',m.includes('filterWorkHistoryV1056'));
ok('history edit delete',m.includes("editTask('${t.id}')")&&m.includes("deleteTask('${t.id}')"));
ok('history photo',m.includes('viewWorkPhotoV1056'));
ok('today history entry',m.includes('ดูประวัติการทำงาน →'));
