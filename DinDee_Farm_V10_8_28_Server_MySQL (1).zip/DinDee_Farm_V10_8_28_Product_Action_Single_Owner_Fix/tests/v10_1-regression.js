
const fs=require('fs');
const files=['modules/master-data.js','modules/tasks.js','modules/stock-houses.js','modules/sales.js','modules/system-pages.js'];
let fail=[];
for(const f of files){let s=fs.readFileSync(f,'utf8');if(!s.length)fail.push('empty '+f)}
const all=files.map(f=>fs.readFileSync(f,'utf8')).join('\n');
for(const marker of ['responsibles','salesDocs','salesReport','categoryTags','editTask','deleteTask','expenseCats','editHouseV101','หลักฐาน / เอกสารแนบ']) if(!all.includes(marker))fail.push('missing '+marker);
if(fail.length){console.error(fail.join('\n'));process.exit(1)}
console.log('DinDee V10.1 regression markers: PASS');
