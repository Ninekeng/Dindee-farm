# V10.8.14 — Rebuilt Farm Shop Cart → Checkout
- Rebuilt the Cart → Checkout transition as one direct flow instead of wrapping older checkout handlers.
- Fixed runtime failure caused by V10.8.10 referencing `isActivity`, which was private to the V10.4.3 module scope.
- Cart, badge, quantity-zero removal, checkout rendering and PIN rendering now use the V10.8.14 entry points.
- Checkout still submits through the existing order/customer/payment pipeline to preserve current business logic and data compatibility.
