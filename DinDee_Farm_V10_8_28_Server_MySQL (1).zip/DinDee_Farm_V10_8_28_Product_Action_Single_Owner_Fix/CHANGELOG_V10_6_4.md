# V10.6.4 — Customer Database Menu
- Added permanent `ฐานข้อมูลลูกค้า` menu in Sales/Customer group.
- Added core router entry instead of relying on a post-render button.
- Admin and Staff can access Customer Database.
- Existing Customer History features remain: search, add/edit, safe delete/deactivate, order history, purchase count, total, latest purchase, address and notes.
