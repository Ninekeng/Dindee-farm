# DinDee Farm V10.8.19

## Dashboard readability
- Changed only the Dashboard layout for **กำไรตามสินค้า / ผลผลิต** and **รายการล่าสุด**.
- These two cards are now stacked vertically at full width instead of sharing a 2-column row.
- Preserved the existing Income/Expense proportion charts, Farm Analytics, Sponsor summary, 6-month Income/Expense/Net chart, Transaction Center, and all existing functions.
- Latest Transactions keeps the **ดูรายการทั้งหมด →** action and gains horizontal overflow protection for narrow screens.
