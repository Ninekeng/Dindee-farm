# V10.8.13 — Direct Cart Flow Fix
- Replaced the Farm Shop cart entry with a direct handler that bypasses the stale V10.8.12 capture listener.
- Cart quantity zero removes the line from the single window.cart state.
- Cart badge and total are recalculated from the same state.
- Cart action proceeds directly to the active PIN checkout (openCheckoutV1043).
- Preserves V10.8.12 Sales menu ordering and all existing features.
