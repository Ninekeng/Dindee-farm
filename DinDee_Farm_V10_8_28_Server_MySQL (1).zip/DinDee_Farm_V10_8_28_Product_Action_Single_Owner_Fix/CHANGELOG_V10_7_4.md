# V10.7.4 — Purchase Edit Tag Dropdown + Compact Actions
- Purchase History edit popup Tag is now a dropdown linked to the selected Category.
- Changing Category refreshes Tag options from the same TAGS master used by the purchase form.
- Category keeps stable internal values while displaying the bilingual label.
- Purchase History Edit / Copy / Delete buttons are compact icon buttons with tooltips to save table width.
