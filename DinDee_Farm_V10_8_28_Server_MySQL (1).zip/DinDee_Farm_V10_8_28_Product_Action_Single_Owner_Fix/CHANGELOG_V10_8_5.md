# V10.8.5 — Customer PIN Recovery
- Customer Database adds compact 🔑 Reset PIN for Admin.
- PIN reset requires a new 4-digit PIN twice and stores only its hash.
- Audit records who reset which customer PIN, never the PIN value.
- Existing customer edit allows Admin to correct a forgotten/changed phone number.
- Customer Order lookup adds “ลืมเบอร์โทรหรือ PIN?” guidance for contacting farm staff.
- Customer action buttons are compact icon-only controls.
