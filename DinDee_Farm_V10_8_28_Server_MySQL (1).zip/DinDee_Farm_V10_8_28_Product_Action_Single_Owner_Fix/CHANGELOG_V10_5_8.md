# V10.5.8 — Stock & History Corrections
- Stock Edit now uses Category dropdown and explicit DOM-based save logic.
- Stock Edit includes unit and supplier selectors.
- Stock with purchase-only history can be deleted; linked source purchase and automatic Purchase expense are cleaned together.
- Stock with real Usage/Cost history is archived instead of hard-deleted.
- Today page now shows one Work History section only, with a link to full filtered history.
- Annual Production Plan removes delete controls from the Gantt/timeline; crop bars remain edit/open controls.
