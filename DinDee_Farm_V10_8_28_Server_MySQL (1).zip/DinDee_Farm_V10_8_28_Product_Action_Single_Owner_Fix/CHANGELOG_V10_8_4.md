# V10.8.4 — Shop Category Delete UI Fix
- Fixed the Shop Category + Income Mapping table so the delete icon is rendered directly in each row.
- Actions are now consistently: Edit Mapping ✏️, Enable/Disable ⏸/▶, Delete 🗑️.
- Existing safe-delete rule from V10.8.2 remains: categories referenced by products/services cannot be deleted.
