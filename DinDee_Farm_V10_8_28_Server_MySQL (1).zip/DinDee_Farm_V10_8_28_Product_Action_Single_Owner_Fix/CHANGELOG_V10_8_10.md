# DinDee Farm V10.8.10
- Fixed Farm Shop active checkout (v1043) so PIN fields are built directly into checkout.
- Existing customer: enter existing 4-digit PIN.
- New/legacy customer without PIN: set and confirm 4-digit PIN.
- Customer Database page now clearly identifies itself and shows PIN status + Admin reset action.
- Preserves V10.8.9 Flow 3 fixes and Farm Camera menu.
