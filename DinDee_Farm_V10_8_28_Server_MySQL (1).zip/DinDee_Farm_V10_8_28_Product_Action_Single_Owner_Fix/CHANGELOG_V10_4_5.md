# DinDee Farm V10.4.5

- Added Deep Farm Analytics entry from Dashboard.
- Added greenhouse performance comparison: cost, harvest, income, profit, task completion and drill-down.
- Added Crop Cycle profitability analysis.
- Added Stock analytics: low stock, near expiry, expired lots.
- Added Sponsor received/used/balance analysis.
- Added Course vs Activity/Workshop sales analysis using existing product/order data.
- Added current-vs-previous-period income and expense comparison and automatic warnings.
- Added full Knowledge CRUD for Admin: view, add, edit, delete using one popup; Staff remains read-only.
- Existing routes/storage keys remain unchanged.
