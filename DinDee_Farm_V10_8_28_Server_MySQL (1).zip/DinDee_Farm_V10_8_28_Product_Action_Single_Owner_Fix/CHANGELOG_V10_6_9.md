# V10.6.9 — Crop Cycle Species Master + Free Text
- Crop Cycle plant/animal field now suggests active values from Settings > ชนิดพืช / สัตว์.
- Users can still type any new plant/animal name directly.
- Typed custom names are saved only to that Crop Cycle and are NOT automatically added to the Master.
- Edit Crop Cycle uses the same select-or-type behavior.
- V10.6.8 Harvest Edit/Delete and Dashboard borders remain unchanged.
