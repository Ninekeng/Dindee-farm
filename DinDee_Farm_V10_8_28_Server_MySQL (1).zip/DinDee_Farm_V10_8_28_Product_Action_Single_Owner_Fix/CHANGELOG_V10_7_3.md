# V10.7.3 — Purchase Tag + Excel Category Fix
- Fixed root cause of empty Tag dropdown: translated Category labels were changing the actual option value.
- Category options now have explicit stable English values while still displaying Thai descriptions.
- Tag dropdown is rebuilt from the stable Category value.
- Repairs legacy Purchase/Stock/Purchase-Expense categories accidentally saved as `English — Thai`.
- Excel import canonicalizes old translated category labels back to the web Master value.
- Excel engine failure now gives a clear Internet/Refresh diagnostic instead of appearing to do nothing.
