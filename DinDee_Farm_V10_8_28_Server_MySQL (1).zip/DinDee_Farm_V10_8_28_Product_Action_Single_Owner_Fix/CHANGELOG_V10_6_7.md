# V10.6.7 — Harvest Edit/Delete Fix
- Added Edit and Delete actions to Harvest History for Admin.
- Edit opens one popup with cycle, date, yield, unit, loss and note, then saves once.
- Delete requires confirmation and writes an Audit entry.
- Existing harvest creation remains unchanged.
- V10.6.6 Monthly Plan scrollbar/month-per-greenhouse changes are preserved.
