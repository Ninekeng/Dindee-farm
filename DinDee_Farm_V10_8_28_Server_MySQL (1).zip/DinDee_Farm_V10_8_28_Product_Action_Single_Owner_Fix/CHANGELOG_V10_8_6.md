# V10.8.6 — Packed Photo Optional
- Preparing → Packed no longer requires a photo.
- Staff can press “📦 เตรียมสินค้าเสร็จ” immediately for faster multi-order processing.
- Photo and remark remain available as optional fields under a collapsible section.
- If an optional photo is attached it is stored exactly as before and remains visible to the customer.
- Order status/history behavior is preserved.
