# DinDee Farm V10.5.1 — Safe Delete Controls

- เพิ่มปุ่มลบใน รอบการผลิต, โรงเรือน/พื้นที่, จัดการร้านค้าฟาร์ม, เอกสารขาย และ Sponsor Fund
- ใช้การลบแบบปลอดภัย: รายการที่ไม่มีประวัติเชื่อมโยงลบถาวรได้
- รายการที่มีประวัติธุรกรรม/การผลิตจะ Cancel, Archive หรือ Deactivate แทน เพื่อรักษา Stock, Finance, Analytics และ Audit
- ทุกการลบ/ปิดใช้งานบันทึก Audit Log
- รอบการผลิตตรวจ Usage/Harvest/Direct Cost/Income ก่อนลบ
- โรงเรือนตรวจ Cycle/Task/Usage/Harvest/Product ก่อนลบ
- เอกสารขายที่ชำระแล้ว/เชื่อม Order/Income จะ Cancel แทนลบ
- Sponsor Fund ที่เคยใช้เงินแล้วจะปิดใช้งานแทนลบ
