# V10.8.23 — Farm Shop Save Fix

- Fixed Add Product save crash caused by inaccessible `dataFile()` helper in V10.8.22.
- Add Product now uses the global `fileData()` helper only when an image is selected, otherwise saves directly.
- Renamed price label to `ราคาขาย (บาท/หน่วย)` in Add/Edit Product to clarify unit pricing.
- Preserves Farm/Stock/Processed/Other source linkage from V10.8.22.
