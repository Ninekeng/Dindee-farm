# V10.7.9 — Shop Mapping UI Label
- Renamed the Shop Admin category-management entry point to “⚙️ หมวดสินค้า & Income Mapping”.
- Added a tooltip explaining that this is where Shop Category maps to Income Category and Income Tag.
- No accounting logic, order logic, history, or existing mapping behavior was removed or changed.
