# DinDee Farm V10.4.4 Stable Analytics & Work History
- Removed unauthenticated Reset Admin button from Login and disabled resetAdminLogin action before authentication.
- Added income and expense pie charts on Farm Overview with category amount, percentage, and drill-down.
- Added Farm Analytics insights: top income/expense categories, prior-period comparison, overdue tasks, low stock, near-expiry lots.
- Sponsor remains separate from operating revenue.
- Added completed Work History to Today page.
- Work History supports single-popup edit and guarded delete.
- Completed task popup can record actual date, operator, result, evidence photo, and Stock Lot usage.
- Editing/deleting task history reconciles linked Lot stock and writes Audit records.
- Existing routes and dindee_v7_ storage namespace retained.
