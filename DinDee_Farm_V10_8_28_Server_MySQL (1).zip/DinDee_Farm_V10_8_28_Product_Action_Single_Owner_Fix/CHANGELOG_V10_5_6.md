# V10.5.6 — Consolidated Actions + Work History

- Consolidated visible delete actions so each record has only one Delete button.
- Stopped loading V10.5.3/V10.5.4 UI-injection patches that were stacking duplicate buttons.
- Kept safe-delete functions from V10.5.1/V10.5.2.
- Added Work History based on existing completed task records (no duplicate history data).
- Work History supports date, house, crop cycle, status, and text filters; edit/delete and photo evidence.
- Added Work History entry card on Today page.
