# V10.7.1 — Optional Species Master Save + Compact Sidebar
- When a new plant/animal name is typed in a Crop Cycle and saved, the system asks whether to add it to Settings > ชนิดพืช / สัตว์.
- Yes: saves to Master for future dropdown suggestions. No: keeps it only in the Crop Cycle.
- Existing Master names do not trigger the question.
- The same check is applied when editing a Crop Cycle.
- Desktop sidebar reduced from the original 270px to 245px, preserving the existing green theme and all navigation.
