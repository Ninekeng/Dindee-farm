# V10.7.2 — Final requested fixes
1. Monthly Plan date headers now show weekday + day number for every greenhouse.
2. Dashboard shows a dedicated Purchase KPI card for the selected date range; purchases remain included in expense calculations without duplicating Purchase auto-expenses.
3. Purchase History adds Edit / Copy / Delete. Edit synchronizes unused Stock and linked Purchase expense; Delete is blocked after stock from that Lot has been used and otherwise reverses Stock + auto expense safely.
4. Excel Purchase import now validates against the same expense Category, Tag and Unit masters used by the web form, with whitespace/case normalization. Export and Import keep the same Purchase columns.
