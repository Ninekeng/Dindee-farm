# Changelog

## V10.3.2 Professional UI & Naming Standard
- Professional visual refresh for the full post-login application shell.
- Standardized menu/page names in Thai for easier operation.
- Added consistent page title, group breadcrumb, table/card/form styling.
- Kept routes and storage keys unchanged to preserve existing data and functions.
- Existing V10.3.1 Supplier relationship and Monthly Plan changes remain intact.


## V10.3 Professional
- Modern Smart Farm login screen.
- Two-level icon sidebar with grouped navigation.
- Report Center groups reports in one place.
- Purchase and Finance bulk Import/Export with template, validation, preview and batch audit.
- Settings Master export/import with preview.
- Full Backup/Restore preserved.
- V10.2 Purchase, Stock, Finance, Sales and Thai Category/Tag behavior preserved.

## V10.3.1 Supplier Link Fix
- Purchase Supplier is now searchable/typeable using the Supplier Master.
- Staff can type a new Supplier during Purchase; it is created in Master automatically.
- Purchase and Stock retain `supplierId` plus legacy supplier name for backward compatibility.
- Renamed visible “แผนดูแล 30 วัน” to “แผนรายเดือน”; route/data remain unchanged for compatibility.
